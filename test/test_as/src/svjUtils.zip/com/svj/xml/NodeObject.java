package com.svj.xml;

import java.util.Vector;
import java.util.Hashtable;

/**
 * Обьект с вложенными аттрибутами-данными.
 * Реализован для работы с редактором книг.
 * Является частью главы.
 * Хранит в себе свое имя (Идентификатор), текст, список служебных аттрибутов
 *  (даты создания и последнего изменения и т.д.).
 * <BR> User: Zhiganov
 * <BR> Date: 08.09.2004
 * <BR> Time: 17:40:18
 */
public class NodeObject
{
   private  String      name;
   private  Vector      text;
   private  Hashtable   attr;

   public NodeObject ()
   {
      name  = "name";
      text  = new Vector ( );
      attr  = new Hashtable ( );
   }

   public NodeObject ( String name, Vector text )
   {
      this.name = name;
      this.text = text;
      attr  = new Hashtable ( );
   }

   public NodeObject ( String name, Vector text, Hashtable attr )
   {
      this.name = name;
      this.text = text;
      this.attr = attr;
   }

   public NodeObject ( String name, Hashtable attr )
   {
      this.name = name;
      this.attr = attr;
      text  = new Vector ( );
   }

   /**
    * Выводит только имя, т.к. именно этой функцией выводится заголовок на экран в
    * дереве меню оглавления.
    * @return  Строка, отображающая  содержимое обьекта.
    */
   public String  toString ()
   {
      return   name;
   }

   public String  getInfo ()
   {
      StringBuffer   result   = new StringBuffer ( 256 );
      result.append ( "NodeObject '" );
      result.append ( name );
      result.append ( "': [ " );
      result.append ( "text = ( " );
      result.append ( text );
      result.append ( " ); attr = ( " );
      result.append ( attr );
      result.append ( " ) ]" );
      return   result.toString ();
   }

   public String getName ()
   {
      return name;
   }

   public Vector getText ()
   {
      return text;
   }

   public void setName ( String name )
   {
      this.name = name;
   }

   public void setText ( Vector text )
   {
      this.text = text;
   }

   public String getAttribute ( String name )
   {
      String   result;
      result   = (String) attr.get ( name );
      return result;
   }

   public void setAttribute ( String name, String value )
   {
      attr.put ( name, value );
   }

   public Hashtable getAttr ()
   {
      return attr;
   }

   public void setAttr ( Hashtable attr )
   {
      this.attr = attr;
   }


//==============================================================================

}
package com.svj.xml;

import java.util.Hashtable;

/**
 * Содержит константы для древовидных обьектов и динамические параметры.
 * <BR> <BR> User: Zhiganov <BR> Date: 05.07.2005 <BR> Time: 16:57:59
 */
public class TOPar
{
   /* Полное имя до файловой директории, откуда был закачан данный конфиг.
   Необходим для дальнейшей подкачки данных из файлов. На конце строки обязательно
   должен быть символ разделителя. Возможно, лучше Hashtable - на случай если
   в одной программе таких ситуаций много. Тогда все они - под разными именами. */
   public static String    FilePath  = "";

   /** Имя параметра, хранящего вид разделителя имен в полном пути. */
   public static final String SEPARATOR_NAME   = "separator";
   /** Имя служебного параметра 'full_name'. */
   public static final String FULL_NAME        = "full_name";
   /** Имя служебного параметра 'name'. */
   public static final String NAME             = "name";
   /** Имя служебного параметра 'FILE'. */
   public static final String FILE             = "FILE";
   /** Имя служебного параметра 'file_load'. */
   public static final String FILE_LOAD        = "file_load";

   public static final String YES              = "yes";
   public static final String NO               = "no";



}

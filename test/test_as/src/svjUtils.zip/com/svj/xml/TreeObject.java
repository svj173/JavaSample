package com.svj.xml;

import com.svj.xml.handlers.ObjectHandler;

import java.util.*;
import java.io.FileReader;


/**
 * Древовидный обьект.
 * <BR> TODO Проблема:
 * Файл подкачки активируется при getTreeObject.
 * Но ведь есть же еще и getTreeObjectsEnum
 * <BR> User: Zhiganov
 * <BR> Date: 27.05.2004
 * <BR> Time: 9:35:17
 */
public class TreeObject
{
   /** для строковых и простых обьектных параметров */
   private	Hashtable	string_params;

   /** для вложенных Tree обьектов дерева (вкладываются  только обьекты вида TreeObject) */
   private	Hashtable	tree_object_params;

   /** для вложенных обьектов дерева  */
   private	Hashtable	object_params;

   /** Отвечает за порядок расположения обьектов дерева, согласно их прописке в
    * xml-файле. Хранит имена обьектов. */
   private  Vector      tree_object_ordering;

//==================================================================================

   public TreeObject		()
   {
      string_params	        = new Hashtable ();		// for String and Object parameters
      // for TreeObject parameters - для вложенных обьектов такого-же типа как и этот
      object_params	        = new Hashtable ();
      tree_object_params	= new Hashtable ();
      tree_object_ordering	= new Vector ();
   }

   public TreeObject		( Hashtable stringParams )
   {
      string_params	= stringParams;
      // for TreeObject parameters - для вложенных обьектов такого-же типа как и этот
      object_params	= new Hashtable ();
      tree_object_params	= new Hashtable ();
      tree_object_ordering	= new Vector ();
      //FilePath = "";
   }

   /**
   * Выдать строковый параметр
   */
   public	String	getString	( String paramName )
   {
      if ( paramName == null )	return	null;
      else	return	(String) string_params.get ( paramName );
   }

   /**
   * Выдать строковый параметр
   */
   public	String	getName	()
   {
      return	(String) string_params.get ( TOPar.NAME );
   }

//-----------------------------------------------------------------------------------
   /**
   * Выдать строковый параметр
   * @param defaultParam	- параметр по умолчанию если искомого значения нет
   */
   public	String	getString	( String paramName, String defaultParam )
   {
      if ( paramName == null )	return	defaultParam;
      String	str	= (String) string_params.get ( paramName );
      if ( str == null )	str	= defaultParam;
      return	str;
   }

//-----------------------------------------------------------------------------------
   /**
   * Сохранить строковый параметр
   */
   public	void	setString	( String paramName, String paramValue )
   {
      string_params.put ( paramName, paramValue );
   }

//-----------------------------------------------------------------------------------
   /**
   * Выдать строковый параметр по полному пути
   *  @param fullName   полное имя параметра
   */
   public	String	getParameter	( String fullName )
        throws Exception
   {
       return   getParameter ( fullName, getSeparator() );
   }

   /**
   * Выдать строковый параметр по полному пути
   *  @param fullName   полное имя параметра
   */
   public	String	getParam	( String fullName )
   {
       String result;
       try
       {
           result   =   getParameter ( fullName, getSeparator() );
       } catch ( Exception e )
       {
           result   = null;
       }
       return result;
   }

   /**
   * Выдать строковый параметр по полному пути
   *  @param fullName   полное имя параметра
   *  @param sep    используемый в полном имени разделитель.
   */
   public	String	getParameter	( String fullName, String sep )
        throws Exception
   {
       String result, str;
       result = null;
       //System.out.println ( "fullName = " + fullName + ", sep = " + sep );
       if (fullName == null) return result;
       int i;
       TreeObject to;
       // Взять обьект, отвечающий за этот параметр
       i = fullName.lastIndexOf(sep);
       if (i < 0) return result;
       // - Обрезать имя параметра
       str = fullName.substring(0, i);
       to = getTreeObject(str, sep);
       if (to == null) return result;
       //System.out.println ( "to = " + to );
       // Выделить последнее имя из полного пути
       //System.out.println ( "i = " + i );
       str = fullName.substring(i + sep.length());
       //System.out.println ( "param name = " + str );
       if (str == null) return result;
       result = to.getString(str);
       //System.out.println ( "result = " + result );
       return result;
   }

   /**
   * Изменить строковый параметр по полному пути
   *  @param fullName   полное имя параметра
   *  @param value    значение.
   */
   public	void	setParameter	( String fullName, String value )
        throws Exception
   {
       //System.out.println ( "fullName = " + fullName + ", sep = " + sep );
       if (fullName == null || value == null)
           throw new TOException("fullName = " + fullName + " or value = " + value + " is NULL.");
       String str, sep;
       int i;
       TreeObject to;

       sep = ".";
       to = getTreeObject(fullName, sep);
       //System.out.println ( "to = " + to );
       // Выделить последнее имя из полного пути
       i = fullName.lastIndexOf(sep);
       //System.out.println ( "i = " + i );
       if (i < 0) throw new TOException("Cannot give last name.");
       str = fullName.substring(i + sep.length());
       //System.out.println ( "param name = " + str );
       if (str == null) throw new TOException("Last name is NULL.");
       //result   = to.getString ( str );
       to.setString(str, value);
   }

//-----------------------------------------------------------------------------------
   /**
   * Сохранить обьектный параметр
   */
   public	void	setTreeObject	( String objectName, Object object )
   {
      if ( object	  == null )	return;
      if ( objectName == null )	objectName	= "param-00";
      tree_object_params.put ( objectName, object );
      tree_object_ordering.addElement ( objectName );
   }

//-----------------------------------------------------------------------------------
   /**
   * Сохранить обьектный параметр
   */
   public	void	setObject	( String objectName, Object object )
   {
      if ( object		== null )	return;
      if ( objectName == null )	objectName	= "param-00";
      object_params.put ( objectName, object );
   }

//-----------------------------------------------------------------------------------
   /**
   * Получить вложенный древовидный обьект по его имени
   * @return		обьект TreeObject
   */
   public	Object	getObject	( String	objectName )
   {
      if ( objectName == null )	return null;
      return	(Object) object_params.get ( objectName );
   }

//-----------------------------------------------------------------------------------
   /**
   * Получить вложенный древовидный обьект по его имени
   * <BR> Если это компонента - проверить, были ли подкачаны данные
   *  из стороннего файла  (ссылка на файл, в котором прописаны аттрибуты
   *  данной компоненты - чтобы не засорять основное меню).
   * @return		обьект TreeObject
   */
   public	TreeObject	getTreeObject	( String	objectName )  throws Exception
   {
      if ( objectName == null )	return null;
      TreeObject  result;
      try
      {
         result   = (TreeObject) tree_object_params.get ( objectName );
         if ( result != null )   result.treatLoadFile ();
      } catch ( TOException te )
      {
         throw te;
      } catch ( Exception e )
      {
         throw new TOException ( "Get TreeObject error. " + e.getMessage (), e );
      }
      return	result;
   }

//-----------------------------------------------------------------------------------
   /**
    *  Найти в дереве компоненту по полному имени (по расположению а не ИД).
    * Если данный tree-обьект (tp) имет вложенные обьекты, например: selects - obj1 - obj2,
    * то сразу получить обьект obj2 можно командой:
    * <BR>  tresult = tp.getTreeObject("selects.obj1.obj2", tp.getSeparator() );
    *
    * @param   full_name
    * @param   sep    Знак разделителя в заданном полном пути
    *    (может отличаться от исходного)
    * @return  TreeObject либо NULL если не нашел
    * @throws  TOException
    */
   public TreeObject getTreeObject ( String full_name, String sep )
        throws TOException
   {
      TreeObject parent, result	= this;
      // если нет полного имени - вернуть корневой обьект
      if ( full_name == null )	return result;
      parent   = result;
      String	oName;
      try
      {
         StringTokenizer tokenizer = new StringTokenizer ( full_name, sep );
          // пропустить корневой элемент - если начало имен - с самого корня.
         if ( full_name.startsWith(sep) )      tokenizer.nextToken();

         while ( tokenizer.hasMoreTokens() )
         {
            // взять имя обьекта
            oName	= tokenizer.nextToken();
            // Получить обьект с таким именем
            result	= result.getTreeObject ( oName );
            if ( result	== null )
            {
               // Какая-то ошибка в полном имени - не должно быть.
                // Возможно - это было уже имя параметра а не tree-обьекта
               //result   = parent;    // null ?
                // NULL - Нельзя. Ломается метод - getParameter(fullName,sep) - Исправил
                break;
            }
            /*
            else
            {
               parent   = result;
            }
            */
         }
         // Получили требуемый элемент.
         // - Проверить, есть ли в нем подгружаемые обьекты.
         if ( result != null )   result.treatLoadFile ();
      } catch ( Exception e )
      {
         throw new TOException ( "Get TreeObject error. " + e.getMessage (), e );
      }

      return	result;
   }

//-----------------------------------------------------------------------------------
   /**
    * Удалить обьектный параметр.
    */
    public	void	deleteObject	( String objectName )
    {
       object_params.remove ( objectName );
    }

//-----------------------------------------------------------------------------------
    /**
    * Удалить строковый параметр
    */
    public	void	deleteString	( String objectName )
    {
       string_params.remove ( objectName );
    }


//-----------------------------------------------------------------------------------
    /**
    * Удалить все обьектные параметры
    */
    public	void	deleteObjects	()
    {
       object_params.clear();
    }

//-----------------------------------------------------------------------------------
    /**
    * Удалить обьектный параметр
    */
    public	void	deleteTreeObject	( String objectName )
    {
       tree_object_params.remove ( objectName );
       tree_object_ordering.remove ( objectName );
    }


//-----------------------------------------------------------------------------------
    /**
    * Удалить все обьектные параметры
    */
    public	void	deleteTreeObjects	()
    {
       tree_object_params.clear();
       tree_object_ordering.clear ();
    }

//-----------------------------------------------------------------------------------
   /**
   * Удалить все служебные строковые параметры
   */
   public	void	deleteServiceString ()
   {
      string_params.remove ( TOPar.SEPARATOR_NAME );
      string_params.remove ( TOPar.FULL_NAME );
      string_params.remove ( TOPar.NAME );
      string_params.remove ( TOPar.FILE );
      string_params.remove ( TOPar.FILE_LOAD );
   }

//-----------------------------------------------------------------------------------
    /**
    * Полностью очистить обьект
    */
    public	void	clear	()
    {
       object_params.clear();
       string_params.clear();
    }
//-----------------------------------------------------------------------------------
    /**
    * Проверить, есть ли значения в обьекте - как строковые так и обьектные
    */
    public	boolean	isEmpty	()
    {
       if ( (string_params.isEmpty()) && ( object_params.isEmpty()) )	return	true;
       else	return false;
    }

//-----------------------------------------------------------------------------------
    /**
    * Преобразовать обьект в строку
    */
    public	String	toString	()
    {
       return	toString ( 0 );
    }

//-----------------------------------------------------------------------------------
    /**
    * Преобразовать обьект в строку, начиная с заданного уровня вложенности.
    * Уровень вложенности используется как индикатор и только для формирования отступов.
    * Один уровень равен двум пробелам.
    */
    public	String	toString	( int level )
    {
       StringBuffer	result	= new StringBuffer ( 1024);
       String	str, parName, tab;
       TreeObject	to;
       Enumeration parNames;
       Object      obj;
       int           i;

       // сформировать левый отступ, согласно уровню вложенности (уровень = 2 пробела)
       String	left_sp		= "\n";
       String	left_sp2	   = "\n";
       for ( i=0; i<level ; i++ )		left_sp	+= "  ";
       left_sp2	= left_sp + "  ";

       result.append ( left_sp );
       result.append ( "TreeObject { " );

       // Строковые параметры
       parNames = string_params.keys();
       while ( parNames.hasMoreElements() )
       {
          parName	= (String) parNames.nextElement();
          str		= (String) string_params.get ( parName );
          result.append ( left_sp2 );
          result.append ( "[ " );
          result.append ( parName );
          tab = "\t";
          //if ( parName.length() < 16 )	tab	= "\t";
          if ( parName.length() <  8 )	tab	= tab + tab;
          result.append ( tab );
          result.append ( "= " );
          result.append ( str );
          result.append ( " ]" );
       }

       // TreeObject обьекты
       //parNames = tree_object_params.elements();
       for ( i=0; i<tree_object_ordering.size (); i++ )
       //while ( parNames.hasMoreElements() )
       {
          // tree_object_ordering - вектор имен
          str		= (String) tree_object_ordering.get ( i );
          to		= (TreeObject) tree_object_params.get ( str );
          //obj   = parNames.nextElement();
          //to		= (TreeObject) obj;
          result.append ( to.toString ( level+1 ) );
       }

       // Простые обьекты
       parNames = object_params.elements();
       while ( parNames.hasMoreElements() )
       {
          obj		= parNames.nextElement();
          result.append ( obj.toString () );
       }

       result.append ( left_sp );
       result.append ( "}" );

       return	result.toString();
    }


//-----------------------------------------------------------------------------------
    /**
    * Получить кол-во вложенных обьектов
    */
    public	int	getObjectSize	()
    {
       return	object_params.size();
    }

//-----------------------------------------------------------------------------------
    /**
    * Получить кол-во вложенных обьектов
    */
    public	int	getTreeObjectSize	()
    {
       return	tree_object_params.size();
    }

//-----------------------------------------------------------------------------------
    /**
    * Получить общее кол-во вложенных обьектов и строковых параметров.
    */
   public	int	getSize	()
   {
      int   result   = 0;
      result   += object_params.size();
      result   += tree_object_params.size();
      result   += string_params.size();
      return	result;
   }

   /**
    * Установить новое значение разделителя имен.
    * @param separator
    */
   public void setSeparator ( String separator )
   {
      string_params.put ( TOPar.SEPARATOR_NAME, separator );
   }

   /**
    * Выдать значение разделителя имен, если оно прописано в данном обьекте.
    * @return Separator as String
    */
   public String getSeparator ( )
   {
      return   (String) string_params.get ( TOPar.SEPARATOR_NAME );
   }

   /**
    * Выдать как Enumeration массив имен вложенных tree-обьектов в порядке их расположения в файле.
    * @return Массив имен.
    */
   public Enumeration   getTreeObjectsEnum()
   {
      Enumeration result;
      //result   = tree_object_params.keys ();
      result   = tree_object_ordering.elements ();
      return   result;
   }

   /**
    * Выдать массив вложенных tree обьектов как Enumeration.
    * @return Массив собственно tree-обьектов.
    */
   public Enumeration   getTreeObjectsEnumeration()
   {
      Enumeration result;
      result   = tree_object_params.elements ();
      return   result;
   }


   /**
    * Выдать массив обьектных (не строковых) параметров как Enumeration.
    * @return массив обьектов
    */
   public Enumeration   getObjectsEnum()
   {
      Enumeration result;
      result   = object_params.keys ();
      return   result;
   }

   /**
    * Выдать массив со строковыми параметрами.
    * @return  Hashtable строковых параметров.
    */
   public Hashtable  getStrings ()
   {
      return string_params;
   }

   /**
    * Выдать массив с обьектами.
    * @return  Hashtable, в котором хранятся обьектные параметры (не древовидные)
    */
   public Hashtable  getObjects ()
   {
      return object_params;
   }

   /**
    * Выдать массив с древовидными обьектами.
    * @return   Hashtable  TreeObjects обьектов
    */
   public Hashtable  getTreeObjects ()
   {
      return tree_object_params;
   }

   /**
    * Добавить массив с параметрами.
    */
   public void  addStrings ( Hashtable params )
   {
      string_params.putAll ( params );
   }

   /**
    * Добавить - Сложить обьекты (Add two TreeObjects).
    */
   public void  addTreeObject ( TreeObject to )   throws Exception
   {
      string_params.putAll ( to.getStrings() );
      object_params.putAll ( to.getObjects () );
      // Переписать полные пути
      //  - Установить знак-разделитель для имени
      String   sep   = getString ( TOPar.SEPARATOR_NAME );
      if ( sep == null )   sep   = ".";
      //to.setSeparator ( sep );
      // - Взять текущий корневой путь
      String   path  = getString ( TOPar.FULL_NAME );
      if ( path == null )  path  = "";
      // - Переписать (рекурсивно)
      rewriteFullPath ( to, path, sep );
      tree_object_params.putAll ( to.getTreeObjects () );
      tree_object_ordering.addAll ( to.getTreeObjectsOrder () );
   }

   /**
    * Выдать массив порядкового расположения древовидных обьектов.
    * @return Вектор имен tree-обьектов.
    */
   public Vector getTreeObjectsOrder ()
   {
      return tree_object_ordering;
   }

   /**
    * Переписать полное имя-путь обьекта.
    * Используется при сложении двух древовидных обьектов, приведя новые
    * обьекты к используемому пути.
    * @param to
    * @param path
    * @param sep
    */
   private void rewriteFullPath ( TreeObject to, String path, String sep )
      throws TOException
   {
      if ( to == null ) return;

      String   str, fpath;
      TreeObject  tr;
      // Заменить полное имя
      // - Взять имя
      str   = to.getString ( TOPar.NAME );
      if ( str != null )
      {
         // - Добавить его к корневому пути
         fpath = path + sep + str;
         // - Занести в обьект
         to.setString ( TOPar.FULL_NAME, fpath );
      }
      else
      {
         // Не надо добавлять имя
         fpath = path;
      }

      try
      {
         // - Перебрать другие вложенные обьекты, если есть
         Enumeration en = to.getTreeObjectsEnum ();
         while ( en.hasMoreElements () )
         {
            str   = (String) en.nextElement ();
            tr    = to.getTreeObject ( str );
            rewriteFullPath ( tr, fpath, sep );
         }
      } catch ( TOException te )
      {
         throw te;
      } catch ( Exception e )
      {
         throw new TOException ( "Rewrite Full Path error. " + e.getMessage (), e );
      }
   }

   /**
    * Добавить в компоненту данные из файла, если есть ссылка на файл и данные
    *  еще не подкачивались.
    */
   public void treatLoadFile () throws Exception
   {
      String   file, str;
      TreeObject  to;

      to    = this;
      file  = to.getString ( TOPar.FILE );
      if ( file == null )   return;  // Нет ссылки на подгрузку файла

      /*
      // Есть ссылка - проверить, была ли подкачка.
      boolean  bLoad = true;
      str   = to.getString ( FILE_LOAD );
      if ( str == null )   bLoad = false;
      else   if ( ! str.equalsIgnoreCase( YES ) )   bLoad = false;

      if ( bLoad )   return;  // Есть ссылка. Была подкачка
      */

      // Подкачать.

      // Создать полный путь до файла
      str   = createPath ( file );
      //System.out.println ( "Load config file = " + str + ", FilePath = " + TOPar.FilePath );

      // Распарсить XML конфиг
      ObjectHandler hdb  = new ObjectHandler ();
      try
      {
         FileReader  fr = new FileReader ( str );
         Parser.parse ( hdb, fr );
      } catch ( Exception e )
      {
         throw new TOException ( "XML config file '" + str + "' parsing error.", e );
      }
      TreeObject  result          = (TreeObject) hdb.getResult();
      //Syslog.l.debug ( "Get file = " + result );
      // Удалить сервисные параметры (name, full_name...)
      result.deleteServiceString ();
      // скопировать параметры в исходный
      to.addTreeObject ( result );
      //Syslog.l.debug ( "Create new config = " + to );
      // Установить флаг что подгрузка уже была
      //to.setString ( FILE_LOAD, YES );
      // Удалить параметр файла подкачки - как признак что подкачка уже состоялась
      to.deleteString ( TOPar.FILE );
   }

   /**
    * Создать копию обьекта.
    * @param   source
    * @return  Копия в виде TreeObject
    */
   public TreeObject clone ( TreeObject source )
   {
      TreeObject result          = new TreeObject ();
      result.string_params       = new Hashtable ( source.getStrings() );
      result.tree_object_params  = new Hashtable ();
      Iterator it = source.tree_object_params.entrySet().iterator ();
      while ( it.hasNext () )
      {
         Map.Entry  entry = ( Map.Entry ) it.next ();
         TreeObject value = clone ( ( TreeObject ) entry.getValue () );
         result.tree_object_params.put ( entry.getKey(), value );
      }
      return result;
   }

   /**
    * Создать абсолютный файловый путь.
    * @param   path
    * @return  Путь в виде строки.
    */
   private  String createPath ( String path )
   {
      String   result   = "";
      // Создать полный путь до файла
      if ( (path.indexOf ( ':') > 0 ) || (path.startsWith ( "/")) || (path.startsWith ( "\\") ) )
         result   = path;  // Прописан абсолютный путь - взять целиком
      else
         result   = TOPar.FilePath + "/" + path;   // Сложить с абсолютным
      return result;
   }


//==================================================================================

}
package com.svj.xml;

/**
 * Данный класс выдает только версию данного jar-файла.
 * <BR> Версия устанавливается при установке в CVS версионного Tag.
 * <BR> Данный класс прописан как стартовый в манифесте SimpleXML.jar.
 * <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 26.08.2004
 * <BR> Time: 16:16:24
 */
public class Version
{
   /**
    * Получение номера версии.
    * <BR> Запуск: java -jar svjXml.jar
    */
   public static void main ( String[] args ) throws Exception
   {
      String   version  = "2.6";
      String   nameTag  = "$Name:  $";
      String   dataTag  = "Date: 2005/08/03 17:01";
      System.out.println ( "svjXml.jar, version = " + version + ", cvs_tag = "
              + nameTag + ", " + dataTag );
   }

}
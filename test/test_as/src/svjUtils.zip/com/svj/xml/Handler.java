package com.svj.xml;

import java.util.*;

/**
 * Интерфейс обработчика XML файлов.
 * <BR> Zhiganov Sergey.
 * <BR> 2 mar 2004.
 */
public interface Handler
{

   /**
    * Найден начальный тэг.
    * @param tag        Имя тэга.
    * @param h          Hashtable, содержащий список аттрибутов тэга
    *                      (если они есть) и их значения.
    * @throws Exception
    */
   public void startElement ( String tag, Hashtable h ) throws Exception;

   /**
    * Найден конечный тэг.
    * @param tag    Имя тэга.
    * @throws Exception
    */
   public void endElement ( String tag ) throws Exception;

   /**
    * Обнаружено начало документа.
    * @throws Exception
    */
   public void startDocument () throws Exception;

   /**
    * Обнаружен конец документа.
    * @throws Exception
    */
   public void endDocument () throws Exception;

   /**
    * Текстовое содержимое тэга. Также здесь выдаются пробелы и переводы строк.
    * @param str
    * @throws Exception
    */
   public void text ( String str ) throws Exception;

   /**
    * Выдать результат в виде обьекта, сформирвоанного обработчиком
    * (строка, Hashtable, TreeObjects и т.д.)
    * @return
    * @throws Exception
    */
   public Object getResult () throws Exception;

}
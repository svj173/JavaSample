package com.svj.xml.handlers;

import java.util.Hashtable;
import java.util.Enumeration;

import org.apache.log4j.*;

import com.svj.xml.Handler;
import com.svj.xml.TreeObject;
import com.svj.xml.TOException;
import com.svj.xml.TOPar;

/**
 * Создает древовидный обьект из параметров, взятых из XML файла. Причем, тэги,
 *    имеющие внутри себя другие тэги, создаются как обьект, а тэги,
 *    имеющие только параметр, заносятся как параметр в Hashtable.
 * <BR> Вложенные обьекты (одинаковые имена тэгов) должны обязательно иметь подпараметр
 *    "name", по которому эти обьекты и будут заноситься в общий пул. Обьекты,
 *    не имеющие такой параметр, буду заноситься в общий пул под именем своего тэга.
 * <BR> Так же каждый созданный обьект имеет как параметр полный путь от корня.
 * <PRE>
    При ситуации
    &lt;COMP1&gt;
      &lt;COMP2&gt;
        &lt;COMP3&gt;
    </PRE>
    - создается один стэк. При появлении стартового тэга древовидного обьекта
    создается обьект, заносится в него его тип и складывается в стэк.
      При появлении конечного тэга
    вынимается из стэка верхний обьект, узнается его тип, и этот обьект
      добавляется внутрь соответсвующего
    обьекта. При появлении элементов древовидного обьекта
      (должен быть флаг активности древ обьекта),
    выделенные элементы заносятся внутрь обьекта из стэка, который из стэка
      берется без удаления.
 * <BR>
 * <BR> Зарезервированные имена тэгов:
 * <LI> name - имя для обьектов с одинаковыми названиями тэгов</LI>
 * <LI> full_path - полный путь до данного обьекта от корня</LI>
 * <LI> root - имя для корневого обьекта</LI>
 * <LI> separator - Имя параметра, хранящего вид разделителя имен в полном пути.</LI>
 * <BR>
 * <BR> Особенности:
 * <LI> пустой тэг формируется как обьект.</LI>
 * <LI> Имя для 'name' всегда преобразуется к маленьким буквам - для удобства поиска.</LI>
 * <LI>Если в обьекте нет name, то name = имени тэга обьекта.</LI>
   <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 27.05.2004
 * <BR> Time: 9:28:52
 */
public class ObjectHandler   implements Handler
{
   /** Хранилище древовидных обьектов для выдачи результата */
   private TreeObject	result   = null;

   /** Текущий древовидный обьект */
   private TreeObject	currentObject;

   /** Имя текущего тэга - используется при получении текста */
   private String		   currentTagName;

   /** Полный путь до обьекта - из имен обьектов от корня */
   private String[]	   path;

   /** Счетчик имен в полном пути обьекта */
   private int          currentNum	= 0;

   /** Символы разделителя полного пути имен обьектов  */
   private	String	   SEPARATOR	= ".";

   /* Обьект, отвечающий за логирвоание работы обработчика. Может устанавливаться извне. */
   private  Logger   logger   = null;


   // Константы
   /* Имя элемента, хранящего имя обьекта. */
   private final String NAME        = "name";
   /* Имя элемента, хранящего полное имя обьекта, от корневого элемента. */
   private final String FULL_NAME   = "full_name";


//-----------------------------------------------------------------------------------
   /**
    * Конструктор. Создает собственный логгер.
    */
   public ObjectHandler ( )
   {
      logger   = Logger.getLogger ( ObjectHandler.class );
   }

   /**
    * Конструктор. Устанавливает заданный логгер.
    * @param logger  Логгер, созданный сторонним обьектом.
    */
   public ObjectHandler ( Logger logger )
   {
      this.logger = logger;
   }

   /**
    * Конструктор. Устанавливает путь до файлов. Чтобы можно было в конфиге пропсиывать относительные пути..
    * @param filePath
    */
   public ObjectHandler ( String filePath )
   {
      TOPar.FilePath = filePath;
   }

   /** Установить (изменить) разделитель имен в полном пути  */
   public void setSeparator ( String sep )
   {
      SEPARATOR	= sep;
   }

//-------------------------------------------------------------------------------
   public void startDocument () throws Exception
   {
      //mess ( 0, "=========================== start ==========================" );
      result			= new TreeObject ();   // ???
      currentTagName	= "";
      currentObject	= null;
      // глубина вложенности тэгов
      path			   = new String[100];
      currentNum		= 0;
      if ( SEPARATOR == null )	SEPARATOR	= ".";
   }

   public void endDocument () throws Exception
   {
      // Занести в результат вид используемого разделителя.
      result.setSeparator ( SEPARATOR );
      //mess ( 0, "=========================== end ==========================" );
   }

   public void startElement ( String tag, Hashtable h ) throws Exception
   {
      TreeObject to;
      String   str   = null;

      // Если нет текущего элемента - создать корневой и сделать текущим
      if ( currentObject == null )
      {
         result         = new TreeObject ();
         currentObject  = result;
         currentTagName = tag;
      }
      else
      {
         // Создать новый обьект
         to = new TreeObject ();
         // Сформировать текущее имя тэга (т.к. при вложенном name оно - другое.
         // - Взять из списка параметров имя name
         if ( h   != null )   str   = (String) h.get ( NAME );
         if ( str != null )   str   = str.toLowerCase ();  // привести к маленьким
         else  str   = tag;
         // Вложить в текущий обьект наш новый созданный
         currentObject.setTreeObject ( str, to );
         // Сделать новый обьект текущим
         currentObject  = to;
         // Сделать текущее имя новым
         currentTagName = str;
      }

      //mess ( 0, "startElement:: tag = " + tag + ", currentTagName = " + str );

      // Если есть вложенные элементы - занести их в текущий обьект как
      //    строковые параметры
      if ( (h != null) && (!h.isEmpty ()) )
      {
         String      key;
         Enumeration en  = h.keys ();
         while ( en.hasMoreElements () )
         {
            key   = (String) en.nextElement ();
            str   = (String) h.get (key);
            currentObject.setString ( key, str);
         }
      }

      // Заменить в имени тэга все символы, равные разделителю
      currentTagName = replaceSeparator ( currentTagName );

      // Занести имя в полное имя обьекта
      if ( currentTagName == null )		currentTagName	= NAME + currentNum;
      // -- Добавить имя в полный путь
      path [currentNum]	= currentTagName;
      currentNum++;	// увеличить счетчик имен

      // Просчитать полный путь и занести его в текущий обьект
      // -- Сформировать полное имя (путь) обьекта
      str		= "";
      for ( int i=0; i<currentNum ; i++ )		str	+= SEPARATOR + path[i];
      // -- Занести полный путь
      currentObject.setString ( FULL_NAME, str );
      // -- Занести имя в него же (в обьект) как имя данного обьекта
      currentObject.setString ( NAME, currentTagName );

   }

   /**
    * Заменить в имени тэга символы разделителя на какие-нибудь другие.
    * Например, на подчеркивание. Но если разделитель = подчеркивание, то тогда на '?'.
    * @param   name     Имя полученного тэга.
    * @return  Преобразованная строка.
    */
   private String replaceSeparator ( String name )
   {
      String   result   = name;
      // Пока только для одного символа. Если разделитель - стркоа - то
      //  общей замены не получается что-то.
      /*
      String   str   = "_";
      if ( str.equals(SEPARATOR) )  str   = "?";
      result   = name.replaceAll ( SEPARATOR, str );
      */
      if ( SEPARATOR.length () == 1 )
      {
         char  sep   = SEPARATOR.charAt ( 0 );
         char  ch    = '_';
         if ( ch == sep )  ch = '?';
         result   = name.replace ( sep, ch );
      }
      return result;
   }

   /**
    * Найден конечный тэг (например &lt;/COMPONENT&gt; )
    * <BR>	При появлении конечного тэга текущий обьект сменяется на -1
    * , т.е. берется родительский.
    *
    * @param  tag         Имя конечного тэга.
    * @throws Exception   Обрабатывается выше.
    */
   public void endElement ( String tag ) throws Exception
   {
      //mess ( 0, "endElement:: tag = " + tag );
      // Сделать текущим обьектом родительский
      currentObject  = getParent();
      // Если нет родительского (т.е. это конец корневого тэга) - ничего не делать.

      // Пересчитать полный путь имен
      currentNum--;	// Уменьшить счетчик имен обьектов
   }

   public void text ( String str ) throws Exception
   {
      //mess ( 0, "text:: Start" );

      // Убрать первые и последние пробелы
      str		= str.trim();

      if ( ! str.equals("") )
      {
         // Есть какие-то данные в тексте - обработать
         String   sname;
         // Взять текущий обьект из стэка (без удаления).
         // Если пуст - взять его имя и удалить совсем.
         int   isize = currentObject.getSize ();
         if ( isize == 2 )
         {
            // Обьект пуст - Взять родительский обьект и занести в него строковый параметр
            sname = currentObject.getString ( NAME );
            currentObject  = getParent();
            // Удалить предыдущий пустой обьект
            currentObject.deleteTreeObject ( sname );
         }
         else
         {
            // Это обьект. Добавить в него этот параметр под текущим именем
         }

         //mess ( 0, "text:: str = " + str + ", currentTagName = " + currentTagName );

         // Если тэг = name - привести к маленьким буквам
         if ( currentTagName.equals ( NAME ) )     str   = str.toLowerCase ( );
         // Занести как строковый параметр под взятым именем - если не пустой
         currentObject.setString ( currentTagName, str );
      }
   }

   private  TreeObject getParent ()   throws Exception
   {
      //mess ( 0, "getParent:: Start. currentNum-1 = " + (currentNum-1) + ", PATH = "
      //        + Utils.u.listArray ( path, ',' ) );
      TreeObject  to = result;
      try
      {
         for ( int i=1; i<currentNum-1 ; i++ )
         {
            // Взять имя
            to   = to.getTreeObject ( path[i] );
            //mess ( 0, " -- " + i + ". Name = " + path[i] );
            if ( to == null )
            {
               // Ошибка
               //mess ( 3, "TreeObject not found in queue. Object name = " + path[i]
               //   + ", i = " + i );
               to = result;
               break;
            }
         }
      } catch ( TOException te )
      {
         throw te;
      } catch ( Exception e )
      {
         throw new TOException ( "Get Parent TreeObject error. " + e.getMessage (), e );
      }
      //mess ( 0, "getParent:: Finish" );
      return   to;
   }


   public Object getResult ()
   {
      return result;
   }

   /**
    * Выдать отладочное сообщение.
    * <BR> Для логгера (type):
    * <BR> 0 - debug;
    * <BR> 1 - info
    * <BR> 2 - warn
    * <BR> 3 - error
    * <BR> 4 - fatal
    * <BR>
    * <BR> Если логгер отсутствует, то тогда вывод осуществляется на стандартный вывод.
    * <BR>
    *
    * @param type
    * @param text
    */
   private  void mess ( int type, String  text )
   {
      if ( logger == null )
      {
         // Нет логгера - вывести по умолчанию - на ERR
         System.err.println ( text );
      }
      else
      {
         // Logger
         switch ( type )
         {
            case 0: // info
               logger.debug ( text );
               break;
            case 1: // info
               logger.info ( text );
               break;
            case 2: // info
               logger.warn ( text );
               break;
            case 3: // info
               logger.error ( text );
               break;
            case 4: // info
               logger.fatal ( text );
               break;
            default: //
               logger.debug ( text );
               break;
         }
      }
   }

//==============================================================================

}
package com.svj.xml.handlers;

import java.util.Hashtable;
import java.util.Vector;
import java.io.FileReader;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.log4j.*;

import com.svj.xml.Handler;
import com.svj.xml.NodeObject;


/**
 * Создает древовидный обьект из параметров, взятых из XML файла.
 * Распихивая все это в обьект DefaultMutableTreeNode для дальнейшего использования
 * стандартных библиотек java swing для работы с деревом.
 * <BR> Зарезервированные имена тэгов:
 * <LI> name - имя для обьектов с одинаковыми названиями тэгов</LI>
 * <LI> full_path - полный путь до данного обьекта от корня</LI>
 * <LI> root - имя для корневого обьекта</LI>
 * <LI> separator - Имя параметра, хранящего вид разделителя имен в полном пути.</LI>
 *
 * <BR> Особенность: пустой тэг формируется как обьект.

 * <BR> User: Zhiganov
 * <BR> Date: 08.09.2004
 * <BR> Time: 12:28:52
 * <BR> Версия: $Revision $
 */
public class TreeNodeHandler   implements Handler
{
   /** Хранилище древовидных обьектов для выдачи результата */
   private DefaultMutableTreeNode	result   = null;

   /** Текущий древовидный обьект. */
   private DefaultMutableTreeNode	currentObject;
   /** Текущий элемент текущего древовидного обьекта. */
   private DefaultMutableTreeNode	currentElementObject;

   /** Имя текущего тэга - используется при получении текста. */
   private String		   currentTagName;

   private  Logger   logger   = null;

   // Константы
   /* Имя xml-тэга книги - name. */
   private final String NAME        = "name";
   /* Имя xml-тэга книги - gl. */
   private final String GL          = "gl";
   /* Имя xml-тэга книги - ab. */
   private final String AB          = "ab";
   /* Имя xml-тэга книги - element. */
   private final String ELEMENT     = "element";

   /* Вектор, хранящий в себе текстовое содержимое элемента.
   Одна запись венктора эквивалентна абзацу. */
   private Vector vText = null;

   /** Имя книги по умолчанию. (SVJ Book) */
   private String bookName          = "SVJ Book";

   /* Буфер для сообщений об ошибках. На будущее, т.к. это нужно вставить в
   интерфейс и во все старые обработчики. А пока это - потерянный текст. */
   private Vector error = new Vector ( );

//-----------------------------------------------------------------------------------
   public TreeNodeHandler ( )
   {
      logger   = Logger.getLogger ( TreeNodeHandler.class );
   }

   public TreeNodeHandler ( Logger logger )
   {
      this.logger = logger;
   }

   public TreeNodeHandler ( Logger logger, String bookName )
   {
      this.logger    = logger;
      this.bookName  = bookName;
   }

//-------------------------------------------------------------------------------
   public void startDocument () throws Exception
   {
      //mess ( 10, "=========================== start ==========================" );
      NodeObject  node  = new NodeObject ( bookName, null, null );
      result			= new DefaultMutableTreeNode ( node );
      currentTagName	= "";
      currentObject	= null;
   }

   public void endDocument () throws Exception
   {
      // Занести в результат вид используемого разделителя.
      //result.setSeparator ( SEPARATOR );
      //mess ( 10, "=========================== end ==========================" );
   }

   public void startElement ( String tag, Hashtable h ) throws Exception
   {
      //mess ( 10, " Start TAG = '" + tag + "'" );
      String        str;
      NodeObject    node;
      currentTagName = tag;

      if ( tag.equalsIgnoreCase ( GL ) )
      {
         // Это начало главы
         //mess ( 10, " Start GL" );
         // - Взять имя главы
         str   = (String) h.get ( NAME );
         // - Создать TreeNode для главы
         node  = new NodeObject ( str, null, h );
         currentObject   = new DefaultMutableTreeNode ( node );
         // - Добавить аттрибуты
         //currentObject.setUserObject ( h );
         // - Занести главу в документ
         result.add ( currentObject );
         return;
      }

      if ( tag.equalsIgnoreCase ( ELEMENT ) )
      {
         // Это начало элемента
         //mess ( 10, " Start Element" );
         // - Взять имя элемента
         str   = (String) h.get ( NAME );
         // - создать обьект для текста
         vText = new Vector();
         node  = new NodeObject ( str, vText, h );
         // - Создать TreeNode  для Элемента
         currentElementObject   = new DefaultMutableTreeNode ( node );
         // - Добавить аттрибуты
         //vText.addElement ( h );
         //currentElementObject.setUserObject ( h );
         //currentElementObject   = new DefaultMutableTreeNode ( str );
         // - занести обьект в элемент
         //currentElementObject.setUserObject ( vText );
         // - Добвить потерянные тексты, если они есть
         if ( ! error.isEmpty () )
         {
            vText.addAll ( error );
            error.clear ();
         }
         // - Занести элемент в главу
         currentObject.add ( currentElementObject );
         //return;
      }
   }

   /**
    * Найден конечный тэг (например &lt;/COMPONENT&gt; )
    * Появлется после метода text.
    * <BR>	При появлении конечного тэга текущий обьект сменяется на -1
    * , т.е. берется родительский.
    *
    * @param  tag         Имя конечного тэга.
    * @throws Exception   Обрабатывается выше.
    */
   public void endElement ( String tag ) throws Exception
   {
      currentTagName	= "";

      //mess ( 10, "end Tag: = " + tag );
      // Сделать текущим обьектом родительский
      //currentObject  = getParent();
      // Если нет родительского (т.е. это конец корневого тэга) - ничего не делать.

      // Пересчитать полный путь имен
      //currentNum--;	// Уменьшить счетчик имен обьектов
   }

   /**
    * Метод вызывается, когда появляется какой-нибудь текст.
    * Как текст внутри тэга, так и текст между тэгами.
    * Например: < ab>Text1< /ab>   < ab>.... - в этом случае метод TEXT
    * вызовется два раза - как для Text1 так и для пробелов (либо переход на
    * новую строку) между < /ab>   < ab>
    * @param str
    * @throws Exception
    */
   public void text ( String str ) throws Exception
   {
      //mess ( 10, "text = '" + str + "'" );

      // Убрать первые и последние пробелы
      str		= str.trim();

      if ( currentTagName.equalsIgnoreCase ( AB ) )
      {
         // Это абзац. Добавить если есть куда, иначе - ошибка. Но не ломаемся.
         if (vText != null ) vText.addElement ( str );
         else
         {
            String err  = "Has unknow text '" + str + "'.";
            error.addElement ( str );
            if ( logger != null )   logger.error ( err );
         }
      }
   }


   public Object getResult ()
   {
      return result;
   }

   /**
    * Выдать отладочное сообщение.
    * Для логгера:
    * 0 - debug,
    * 1 - info,
    * 2 - warn,
    * 3 - error,
    * 4 - fatal.
    *
    * @param type
    * @param text
    */
   private  void mess ( int type, String  text )
   {
      if ( logger == null )
      {
         // Нет логгера - вывести по умолчанию - на ERR
         System.err.println ( text );
      }
      else
      {
         // Logger
         switch ( type )
         {
            case 0: // info
               logger.debug ( text );
               break;
            case 1: // info
               logger.info ( text );
               break;
            case 2: // info
               logger.warn ( text );
               break;
            case 3: // info
               logger.error ( text );
               break;
            case 4: // info
               logger.fatal ( text );
               break;
            default: //
               logger.debug ( text );
               break;
         }
      }
   }

//==============================================================================
   /**
    * Test.
    * <BR> Run: java TreeNodeHandler xml_file
    */
   public static void main ( String[] args ) throws Exception
   {
      if ( args.length == 0 )
      {
         System.out.println ( "Use: java TreeNodeHandler xml_file" );
         System.exit ( 5 );
      }

      FileReader  fr;
      String      fileName;
      DefaultMutableTreeNode   res;
      TreeNodeHandler   reporter;

      reporter    = new TreeNodeHandler ();

      fileName    = args [ 0 ];
      System.out.println ( "===============================" );
      System.out.println ( "File = " + fileName );

      fr    = new FileReader ( fileName );
      com.svj.xml.Parser.parse ( reporter, fr );

      fr.close ();

      res   = (DefaultMutableTreeNode) reporter.getResult();
      System.out.println ( "Result : " + res.toString() );

      System.out.println ( "===============================" );
      reporter = null;
      res      = null;
      //System.exit ( 0 );
   }

//==============================================================================

}
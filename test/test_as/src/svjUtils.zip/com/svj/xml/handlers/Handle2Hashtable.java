package com.svj.xml.handlers;


import java.util.*;
import java.io.FileReader;

import com.svj.xml.Handler;

/**
 * Распарсивает XML файл, складывая значения тэгов в Hashtable, где
 *    ключ - полный XML путь.
 * <BR> Zhiganov Sergey.
 */
public class Handle2Hashtable implements Handler
{

   /** Хранилище древовидных обьектов для выдачи результата */
   private Hashtable	result;

   /** Стэк имен тэгов, начиная от корневого.
    * Служит для формирования полного имени каждого элемента. */
   private Stack		stack;

   /** Полное имя текущего тэга */
   private String		pathName;

   /** Символ разделителя полного пути имен обьектов  */
   public	String	SEPARATOR	= null;

   /* Флаг окончания парсинга. Если не установлен, то при выдаче результата генерит Ошибку. */
   private  boolean stopParsing  = false;

//============================================================================
   /** Установить разделитель имен в полном пути.  */
   public void setSeparator ( String sep )
   {
      SEPARATOR	= sep;
   }

    /**
    * Обнаружен тэг начала всего документа.
    */
   public void startDocument ()
   {
      //System.out.println ( "  start document" );
      stopParsing    = false;
      result			= new Hashtable ();
      stack          = new Stack();
      pathName    	= "";
      if ( SEPARATOR == null )	SEPARATOR	= ".";
   }

   /**
    * Обнаружен тэг окончания всего документа. Ничего не делать.
    */
   public void endDocument ()
   {
      //System.out.println ( "  end document" );
      stopParsing  = true;
   }

   /**
    *  Найден начальный тэг.
    *
    * @param   elem   Имя элемента (тэга).
    * @param   h      Список внутренних параметров этого элемента.
    */
   public void startElement ( String elem, Hashtable h )
   {
      String   str, key, val;
      //System.out.println ( "    start elem: " + elem );
      // Заполнить первое имя и второе имя
      //   - необходимо для парсинья xml-запросов от продавца
      str   = (String) result.get ( SEPARATOR );
      if ( str == null )
      {
         result.put ( SEPARATOR, elem );
      }
      else
      {
         str   = (String) result.get ( SEPARATOR + SEPARATOR );
         if ( str == null )
            result.put ( SEPARATOR + SEPARATOR, elem );
      }

      // Занести имя в стэк имен тэгов
      stack.push ( elem );
      // Получить полный список имен от начала
      pathName   = getPath();

      // Сохранить внутренние параметры в результирующем обьекте
      Enumeration e = h.keys ();
      while ( e.hasMoreElements () )
      {
         key = ( String ) e.nextElement ();
         val = ( String ) h.get ( key );
         if ( ! val.equals("") )
         {
            //System.out.println ( pathName + "@" + key + " = " + val );
            str   = pathName + "@" + key;
            result.put ( str, val );
         }
      }
   }

   /**
    * Найден конечный тэг. Удалить в стеке верхний элемент.
    *
    * @param elem   Имя тэга.
    */
   public void endElement ( String elem )
   {
      //System.out.println ( "    end elem: " + elem );
      // Удалить из стэка обьект если он там есть
      if ( stack.empty() )
      {
         // Стэк пустой -- Это ошибка т.к. такой ситуации не должно быть
         //System.out.println ( "+ERRORS: xmlConfig. Find endElement, but STACK is Empty !" );
      }
      else
      {
         // В стэке есть элементы
         // -- удалить верхний
         stack.pop();
         // переделать полное имя
         pathName   = getPath();
      }
   }

   /**
    * Значение тэга.
    * @param   text   Текстовое значение тэга.
    */
   public void text ( String text )
   {
      String   str, path;
      // Удалить крайние пробелы и символы перевода строк
      str   = text.replace ( '\n', ' ' );
      str   = str.replace ( '\r', ' ' );
      str   = str.trim();
      if ( ! str.equals ("") )
      {
         // Убрать последний символ разделителя из основного пути
         path  = pathName.substring(0, pathName.length()-1 );
         result.put ( path, str );
         //System.out.println ( path + " = " + str + "");
      }
   }

   /**
    * Сформировать строку полного пути.
    * @return  Полный путь до обьекта.
    */
   private  String   getPath ()
   {
      String   result   = "";
      // Получить полный список имен от начала
      Enumeration names = stack.elements ();
      while ( names.hasMoreElements () )
      {
         result += ( String ) names.nextElement () + SEPARATOR;
      }
      return   result;
   }

   /** Выдать результат распарсивания (Hashtable) */
   public Object getResult () throws Exception
   {
      if ( stopParsing )
      {
         if ( result.isEmpty () )
            throw new Exception ( "Result data is empty. May be - XML structure error." );
         else
            return result;
      }
      else
      {
         throw new Exception ( "XML structure error." );
      }
   }

   /**
    * Для тестирования обработчика.
    * <BR> Запуск: java Handle2Hashtable xml_file(s)
    */
   public static void main ( String[] args ) throws Exception
   {
      FileReader  fr;
      String      fileName;
      Hashtable   hb;
      Handle2Hashtable reporter = new Handle2Hashtable ();
      for ( int i = 0; i < args.length; i++ )
      {
         fileName    = args [ 0 ];
         System.out.println ( "===============================" );
         System.out.println ( "file: " + fileName );

         fr = new FileReader ( fileName );
         com.svj.xml.Parser.parse ( reporter, fr );

         fr.close ();

         hb = (Hashtable) reporter.getResult();
         System.out.println ( "Result: " + hb.toString() );
      }
   }

//==============================================================================

}
package com.svj.xml.handlers;


import java.util.*;
import java.io.FileReader;

import com.svj.xml.Handler;

/**
 * Распарсивает XML файл, выискивая значение только одного тэга, либо имени в тэге.
 * Остальные значения игнорируются.
 * <BR> Zhiganov Sergey.
 * <BR> 24 may 2004.
 */
public class HandleOneParam implements Handler
{

   /** Хранилище  для выдачи результата. */
   private  String    result;

   /* Имя тэга или аттрибута. */
   private  String   name  = "";

   /* Флаг, имя тэга (true) или аттрибута (false). */
   private  boolean  isTag = true;

   /** Флаг, что имя найденно - для поиска тэга. Т.к. в этом случае текст идет позже. */
   private  boolean  findName = false;

//============================================================================

   /**
    * Установить начальные значения.
    * @param   name   Имя элемента - тэга или аттрибута - для поиска.
    * @param   isTag  Тип элемента. TRUE - тэг, FALSE - аттрибут в тэге.
    */
   public   void init ( String name, boolean isTag )
   {
      this.name   = name;
      this.isTag  = isTag;
   }

    /**
    * Обнаружен тэг начала всего документа.
    */
   public void startDocument ()
   {
      result			= null;
   }

   /**
    * Обнаружен тэг окончания всего документа. Ничего не делать.
    */
   public void endDocument ()
   {
      //System.out.println ( "  end document" );
   }

   /**
    *  Найден начальный тэг. Сравнение имени тэга с заданным, если посик в тэге,
    * либо поиск заданного имени в спсике аттрибутов.
    *
    * @param   elem   Имя элемента (тэга).
    * @param   h      Список внутренних параметров этого элемента.
    */
   public void startElement ( String elem, Hashtable h )
   {
      String   str;
      if ( isTag )
      {
         // Искать как текст в тэге
         if ( name.equals (elem) )  findName = true;
      }
      else
      {
         // Искать в списке имен тэга.
         Enumeration en  = h.keys ();
         while ( en.hasMoreElements () )
         {
            str = ( String ) en.nextElement ();
            if ( name.equals ( str ) )
            {
               result   = (String) h.get ( str );
            }
         }
      }
   }

   /**
    * Найден конечный тэг. Если это заданный тэг, если это окончание нашего
    * тэга - выключить поиск, чтобы TEXT не взял чужой результат.
    *
    * @param elem   Имя тэга.
    */
   public void endElement ( String elem )
   {
      if ( name.equals (elem) )  findName = false;
      //System.out.println ( "    end elem: " + elem );
      // Удалить из стэка обьект если он там есть
   }

   /**
    * Значение тэга. Причем, если встречаются пустые тэги, то данный метод не
    * вызывается, и значит надо жестко отслеживать имя тэга в котором встретился
    * данный текст.
    * @param   text   Текстовое значение тэга.
    */
   public void text ( String text )
   {
      String   str;
      if ( isTag & findName )
      {
         // Удалить крайние пробелы и символы перевода строк
         str   = text.replace ( '\n', ' ' );
         str   = str.replace ( '\r', ' ' );
         str   = str.trim();
         result   = str;
         findName = false;
      }
   }


   /** Выдать результат распарсивания */
   public Object getResult ()
   {
      return (Object) result;
   }

   /**
    * Для тестирования обработчика.
    * <BR> Запуск: java HandleOneParam xml_file name isTag(y/n)
    * <BR> где  isTag = y - ищем по имени тэга, n - ищем по имени аттрибута в тэге.
    */
   public static void main ( String[] args ) throws Exception
   {
      FileReader  fr;

      if ( args.length < 3 )
      {
         System.out.println ( "Usage: java HandleOneParam xml_file name isTag(y/n)" );
         System.exit ( 1 );
      }

      boolean  is_tag;
      String   fileName = args [0];
      String   tName    = args [1];
      String   str      = args [2];

      if ( str.equalsIgnoreCase("y") )  is_tag   = true;
      else  is_tag   = false;

      System.out.println ( "===============================" );
      System.out.println ( "file: " + fileName );

      fr = new FileReader ( fileName );

      HandleOneParam reporter = new HandleOneParam ();
      reporter.init ( tName, is_tag );
      com.svj.xml.Parser.parse ( reporter, fr );

      fr.close ();

      str = (String) reporter.getResult();
      System.out.println ( "Result: " + str );
   }

//==============================================================================

}
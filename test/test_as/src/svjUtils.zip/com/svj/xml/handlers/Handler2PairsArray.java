package com.svj.xml.handlers;

import com.svj.xml.Handler;

import java.util.Hashtable;
import java.io.FileReader;

/**
 * Выделяет из XML документа вида:
 * <PRE>
   < get-info type="balance" phone-number="+79135555555">
	   < parameters>
         < parameter name="account" value="123456789"/>
         < parameter name="test" value="pw23-9"/>
	   < /parameters>
   < /get-info>
   < /PRE>
 * Массив параметров (parameters) вида name=value.
 * Складывает все это в Hashtable, где ключ - name.
 *
 * <BR> User: Zhiganov
 * <BR> Date: 26.08.2004
 * <BR> Time: 15:55:32
 */
public class Handler2PairsArray    implements Handler
{
   private String  tagName;
   private String  keyName;
   private String  valueName;

   private Hashtable result;

   /**
    * Конструктор.
    * @param tagName    Имя повторяющегося тэга (например: parameter).
    * @param keyName    Название в документе аттрибута для ключевого слова  (например: name).
    * @param valueName  Название в документе аттрибута для значения  (например: value).
    */
   public Handler2PairsArray ( String tagName, String keyName, String valueName )
   {
      this.tagName   = tagName;
      this.keyName   = keyName;
      this.valueName = valueName;
   }

   /**
    * Конструктор. Задает значения по умолчанию.
    * <BR> Имя повторяющегося тэга - parameter.
    * <BR> Название в документе аттрибута для ключевого слова - name.
    * <BR> Название в документе аттрибута для значения - value.
    */
   public Handler2PairsArray ()
   {
      this.tagName   = "parameter";
      this.keyName   = "name";
      this.valueName = "value";
   }

   public void startDocument () throws Exception
   {
      result			= new Hashtable ();
   }

   public void endDocument () throws Exception
   {
      //System.out.println ( "  end document" );
   }

   /**
    *  Найден начальный тэг.
    *
    * @param   elem   Имя элемента (тэга).
    * @param   h      Список внутренних параметров этого элемента.
    */
   public void startElement ( String elem, Hashtable h )
   {
      String   key, val;
      //System.out.println ( "    start elem: " + elem );

      if ( elem.equals(tagName))
      {
         // Найден наш тэг
         // - Выделяем имя ключа
         key   = (String) h.get ( keyName );
         // - Выделяем имя ключа
         val   = (String) h.get ( valueName );
         if ( (key != null) && (val != null) )     result.put ( key, val );
      }
   }

   /**
    * Найден конечный тэг.
    *
    * @param elem   Имя тэга.
    */
   public void endElement ( String elem )
   {
      //System.out.println ( "    end elem: " + elem );
   }

   /**
    * Значение тэга.
    * @param   text   Текстовое значение тэга.
    */
   public void text ( String text )
   {
   }

   public Object getResult () throws Exception
   {
      return result;
   }

//==============================================================================
   /**
    * Для тестирования обработчика. Можно обрабатываемые xml-файлы задавать списком,
    * через пробел.
    * <BR> Запуск: java Handler2PairsArray xml_file(s)
    */
   public static void main ( String[] args ) throws Exception
   {
      if ( args.length == 0 )
      {
         System.out.println ( "Use: java Handler2PairsArray xml_file_1 xml_file_2 ..." );
         System.exit ( 5 );
      }

      FileReader  fr;
      String      fileName;
      Hashtable   hb;
      Handler2PairsArray   reporter;

      reporter    = new Handler2PairsArray ( "parameter", "name", "value" );
      int   ic = args.length;
      System.out.println ( "Args size = " + ic );
      for ( int i = 0; i < ic; i++ )
      {
         fileName    = args [ i ];
         System.out.println ( "===============================" );
         System.out.println ( "File N=" + (i+1) + " : " + fileName );

         fr = new FileReader ( fileName );
         com.svj.xml.Parser.parse ( reporter, fr );

         fr.close ();

         hb = (Hashtable) reporter.getResult();
         System.out.println ( "Result : " + hb.toString() );
      }
      System.out.println ( "===============================" );
      reporter = null;
      hb       = null;
   }

//==============================================================================

}


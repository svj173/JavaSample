package com.svj.xml;

/**
 * Ошибка в файле конфигурации
 * <BR> <BR> User: Zhiganov <BR> Date: 05.07.2005
 * <BR> Time: 15:22:10
 */
public class TOException extends Exception
{
   public TOException ()
   {
      super ();
   }

   public TOException ( String message )
   {
      super ( message );
   }

   public TOException ( String message, Throwable cause )
   {
      super ( message, cause );
   }

   public TOException ( Throwable cause )
   {
      super ( cause );
   }

}

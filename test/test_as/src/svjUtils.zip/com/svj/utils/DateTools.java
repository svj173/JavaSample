package com.svj.utils;

import org.apache.log4j.Logger;

import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

/**
 * Сервисные утилиты по работе с датой.
 * <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 24.08.2005
 * <BR> Time: 14:15:53
 */
public class DateTools
{
    private static Logger logger = Logger.getLogger ( DateTools.class );


   /**
    * Расчитывает время между заданными значениями и
    * выдает результат в заданном строковом формате. Например: hh:MM:ss
    * @param startDate
    * @param endDate
    * @param resultFormat    String by "hh:mm:ss"
    * @return  result string as format
    */
   public static String intervalDate ( Date startDate, Date endDate, String resultFormat )
   {
      String   result;
      long ll          = endDate.getTime () - startDate.getTime ();
      int   interval = (int) ll / 1000; // get sec from milsec
      result  = sec2str ( interval, resultFormat );
      return result;
   }

   /**
    *  Перевести секунды в минуты и часы (hh:mm:ss) без округления секунд - для числа
    * Тип вывода - либо dd:hh:mm:ss, hh:mm:ss, mm:ss
    */
   public static String sec2str ( int lps1, String type )
   {

      int lps2, lps3, lps4, lps5;

      lps4 = lps5 = 0;
      lps2 = lps1 % 60;	// Секунды
      lps3 = lps1 / 60;	// Минуты

      if ( type.equals ( "mm:ss" ) )
      {
         return setFirstZero ( lps3 ) + ":" + setFirstZero ( lps2 );
      }
      if ( type.equals ( "hh:mm:ss" ) )
      {
         if ( lps3 > 59 )
         {
            // Если минуты больше 60, то выделить часы
            lps4 = lps3 / 60;
            lps3 = lps3 % 60;
         }
         return setFirstZero ( lps4 ) + ":" + setFirstZero ( lps3 ) + ":" + setFirstZero ( lps2 );
      }
      if ( type.equals ( "dd:hh:mm:ss" ) )
      {
         // Выделить дни
         if ( lps4 > 23 )
         {
            // Если часы больше 23, то выделить дни
            lps5 = lps4 / 24;
            lps4 = lps4 % 24;
         }
         return setFirstZero ( lps5 ) + ":" + setFirstZero ( lps4 ) + ":" +
              setFirstZero ( lps3 ) + ":" + setFirstZero ( lps2 );
      }
      return setFirstZero ( lps3 ) + ":" + setFirstZero ( lps2 );
   }

//----------------------------------------------------------------------------
/**
 *  Если число меньше десяти - то ставит 0 впереди в выходной строке - 020398.txt
 *
 * @param iprv    Искомое число.
 * @return        Строковое представление числа.
 */
   public static String setFirstZero ( int iprv )
   {
      String result;
      if ( iprv < 10 )
         result = "0" + iprv;
      else
         result = "" + iprv;
      return result;
   }

    /**
     * Выдать дату в стандартном виде: dd.MM.yyyy
     * @param date
     * @return string
     */
    public static String getStandartDate ( Date date )
    {
        return getPatternDate ( date, "dd.MM.yyyy" );
    }

    /**
     * Выдать время в стандартном виде: HH:mm:ss
     * @param date
     * @return string
     */
    public static String getStandartTime ( Date date )
    {
        return getPatternDate ( date, "HH:mm:ss" );
    }

    /**
     * Выдать время в виде: hh:mm
     * @param date
     * @return string
     */
    public static String getSimpleTime ( Date date )
    {
        return getPatternDate ( date, "HH:mm" );
    }

    /**
     * Выдать дату в виде: dd.MM.yyyy HH:mm:ss
     * @param date
     * @return string
     */
    public static String getFullDate ( Date date )
    {
        return getPatternDate ( date, "dd.MM.yyyy HH:mm:ss" );
    }

    /**
     * Выдать дату в виде: dd.MM.yyyy HH:mm
     * @param date
     * @return string
     */
    public static String getRussianDate ( Date date )
    {
        return getPatternDate ( date, "dd.MM.yyyy HH:mm" );
    }

    /**
     * Выдать дату в виде: yyyy-mm-dd hh:mm:ss.fffffffff
     * Это формат, который берет Timestamp.
     *  Т.е.  Timestamp tm  = new Timestamp (yyyy-mm-dd hh:mm:ss.fffffffff);
     * @param date
     * @return string
     */
    public static String getTimestamp ( Date date )
    {
        return getPatternDate ( date, "yyyy-MM-dd HH:mm:ss" );
    }

    /**
     * Форматирует дату согласно шаблону.
     * @param date
     * @param pattern  Шаблон вида dd.MM.yyyy HH:mm:ss
     * @return  Отформатирвоанная строка, содержащее дату
     */
    public static String getPatternDate ( Date date, String pattern )
    {
        String result;
        SimpleDateFormat fm = new SimpleDateFormat ( pattern );
        result = fm.format ( date );
        return result;
    }

    /*
    public static String getShortDate ( Calendar calendar )
    {
        String  result;
        result	        = setFirstZero( calendar.get(Calendar.DATE) ) + "."
                + setFirstZero( calendar.get(Calendar.MONTH)+1 )
                + "." + calendar.get ( Calendar.YEAR);
        return result;
    }
    */

    /**
    * get start date and end date of last day (dd.mm.yyyy hh:mm:ss.SSS)
    *
    * <BR>return result[0]	start date of last day
    * <BR>return result[1]	end date of last day
    * <BR>return result[2]	name of this function (for draw it in HTML page)
    *
    * @return result	String[] as array of result date (dd.mm.yyyy hh:mm:ss.SSS)
    */
    public static String[] getLastDay()
    {
        String[]    result;
        String      dat;
        Calendar    calendar;
        // ------------------- Last day
        calendar	  = new GregorianCalendar ();
        result	     = new String[2];
        calendar.add ( Calendar.DAY_OF_YEAR, -1 );
        dat	        = setFirstZero( calendar.get(Calendar.DATE) ) + "."
                + setFirstZero( calendar.get(Calendar.MONTH)+1 )
                + "." + calendar.get ( Calendar.YEAR);
        //String dat	= calendar.get ( Calendar.YEAR) + "-"
        //        + setFirstZero( calendar.get(Calendar.MONTH)+1 )
        //        + "-" + setFirstZero( calendar.get(Calendar.DATE) );
        result[0]	= dat + " 00:00:00.000";
        result[1]	= dat + " 23:59:59.999";
        return result;
    }

    /**
    * return current date in our format (24.08.2006 16:44).
    * @return String as current date (24.08.2006 16:44)
    */
    public static String getCurrentDate()
    {
        Calendar calendar;
        int ih, ip;
        String sh, smin, ssec, sdate, smonth, result;

        calendar	  = new GregorianCalendar();
        ih	    = calendar.get(Calendar.HOUR);
        ip	    = calendar.get(Calendar.AM_PM);
        if ( ip == Calendar.PM ) ih = ih + 12;
        sh		 = setFirstZero ( ih );
        smin	 = setFirstZero ( calendar.get(Calendar.MINUTE) );
        ssec	 = setFirstZero ( calendar.get(Calendar.SECOND) );
        sdate   = setFirstZero ( calendar.get(Calendar.DATE) );
        smonth	 = setFirstZero ( calendar.get(Calendar.MONTH) + 1 );
        result	 = sdate+"."+smonth+"."+calendar.get(Calendar.YEAR)+" "+ sh + ":" + smin + ":" + ssec + ".500";
        //result	 = calendar.get(Calendar.YEAR) + "-" + smonth + "-" + sdate + " " + sh + ":" + smin;
        return result;
    }

    /**
    * get start date and end date (as current date) of current day
     * (24.08.2006 00:00:00.000 - 24.08.2006 16:44:32.500 )
    *
    * <BR>return result[0]	start date of current day
    * <BR>return result[1]	end date (as current date) of current day
    * <BR>return result[2]	name of this function (for draw it in HTML page)
    *
    * @return result	String[] as array of result date
    */
    public static String[] getCurrentDay()
    {
        String[]    result;
        String      dat;
        Calendar    calendar;
        // ------------------- Current day
        calendar		= new GregorianCalendar();
        result	= new String[2];
        dat	        = setFirstZero( calendar.get(Calendar.DATE) ) + "."
                + setFirstZero( calendar.get(Calendar.MONTH)+1 )
                + "." + calendar.get ( Calendar.YEAR);
        result[0]	= dat + " 00:00:00.000";
        result[1]	= getCurrentDate();
        result[2]	= "Current day";
        return result;
    }

    /**
    * Преобразовать строку текстового формата в дату, используя шаблон.
    */
    public static Date getDate ( String date, String pattern  )
    {
        Date	result;
        result  = null;   // null?
        if ( date != null )
        {
            try
            {
                SimpleDateFormat	sdf	= new SimpleDateFormat ( pattern );
                result	= sdf.parse ( date );
            } catch ( Exception e )	{
                logger.error ( "Cannot parse string date by pattern. StringDate = "
                        + date + ", pattern = " + pattern, e );
            }
        }
        else
        {
            logger.error ( "String date for parse = NULL" );
        }
        return result;
    }

}

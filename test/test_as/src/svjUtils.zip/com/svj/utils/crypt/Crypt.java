package com.svj.utils.crypt;


import org.apache.log4j.Logger;

import java.io.*;
import java.util.Random;


/**
 * <PRE>
 * Шифрует имя или пароль, сохраняя их в заданном файле.
 * А также дешифрует из файла.
 * Т.е. задается результирующий файл и вводится какое-то имя (строка),
 * которая шифруется и сохраняется в заданном файле.
 *
 * Пример работы:
 * 1. Создать обьект.
 *    Crypt crpwd  = new Crypt();
 * 2. Установить новый ключ (необязательно).
 *    crpwd.setKey ( byte[] bkey );
 * 3. Зашифровать данные - data
 *    byte[] crypt_data = crpwd.crypt ( data );
 * 4. Сохранить в файле
 *    crpwd.saveToFile ( crypt_data, fileName );
 * </PRE>
 * <BR> Шифрует данные, введенные с консоли. Дешифрует - программно.
 * <BR>
 *
 * <BR> User: Zhiganov
 * <BR> Date: 03.11.2004
 * <BR> Time: 16:39:55
 */
public class Crypt
{
   private static Logger logger  = Logger.getLogger ( Crypt.class );

   private  String   file     = null;
   private  String   pwd      = null;

   /* Коэффициент увеличения шифрованного имени. */
   //private  int   count = 2;  //232;
   private  int   count = 232;  //232;

   /* Ключ по умолчанию, используемый при шифрации. Его можно менять извне. */
   private  byte[]   initKey =
           {  2, 5, 34,47,67, 32, 12,34,56,90,123,43,25,31,68,75,81,29, 20,11,
            101,95, 84,91,86, 94, 35,32,16,19, 40,70,68,45,37,83,57,82,116, 1,
             54,118, 3, 7,80,106,120, 4,61,27, 64,34,70,49,52,26,85,97,100, 9,
             83, 57,82,16, 1, 12, 34,56,90,13, 84,91,86,94,18,10, 4,78,  3, 7,
             80,119, 3, 7,80, 32, 12,34,56,90,123,43, 2,32,16,19,40,70, 68,45
           };

   private  int   radix = 256;

   public Crypt ()
   {
   }

   public void setKey ( byte[] key )
   {
      initKey  = key;
   }

   public byte[] getKey ()
   {
      return initKey;
   }

   /**
    * Ввести параметр с консоли.
    * @param trySize         Кол-во попыток ввода запрашвиаемых данных
    * @param requestMessage  Сообщение, выводимое в стркое запрсоа данных.
    */
   private String getParam ( int trySize, String requestMessage ) throws Exception
   {
      String result  = null;
      BufferedReader in = new BufferedReader( new InputStreamReader( System.in ) );
      PrintStream out = System.out;
      String str  = null;

      for ( int i=0; i<trySize; i++ )
      {
         out.print ( requestMessage + " (try is " + (i+1) + ") : " );
         try
         {
            result = in.readLine();
            if ( str != null )
            {
               if ( ! str.equals ( result) )
                  throw new Exception ( "Wrong parameter ! Try once more." );
            }
            else  str   = result;
         } catch ( IOException e )
         {
            out.println ( "Init. ERROR = " + e.getMessage () );
            e.printStackTrace ( out );
         }
      }
      return   result;
   }

   /**
    * Взять данные из аргументов командной строки.
    * @param args
    */
   private void setArgs ( String[] args )
   {
      try
      {
         file  = pwd = null;
         // Разобрать аргументы
         if ( args.length > 0 )   file       = args[0];
         if ( args.length > 1 )   pwd        = args[1];
         // Проверить на пропуск
         if ( file.equals ( "%1") )   file       = args[0];
         if ( args.length > 1 )   pwd        = args[1];

         // Если чего-то нет - ввести с клавиатуры. Причем имя и пароль - два раза.
         if ( file      == null )  file      = getParam ( 1, "File name" );
         if ( pwd       == null )  pwd       = getParam ( 2, "Crypt string" );

         // Write result
         logger.debug ( "File = " + file );
         //logger.debug ( "name = " + pwd );
      } catch ( Exception e )
      {
         System.out.println ( "ERROR = " + e.getMessage () );
         //e.printStackTrace ( System.out );
         System.exit ( 12 );
      }
   }

   /**
    * Прочитать файл с паролем. Расшифровать. Выдать результат.
    * Если ошибка - Exception.
    */
   public String load () throws Exception
   {
      logger.debug ( "load: Start" );
      String result   = "";
      int   i;

      try
      {
         // Загрузить файл
         File  f  = new File ( file );
         FileInputStream   fis   = new FileInputStream ( f );
         byte[] buf  = new  byte [(int)f.length ()];
         fis.read ( buf );

         // Расшифровать имя
         result   = decrypt ( buf );

      } catch ( Exception e )
      {
         System.out.println ( "Load. ERROR = " + e.getMessage () );
         //Slog.println ( "Load file ERROR", e );
         e.printStackTrace ( System.out );
         //System.exit ( 17 );
         throw e;
      } finally {
         logger.debug ( "load: Finish" );
      }

      // Выдать имя и пароль
      return   result;
   }

   public String decrypt ( byte[] pwd )   throws Exception
   {
      logger.debug ( "decrypt: Start" );
      String   result;
      int   i, j, pwdLen, blockLen;

      pwdLen   = pwd.length;
      blockLen = pwdLen / count;
      logger.debug ( "decrypt: pwdLen = " + pwdLen + ", blockLen = " + blockLen );
      if ( (pwdLen == 0) || (blockLen == 0) )
         throw new Exception ( "Decrypt: Result length is 0." );

      logger.debug ( "decrypt: create Key" );
      byte[] key  = new byte[blockLen];
      for (i=0; i<blockLen; i++)
         key[i]   = initKey[i];

      logger.debug ( "decrypt: Decrypt" );
      for (i = 0; i < pwdLen; i += blockLen)
      {
         for (j = 0; j < blockLen; j++)
         {
            key[j] ^= pwd[i+j];
         }
      }

      result   = new String ( key );
      logger.debug ( "decrypt: Finish" );
      return result;
   }

   /**
    * Зашифровать данные. Сохранить в файле.
    */
   private void save ()
   {
      byte[]   pwdName;
      logger.debug ( "save: Start" );

      try
      {
         // Crypt
         pwdName  = crypt ( pwd );
         logger.debug ( "pwd = " + printArray ( pwdName ) );
         // Save to file
         saveToFile ( pwdName );
      } catch ( Exception e )
      {
         System.out.println ( "Save. ERROR = " + e.getMessage () );
         System.exit ( 15 );
      }
      logger.debug ( "save: Finish" );
   }

   private void saveToFile ( byte[] pwdName )
           throws Exception
   {
      saveToFile ( pwdName, file );
   }

   public void saveToFile ( byte[] pwdName, String fileName )
           throws Exception
   {
      // Open file
      FileOutputStream  fos   = new FileOutputStream ( fileName );
      // Write to file pwd_name
      fos.write ( pwdName );
      //
      fos.flush ();
      fos.close ();
   }

   /**
    * Преобразовать integer в массив байт.
    *
    * @param length
    * @return массив
    */
   private byte[] getByteSize ( int length )
   {
      byte[]   result   = new byte[2];
      short slength  = (short) length;
      result[1] = (byte) (slength % radix);
      result[0] = (byte) (slength / radix);
      return result;
   }

   private String printArray ( byte[] array )
   {
      String   result   = "";
      String str;
      if ( array == null ) return   result;
      for (int i=0; i<array.length; i++ )
      {
         str      =  Integer.toHexString ( array[i] );
         if ( str.length () > 2 )   str   = str.substring ( str.length()-2);
         result   += str + " ";
      }
      return result;
   }

   public byte[] crypt ( String pname ) throws Exception
   {
      logger.debug ( "crypt: Start" );
      int   i, j;
      int   passLen  = pname.length ();
      int   initLen  = initKey.length;
      if ( passLen > initLen )
         throw new Exception ( "Password length too long (must be less then " + initLen + ")." );

      byte[]   result   = new byte [count * passLen];
      int   resultLen  = result.length;
      // Заполнить буфер случайной последовательностью
      Random   rand  = new Random ();
      rand.nextBytes ( result );
      // Занести в конец буфера пароль
      byte[]   bp = pname.getBytes ( );
      logger.debug ( "bp_name  = " + printArray ( bp ) );
      logger.debug ( "result (ish1) = " + printArray ( result ) );
      System.arraycopy ( bp, 0, result, resultLen-passLen, passLen );
      logger.debug ( "result (ish2) = " + printArray ( result ) );

      byte[] key  = new byte[passLen];
      for (i=0; i<passLen; i++)
         key[i]   = initKey[i];

      for (i = 0; i < resultLen; i += passLen)
      {
         for (j = 0; j < passLen; j++)
         {
            result[i+j] ^= key [j];
            key[j] ^= result[i+j];
         }
      }

      logger.debug ( "crypt: Finish" );
      return result;
   }

   public void setFile ( String fileName )
   {
      file  = fileName;
   }

//===============================================================================
   /**
    * Метод запрашивает значения необходимых параметров, шифрует и сохраняет в файле.
    *
    * @param args
    */
   public static  void main   ( String[] args )
   {
      // Читать аргументы
      //*
      if ( args.length < 1 )
      {
         System.out.println (
            "Usage: java -classpath svjUtil.jar com.svj.utils.crypt.Crypt [result_file_name] [text_for_crypt]" );
      }
      //*/

      logger.debug ( "main. Start" );

      try
      {
         Crypt  crypt = new Crypt ();
         crypt.setArgs(args);
         crypt.save();

         // TEST
         String result;
         result   = crypt.load();
         logger.debug ( "dec pwd = " + result );
         //logger.debug ( "dec password = " + result[1] );

         logger.debug ( "main. Finish" );
      } catch ( Exception e )
      {
         e.printStackTrace ();
      }
      System.exit ( 0 );
   }

//===============================================================================

}
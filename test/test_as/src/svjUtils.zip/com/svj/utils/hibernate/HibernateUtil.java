package com.svj.utils.hibernate;


import net.sf.hibernate.*;
import net.sf.hibernate.type.Type;
import net.sf.hibernate.cfg.*;

import java.util.List;
import java.io.Serializable;
import java.sql.Statement;

/**
 * User: dmb
 * Date: 30.07.2004
 * Time: 19:33:12
 */
public class HibernateUtil
{
    private static class SessionHolder
    {
        private Session session;
        private boolean locked;

        private Session getSession ()
        {
            return session;
        }

        private void setSession ( Session session )
        {
            this.session = session;
        }

        private boolean isLocked ()
        {
            return locked;
        }

        private void setLocked ( boolean locked )
        {
            this.locked = locked;
        }
    }

    private static final SessionFactory sessionFactory;
    private static final Configuration configuration;

    static
    {
        try
        {
            // Create the SessionFactory
            configuration = new Configuration ().configure ();
            sessionFactory = configuration.buildSessionFactory ();
        }
        catch ( HibernateException ex )
        {
            System.out.println ( ex );
            throw new RuntimeException ( "Hibernate configuration problem: " + ex.getMessage (), ex );
        }
    }

    public static final ThreadLocal sessionHolder = new ThreadLocal ();

    public static Configuration getConfiguration ()
    {
        return configuration;
    }

    public static Session currentSession () throws HibernateException
    {
        SessionHolder holder = ( ( SessionHolder ) sessionHolder.get () );

        // Open a new Session, if this Thread has none yet
        if ( holder == null )
        {
            holder = new SessionHolder ();
            holder.setSession ( sessionFactory.openSession () );
            sessionHolder.set ( holder );
        }
        return holder.getSession ();
    }

    public static Session lockSession () throws HibernateException
    {
        SessionHolder holder = ( ( SessionHolder ) sessionHolder.get () );

        // Open a new Session, if this Thread has none yet
        if ( holder == null )
        {
            holder = new SessionHolder ();
            holder.setSession ( sessionFactory.openSession () );
            sessionHolder.set ( holder );
        }

        holder.setLocked ( true );
        return holder.getSession ();
    }

    public static void closeSession () throws HibernateException
    {
        SessionHolder holder = ( SessionHolder ) sessionHolder.get ();
        if ( holder == null )
        {
            return;
        }

        if ( holder.isLocked () )
        {
            return;
        }

        sessionHolder.set ( null );

        Session s = holder.getSession ();
        if ( s != null )
        {
            holder.setSession ( null );
            s.close ();
        }
    }

    public static void unlockSession ()
    {
        SessionHolder holder = ( SessionHolder ) sessionHolder.get ();
        if ( holder == null )
        {
            return;
        }

        holder.setLocked ( false );
    }

    public static void unlockAndCloseSession () throws HibernateException
    {
        unlockSession ();
        closeSession ();
    }

    public static List retrieveAll ( Class cls )
    {
        Session ses = null;
        List res;

        try
        {
            ses = HibernateUtil.currentSession ();
            res = ses.find ( "from " + cls.getName () );
        }
        catch ( HibernateException e )
        {
            return null;
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
                return null;
            }
        }
        return res;
    }

    public static List retrieveAll ( Class cls, String orderBy )
    {
        Session ses = null;
        List res;

        try
        {
            ses = HibernateUtil.currentSession ();
            res = ses.find ( "from " + cls.getName () + " order by " + orderBy );
        }
        catch ( HibernateException e )
        {
            System.out.println ( e );
            return null;
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
                return null;
            }
        }
        return res;
    }

    public static Object load ( Class cls, Serializable id )
    {
        Session ses = null;
        Object res = null;
        try
        {
            ses = HibernateUtil.currentSession ();
            res = ses.load ( cls, id );
        }
        catch ( HibernateException e )
        {
            System.out.println ( e );
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
            }
        }
        return res;
    }

    public static boolean load ( Object target, Serializable id )
    {
        Session ses = null;

        try
        {
            ses = HibernateUtil.currentSession ();
            ses.load ( target, id );
        }
        catch ( HibernateException e )
        {
            return false;
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
                return false;
            }
        }
        return true;
    }

    public static boolean delete ( Object obj )
    {
        Session ses = null;
        Transaction tx = null;

        try
        {
            ses = HibernateUtil.currentSession ();
            tx = ses.beginTransaction ();
            ses.delete ( obj );
            tx.commit ();
        }
        catch ( HibernateException e )
        {
            try
            {
                tx.rollback ();
                return false;
            }
            catch ( Exception ex )
            {
            }
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
                return false;
            }
        }
        return true;
    }

    public static int delete ( String query, Object value, Type type )
    {
        Session ses = null;
        Transaction tx = null;
        int result = 0;

        try
        {
            ses = HibernateUtil.currentSession ();
            tx = ses.beginTransaction ();
            result = ses.delete ( query, value, type );
            tx.commit ();
        }
        catch ( HibernateException e )
        {
            try
            {
                tx.rollback ();
                return -1;
            }
            catch ( Exception ex )
            {
            }
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
                return -1;
            }
        }
        return result;
    }

    public static boolean delete ( Class clazz, Serializable id )
    {
        Session ses = null;
        Transaction tx = null;
        try
        {
            ses = HibernateUtil.currentSession ();
            tx = ses.beginTransaction ();

            Object obj = ses.load ( clazz, id );
            ses.delete ( obj );
            tx.commit ();
        }
        catch ( HibernateException e )
        {
            try
            {
                tx.rollback ();
                return false;
            }
            catch ( Exception ex )
            {
            }
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
                return false;
            }
        }
        return true;
    }

    public static boolean saveOrUpdate ( Object obj )
    {
        Session ses = null;
        Transaction tx = null;

        try
        {
            ses = HibernateUtil.currentSession ();
            tx = ses.beginTransaction ();
            ses.saveOrUpdate ( obj );
            tx.commit ();
        }
        catch ( HibernateException e )
        {
            try
            {
                tx.rollback ();
                return false;
            }
            catch ( Exception ex )
            {
            }
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
            }
        }
        return true;
    }

    public static List find ( String query )
    {
        Session ses = null;

        try
        {
            ses = HibernateUtil.currentSession ();
            return ses.find ( query );
        }
        catch ( HibernateException e )
        {
            System.out.println ( e );
            return null;
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
            }
        }
    }

    public static List find ( String query, Object value, Type type )
    {
        Session ses = null;

        try
        {
            ses = HibernateUtil.currentSession ();
            return ses.find ( query, value, type );
        }
        catch ( HibernateException e )
        {
            System.out.println ( e );
            return null;
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
            }
        }
    }

    public static List find ( String query, Object[] values, Type[] types )
    {
        Session ses = null;

        try
        {
            ses = HibernateUtil.currentSession ();
            return ses.find ( query, values, types );
        }
        catch ( HibernateException e )
        {
            System.out.println ( e );
            return null;
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( HibernateException e )
            {
            }
        }
    }

    public static int executeUpdate ( String sql )
    {
        Session ses = null;
        Transaction tx = null;
        int result;
        try
        {
            ses = HibernateUtil.currentSession ();

            tx = ses.beginTransaction ();

            Statement stm = ses.connection ().createStatement ();

            result = stm.executeUpdate ( sql );
            tx.commit ();
        }
        catch ( Exception e )
        {
            try
            {
                tx.rollback ();
            }
            catch ( Exception ex )
            {
                System.out.println ( ex );
                return 0;
            }
            System.out.println ( e );
            return 0;
        }
        finally
        {
            try
            {
                HibernateUtil.closeSession ();
            }
            catch ( Exception e )
            {
                System.out.println ( e );
            }
        }
        return result;
    }
}

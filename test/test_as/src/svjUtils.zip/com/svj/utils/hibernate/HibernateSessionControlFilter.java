package com.svj.utils.hibernate;

import net.sf.hibernate.Session;
import net.sf.hibernate.HibernateException;

import javax.servlet.*;
import java.io.IOException;

/**
 * User: dmb
 * Date: 16.11.2004
 * Time: 22:11:37
 */
public class HibernateSessionControlFilter implements Filter
{

    public void init ( FilterConfig filterConfig ) throws ServletException
    {
    }

    public void doFilter ( ServletRequest   servletRequest,
                           ServletResponse  servletResponse,
                           FilterChain      filterChain )
            throws IOException, ServletException
    {
        try
        {
            HibernateUtil.lockSession ();
            filterChain.doFilter ( servletRequest, servletResponse );
        }
        catch ( Throwable e )
        {
            e.printStackTrace ();
        }
        finally
        {
            try
            {
                HibernateUtil.unlockAndCloseSession ();
            }
            catch ( Throwable e )
            {
                e.printStackTrace ();
            }
        }
    }

    public void destroy ()
    {
    }

}

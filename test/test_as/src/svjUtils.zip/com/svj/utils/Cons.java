package com.svj.utils;

/**
 * <BR> Константы
 * <BR>
 * <BR> User: svj
 * <BR> Date: 10.03.2006
 * <BR> Time: 13:52:25
 */
public class Cons
{
    public static final String  SP          = "";
    public static final String  END_LINE    = "\r\n";
    public static final String  TAB         = "\t";
    /* Ключевое слово в значение XML тэга. Обозначает, что значение этого
      тэга хранится в файле в зашифрованном виде. Имя файла приводится далее,
      после этого ключевого слова.*/
    public static final String  FILE_KEY    = "file:";
}

package com.svj.utils;


import org.apache.log4j.Logger;

import java.util.StringTokenizer;
import java.net.Socket;
import java.io.*;

import javax.net.ssl.SSLSocket;

/**
 * Класс содержит различные утилиты.
 * <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 19.08.2005
 * <BR> Time: 10:27:58
 */
public class Utils
{
   private static final Logger log = Logger.getLogger(Utils.class);

   /**
    * Выдать информацию о текущей версии, исходя из данных о метке
    * в проекте (CVS tag - Name).
    * <BR>  Версия приходит в виде '_Name: mgate-rel-08-000-002 _'.
    *  Подчеркивание - на самом деле это символ параграфа. Причем первые
    *  буквы роли не играют, а парсятся только последние цифры - анализируя
    *  на разделительный символ (ообычно - тире).
    * <BR>  Например:
    *   getVersion ( '_Name: mgate-rel-08-000-002 _', '-', 3, '.' )
    * <BR>  Получим в результате: 8.0.2
    * <BR>  Zhiganov Sergey, 30 mar 2004.
    *
    * @param   versionTag  Исходная стркоа со строковой версией для распарсивания.
    * @param   sep  Разделитель между числами версии в исходной строке.
    * @param   size  Количество номеров в версии.
    * @param   resultSep  Итоговый разделитель. Используется при формировании
    *  результирующей строки.
    * @return   Информация о версии продукта.
    */
   public static String getVersion
           ( String versionTag, char sep, int size, char resultSep )
   {
      String   str;
      int      i, i2, i3;
      int[]    iVersion;

      try
      {
         // Проверки
         if ( size <= 0 )
            throw new Exception ( " Number version size error. Size = " + size );

         iVersion = new int[size];

         // Убрать  символы 'параграф', если есть.
         str   = versionTag.replace ( '$', ' ' );
         // Убрать крайние пробелы если они есть.
         str   = str.trim();

         // Найти индекс начальной последовательности номеров версий.
         i2 = str.length();
         for ( i=0; i<size; i++)
         {
            i3 = i2;    // for debug
            i2  = str.lastIndexOf ( sep, i2-1 );
            if ( i2 < 0 )
            {
               // Не нашли индекс - Ошибка
               throw new Exception ( " Cannot find start index. Source string = " + str
                       + ", Separator = " + sep + ", Size = " + size
                       + ", i3 = " + i3 + ", i = " + i );
            }
         }
         // Есть индекс.
         // - Выделяем подстроку, содержащую в себе одни толко номера версии через разделитель.
         str   = str.substring ( i2 );
         // - Разложить строку по разделителю
         StringTokenizer st	= new StringTokenizer ( str, ""+sep );
         // - Получить массив значений версий, подверсий и т.д.
         i  = 0;
         while ( st.hasMoreTokens() )
         {
            str	         = st.nextToken();
            iVersion[i]    = Integer.parseInt ( str );
            i++;
         }
         // сформировать строку результата. Исп итоговый разделитель
         str   = "";
         for ( i=0; i<size; i++ )   str   += "" + iVersion[i] + resultSep;
         // Убрать последний разделитель ?

      } catch ( Exception e )
      {
         log.error ( "ATTENTION! Unknow version. ", e );
         str   = "0.0";
      }

      return   str;

   }

   /**
    * Закрыть сокет. Освободить входной порт.
    * @param socket
    */
   public static Socket closeSocket ( Socket socket )
   {
      if ( socket != null )
      {
          /*
         try
         {
            socket.shutdownInput();
            socket.shutdownOutput ();
         } catch ( Exception e )      {
             log.debug ( "Shutdown input/output socket error", e );
         }
         */
         try
         {
            socket.close();
         } catch ( Exception e )      {
             log.debug ( "Close socket error", e );
         }
      }
      return null;
   }

    /**
     * Закрыть сокет. Освободить входной порт.
     * @param socket
     */
    public static SSLSocket closeSslSocket ( SSLSocket socket )
    {
       if ( socket != null )
       {
           /*
          try
          {
             socket.shutdownInput();
          } catch ( Exception e )      {  }
          */
          try
          {
             socket.shutdownOutput ();
          } catch ( Exception e )      {
              log.error ( "Close SSL Output error.", e );
          }
          try
          {
             socket.close();
          } catch ( Exception e )      {
            log.error ( "Close SSL socket error.", e );
          }
       }
       return null;
    }


   public static void flush ( OutputStream outputStream )
   {
      if ( outputStream == null )   return;
      try
      {
         outputStream.flush ();
      } catch ( IOException e )     {
          log.debug ( "Flush outputStream error", e );
      }
   }

    public static String printIntArray ( int[] array )
    {
        return printIntArray ( array, array.length );
    }

    public static String printIntArray ( int[] array, int size )
    {
        if ( array == null )    return "empty";
        StringBuffer    result  = new StringBuffer ( 512 );
        if ( size > array.length )  size = array.length;
        for ( int i=0; i<size; i++ )
        {
            result.append ( array[i] );
            result.append ( " ");
        }
        return result.toString ();
    }

    public static String printByteArray ( byte[] array )
    {
        if ( array == null )
            return "empty";
        else
            return printByteArray ( array, array.length );
    }

    public static String printByteArray ( byte[] array, int size )
    {
        if ( array == null )    return "empty";
        StringBuffer    result  = new StringBuffer ( 512 );
        if ( size > array.length )  size = array.length;
        for ( int i=0; i<size; i++ )
        {
            result.append ( array[i] );
            result.append ( " ");
        }
        return result.toString ();
    }

    public static String printByteArrayHex ( byte[] array )
    {
        if ( array == null )
            return "empty";
        else
            return printByteArrayHex ( array, array.length );
    }

    public static String printByteArrayHex ( byte[] array, int size )
    {
        if ( array == null )    return "empty";
        StringBuffer    result  = new StringBuffer ( 512 );
        if ( size > array.length )  size = array.length;
        for ( int i=0; i<size; i++ )
        {
            result.append ( getByteHex (array[i]) );
            result.append ( " ");
        }
        return result.toString ();
    }

    public static String getHex ( int ic )
    {
        String result;
        result   = Integer.toHexString ( ic );
        return result;
    }

    public static String getByteHex ( int ic )
    {
        String result;
        int     i;
        result  = Integer.toHexString ( ic );
        i       = result.length ();
        if ( i > 2 )
        {
            result  = result.substring ( i-2 );
        }
        return result;
    }

    /**
     * @deprecated Перенес в StringTools
     * @param array
     * @return строка
     */
    public static String printStringArray ( String[] array )
    {
        if ( array == null )    return "empty";
        StringBuffer    result  = new StringBuffer ( 512 );
        for ( int i=0; i<array.length; i++ )
        {
            result.append ( "'" );
            result.append ( array[i] );
            result.append ( "', ");
        }
        return result.toString ();
    }

    /**
     * Найти одну из заданных строк в другой строке, игнорируя регистр букв.
     * @param source
     * @param find искомая строка
     * @param from номер позиции в строке, с которой нужно начинать поиск
     * @return номер позиции в строке, или -1, если не найдено
     */
    public static int indexOfIgnoreCase (String source, String find[], int from) {
      int indexTo = source.length() - 1;
      for (int i = from; i <= indexTo; i++) {
        for (int j = 0; j < find.length; j++) {
          if (source.length() - i >= find[j].length()) {
            if (source.substring(i, i + find[j].length()).equals(find[j])) return i;
          }
        }
      }
      return -1;
    }

    /**
     * Найти строку в другой строке, игнорируя регистр букв
     * @param source
     * @param find искомая строка
     * @param from
     * @return индекс, или -1, если не найдено
     */
    public static int indexOfIgnoreCase(String source, String find, int from) {
      if (source == null || find == null) return -1;
      int indexTo = source.length() - find.length();
      if (indexTo < 0) return -1;
      for (int i = from; i <= indexTo; i++) {
        if (source.substring(i, i + find.length()).equals(find)) return i;
      }
      return -1;
    }


/*

   public static void closeInput ( InputStream inputStream )
   {
      if ( inputStream == null )   return;
      try
      {
         inputStream.close ();
      } catch ( IOException e )
      { }
   }


   public static void closeOutput ( OutputStream outputStream )
   {
      if ( outputStream == null )   return;
      try
      {
         outputStream.close ();
      } catch ( IOException e )
      {  }
   }
*/
   /*
   public static String createSpec ( String spec, long num )
   {
      StringBuffer   result   = new StringBuffer ( 16 );
      result.append ( spec );
      result.append ( '_' );
      result.append ( num );
      result.append ( '}' );
      return   result.toString ();
   }
   */

   /**
    * Работа с шаблонами. Привязка в тексте шаблона макросов к обьекту и его методам 'get'.
    * @param doc
    * @param templateFile
    * @return
    */
/*  public static String loadString(Object doc, String templateFile) {
      String out = "";
      VelocityContext context = VelocityHelper.newContext(false);
//       context.put("SU", new StringUtils());
//       context.put("DU", new DateUtils());

      if (doc != null) {
        context.put("DOC", doc);
      }

      StringWriter sw = new StringWriter();
      try {
        log.debug(
          "templateFile=" + templateFile + " input.encoding=" + (String) Velocity.getProperty("input.encoding") +
          " file.resource.loader.path=" + Velocity.getProperty("file.resource.loader.path")
        );
        Velocity.mergeTemplate(templateFile, (String) Velocity.getProperty("input.encoding"), context, sw);
      } catch (Exception e) {
        log.error("error while merge templates message=", e);
      }
      out = sw.getBuffer().toString();
      log.debug("made velocity message=" + out);
      return out;
   }
*/
//===============================================================================
   /**
    * Для тестирования утилитных процедур.
    *
    * @param args
    */
   public static void main ( String[] args )
   {
      System.out.println ( "=================================================" );
      System.out.println ( "Utils:: START." );
      if ( args.length < 1 )
      {
         System.out.println ( "USAGE:  java  com.cft.simmp.utils.Utils  type" );
         System.out.println ( "\ttype:" );
         System.out.println ( "\t - version\t- getVersion utility test." );
         System.exit ( 1 );
      }

      if ( args[0].equals ( "version" ))
      {
         String   nameTag  = "$Name:  $";
         String   version  = "UTILS " + Utils.getVersion ( nameTag, '-', 3, '.' )
                       + " (" + nameTag + ", $Date: 2005/08/22 10:02:01 $)";
         System.out.println ( version );
      }
   }

//============================================================================

}

package com.svj.utils;

/**
 * ��������� �������.
 * User: svj
 * Date: 27.11.2006
 * Time: 9:58:11
 */
public class SystemTools
{

    public static void runGc()
    {
        Runtime.getRuntime().gc();
    }

    public static long getFreeMemory()
    {
        long result;
        result  = Runtime.getRuntime().freeMemory();
        return result;
    }

    public static long getMaxMemory()
    {
        long result;
        result  = Runtime.getRuntime().maxMemory();
        return result;
    }

    public static long getTotalMemory()
    {
        long result;
        result  = Runtime.getRuntime().totalMemory();
        return result;
    }

    public static String getMemoryInfo()
    {
        StringBuffer result;
        result  = new StringBuffer(128);
        result.append ( "Memory : max = " );
        result.append ( Runtime.getRuntime().maxMemory() );
        result.append ( ", total = " );
        result.append ( Runtime.getRuntime().totalMemory() );
        result.append ( ", free = " );
        result.append ( Runtime.getRuntime().freeMemory() );
        return result.toString();
    }


}

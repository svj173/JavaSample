package com.svj.utils;


import java.util.Hashtable;
import java.util.Enumeration;
import java.net.URL;
import java.net.MalformedURLException;

import org.apache.log4j.Logger;
import com.svj.utils.ssl.SSLCons;

import javax.servlet.http.HttpServletRequest;

/**
 * Сервисные утилиты по различным преобразованиям для работы с HTML.
 * <BR> <BR> User: Zhiganov <BR> Date: 25.08.2005 <BR> Time: 12:17:00
 */
public class HtmlTools
{
   private static final Logger logger = Logger.getLogger(HtmlTools.class);


   /**
    * Из набора пар-параметров создать строку POST запроса.
    * @param params    пары параметров. Key - имя параметра, Value - значение параметра.
    * @return  string
    */
   public static String  createDataRequest ( Hashtable params )
   {
      String   result   = "";
      String   par, value;
      Enumeration enumeration = params.keys ();
      while ( enumeration.hasMoreElements () )
      {
         par   = ( String ) enumeration.nextElement ();
         value = (String) params.get ( par );
         result += "&";
         result += par;
         result += "=";
         result += value;
      }
      // Удалить первый символ '&'
      result   = result.substring ( 1 );
      return result;
   }

   public static String createPostRequest ( String strUrl, Hashtable header, Hashtable data )
        throws SvjException
   {
      URL url = createHttpsUrl ( strUrl );
      return   createPostRequest ( url, header, data );
   }

   public static String createPostRequest ( String strUrl, String request )
        throws SvjException
   {
      URL url = createHttpsUrl ( strUrl );
      StringBuffer headerbuf = new StringBuffer();

      // Положить в буфер исходные значения
      headerbuf.append ( SSLCons.HEADER_POST );
      headerbuf.append ( " " );
      headerbuf.append ( url.getFile() );  // toString()
      headerbuf.append ( " HTTP/1.0\r\n" );
      headerbuf.append ( SSLCons.HEADER_CONTENT_LENGTH );
      headerbuf.append ( ": " );

      //headerbuf.append ( request.getContentLength() );
      headerbuf.append ( request.length() );
      headerbuf.append ( SSLCons.END_LINE );
      headerbuf.append ( SSLCons.END_LINE );
      headerbuf.append ( request );
      headerbuf.append ( SSLCons.END_LINE );

      return headerbuf.toString ();
   }

   /**
    * Инкапсулировать запрос в POST-header.
    * URL = https://www.ntcgsm.ru/rp/cgi-bin/cgi.exe
    * request = p_field=lang&p_value=RUS&p_field=user
    * @param header Параметры заголовка
    * @param data   Параметры данных
    * @return  Сформированная строка
    */
   public static String createPostRequest ( URL url, Hashtable header, Hashtable data )
   {
      // Сформировать POST запрос.
      // Создать буфер, где будет хранится заголовок
      StringBuffer headerbuf = new StringBuffer();
      String   dataRequest;
      // Положить в буфер исходные значения
      headerbuf.append ( SSLCons.HEADER_POST );
      headerbuf.append ( " " );
      headerbuf.append ( url.getFile() );  // toString()
      headerbuf.append ( " HTTP/1.0\r\n" );
      /*
      // Если через проксю. здесь адрес удаленного хоста
      headerbuf.append ( HEADER_HOST );
      headerbuf.append ( ": " );
      headerbuf.append ( url.getHost() );
      headerbuf.append ( ':' );
      headerbuf.append ( port );
      headerbuf.append ( "\r\n" );
      */
      /*
      headerbuf.append ( HEADER_CONTENT_TYPE );
      headerbuf.append ( ": " );
      //headerbuf.append ( request.getContentType() );
      String	contentType	= HEADERVAL_CONTENT_TYPE_DEFAULT;
      headerbuf.append ( contentType );
      headerbuf.append ( "\r\n" );
      */
      headerbuf.append ( SSLCons.HEADER_CONTENT_LENGTH );
      headerbuf.append ( ": " );

      // Сформировать данные
      if ( data != null )
         dataRequest = createDataRequest ( data );
      else
         dataRequest = "";

      //headerbuf.append ( request.getContentLength() );
      headerbuf.append ( dataRequest.length() );
      headerbuf.append ( SSLCons.END_LINE );
      headerbuf.append ( SSLCons.END_LINE );
      headerbuf.append ( dataRequest );
      headerbuf.append ( SSLCons.END_LINE );

      return headerbuf.toString ();
   }

   public static URL createHttpsUrl ( String url ) throws SvjException
   {
      URL   httpsUrl;
      // Создать возможность работы урла с протоколом https
      String   pkgs, protocol;
      pkgs     = "java.protocol.handler.pkgs";
      protocol = "com.sun.net.ssl.internal.www.protocol";
      String urlHandlerProp = System.getProperty ( pkgs, "" );
      if ( urlHandlerProp.indexOf ( protocol ) < 0 )
      {
         if ( urlHandlerProp.length () > 0 )   urlHandlerProp = urlHandlerProp + '|';
         System.setProperty ( pkgs, urlHandlerProp + protocol );
      }
      try
      {
         httpsUrl   = new URL ( url );
      } catch ( MalformedURLException e )
      {
         throw new SvjException ( "URL error. Url = " + url, e );
      }
      return   httpsUrl;
   }

   public String createGetRequest ( URL url, String dataRequest )
   {
      logger.debug ( "Start.");

      // ------------ POST -------------------------
      // Construct the HTTP header - создать заголовок запроса.
      // Создать буфер, где будет хранится заголовок
      String headerbuf = "";
      // Положить в буфер исходные значения
      headerbuf += "GET ";
      headerbuf += "https://";
      headerbuf += url.getHost ();
      headerbuf += ":";
      headerbuf += url.getPort ();
      headerbuf += url.getFile ();
      headerbuf += "?";

      headerbuf += dataRequest ;
      headerbuf += " HTTP 1.1" ;      //  HTTP/1.0

      // ??
      //headerbuf += "\r\n" ;
      //headerbuf += "Authorization: Basic " + authorization;

      headerbuf += "\r\n\r\n" ;

      logger.debug ( " Data = " + headerbuf );
      logger.debug ( "Finish.");
      return   headerbuf;
   }

    public static String dumpRequest ( HttpServletRequest r )
    {
        //int ic;
      StringBuffer result = new StringBuffer("request parameters:");
      for (Enumeration k = r.getParameterNames(); k.hasMoreElements();)
      {
        String paramName = (String) k.nextElement();
        String[] paramValues = r.getParameterValues(paramName);
        if (paramValues != null)
        {
            for (String paramValue : paramValues)
            {
                result.append("\n");
                result.append(paramName);
                result.append("=");
                result.append(paramValue);
            }
        }
      }
      return result.toString();
    }


}

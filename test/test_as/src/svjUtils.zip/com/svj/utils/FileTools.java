package com.svj.utils;


import org.apache.log4j.Logger;

import java.io.*;
import java.util.Properties;

/**
 * Сервисные утилиты по работе с файлами и их именами.
 * <BR> <BR> User: Zhiganov <BR> Date: 24.08.2005 <BR> Time: 14:19:32
 */
public class FileTools
{
    private static final Logger logger = Logger.getLogger(FileTools.class);


   /**
    * Создать полное имя файла - с абсолютным путем.
    * @param fileName   Имя файла
    * @param path       Абсолютный путь
    * @return  Полное имя файла
    */
   public static String createFileName ( String fileName, String path )
   {
      if ( fileName.startsWith ( "/") || (fileName.indexOf ( ':') > 0 ) )
      {
         // Это абсолютный путь - взять как есть
         return fileName;
      }
      else
      {
         // Добавить абс путь
          String sep    = "/";     // добавить разделитель если необходимо
          if ( path.endsWith ( "/")     || path.endsWith ( "\\") )     sep    = "";
          return path + sep + fileName;
      }
   }

    /**
     * Прочитать файл с текстом. Выдать результат.
     * Если ошибка - Exception.
     */
    public static String loadFile ( String fileName ) throws Exception
    {
        return loadFile ( fileName, null );
    }


    /**
     * Прочитать файл с текстом. Выдать результат.
     * Если ошибка - Exception.
     */
    public static String loadFile ( String fileName, String codePage ) throws Exception
    {
       logger.debug ( "Start loadFile: Name = " + fileName );
       String result   = "";

       try
       {
          // Загрузить файл
          File  f  = new File ( fileName );
          FileInputStream   fis   = new FileInputStream ( f );
          byte[] buf  = new  byte [(int)f.length ()];
          fis.read ( buf );
          //
          if ( codePage == null )
              result   = new String ( buf );
          else
              result   = new String ( buf, codePage );

       } catch ( Exception e )
       {
          logger.error ( "Load. ERROR = " + e.getMessage (), e );
          throw e;
       } finally {
          logger.debug ( "load: Finish" );
       }

       return   result;
    }

    public static Properties loadProperties ( String fileName ) throws SvjException
    {
       Properties  result   = new Properties ( );
       FileInputStream   fis;
       try
       {
           fis   = new FileInputStream ( fileName );
           if ( fileName.endsWith ( "xml"))
           {
               // XML файл
               result.loadFromXML ( fis );
           }
           else
           {
               // Текстовый файл
               result.load ( fis );
           }
       } catch ( Exception e )
       {
          //logger.error ()
          throw new SvjException ( "Load file '" + fileName + "' properties error", e);
       }
       return result;
    }

    /**
     * Прочитать ява-обьект из файла.
     * @param fileName
     * @return
     * @throws Exception
     */
    public static Object loadObject ( String fileName ) throws Exception
    {
        Object      result;
        FileInputStream    fis;
        ObjectInputStream  ois;

        fis     = new FileInputStream(fileName);
        ois     = new ObjectInputStream(fis);
        result  = ois.readObject ();
        ois.close ();

        return  result;
    }

    /**
     * Сохранить ява-обьект в файле.
     * @param fileName
     * @param object
     * @throws Exception
     */
    public static void save ( String fileName, Object object ) throws Exception
    {
        FileOutputStream    fos;
        ObjectOutputStream  oos;

        fos = new FileOutputStream(fileName);
        oos = new ObjectOutputStream(fos);

        //oos.writeInt(12345);
        oos.writeObject(object);
        oos.close();
    }

    /**
     * Сохранить текст в файле.
     * @param fileName
     * @param text
     * @throws Exception
     */
    public static void save ( String fileName, String text ) throws Exception
    {
       FileWriter   fw;

       fw  = new FileWriter ( fileName );
       // Записать в основной
       fw.write ( text );
       fw.flush();
       fw.close();
    }

    public static void saveWithTmp ( File file, StringBuffer text ) throws Exception
    {
       FileWriter              fw, tmp;
       String   str;
       // Создать промежуточный
       str   = file.getAbsoluteFile() + ".tmp";
       tmp = new FileWriter ( str );
       // Записать в промежуточный
       tmp.write ( text.toString () );
       tmp.close();
       // Создать основной
       fw = new FileWriter ( file );
       // Записать в основной
       fw.write ( text.toString () );
       fw.close();
       // TODO в конце работы промежуточный файл удалить
    }

}

package com.svj.utils;

/**
 * <BR> <BR> User: Zhiganov <BR> Date: 18.08.2005 <BR> Time: 11:03:45
 */
public class SvjException extends Exception
{
    /* Внутренний код ошибки. */
   protected int status;


   public SvjException ( int status, String mess )
   {
      super ( mess );
      this.status = status;
   }

   public SvjException ( String mess )
   {
      super ( mess );
   }

   public SvjException ( int status, String message, Throwable cause )
   {
      super ( message, cause );
      this.status = status;
   }

   public SvjException ( String message, Throwable cause )
   {
      super ( message, cause );
   }

}

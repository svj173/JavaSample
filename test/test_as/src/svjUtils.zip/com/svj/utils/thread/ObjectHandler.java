package com.svj.utils.thread;


import org.apache.log4j.Logger;

import java.util.Stack;

/**
 * <BR> В бесконечном цикле ждет появления обьекта. Как только обьект появился,
 * он складывается в очередь, а обработчик будится.
 * <BR> Обработчик  в цикле тянет обьекты из очереди (вдруг пока обрабатывал первый
 * обьект, появились еще несколько?). Как только очередь опустошается - обработчик засыпает.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 09.06.2006
 * <BR> Time: 16:49:19
 */
public abstract class ObjectHandler  extends Thread
{
    private static Logger logger = Logger.getLogger ( ObjectHandler.class );

    private boolean started     = false;

    private Object  newObject   = new Object ();

    private Stack   queue       = new Stack ();


//===============================================================================

    /** Обработать полученный обьект. */
    public abstract  void  handle ( Object object );

    /** Прежде чем запустить эту нить, ждать когда поднимется какой-то сторонний важный 
     * процесс. Например, стартует сервер. */
    public abstract  void  waitRunning ();

    /** Обработать ошибку, возникшую во время выполнения метода handle. */
    public abstract  void  handleError ( Exception exc );


    public void publish ( Object object )
    {
        logger.debug ( "Start. Name = " + getName() );

        if ( object == null )
        {
            logger.error ( "Object is NULL" );
        }

         // Процессор находится в ожидании - Положить сообщение на обработку и встряхнуть Процессор.
         synchronized ( newObject )
         {
             //if ( queue == null )   queue   = new Stack ();
             queue.push ( object );
             logger.debug ( "Waking up sleeping thread" );
             newObject.notify ();
         }
         logger.debug ( "Finish" );
    }


    public void startHandler ()
    {
        logger.debug ( "Start." );
        //if ( queue == null )   queue   = new Stack ();
        if ( ! started )
        {
            started = true;
            start ();
        }
        else
        {
            logger.error ( "Process already started." );
        }
        logger.debug ( "Finish." );
    }

    public void stopHandler ()
    {
        logger.debug ( "Start." );
        started = false;
        this.interrupt ();
        logger.debug ( "Finish." );
    }


    public void run ()
    {
        Object  object;

        logger.debug ( "Start." );
        // Ждать когда поднимется какой-то важный процесс. Например, стартует сервер.
        waitRunning();
        logger.debug ( "Start: thread '" + this + "' is running. Started = " + started );

        while ( started )
        {
            try
            {
                synchronized ( newObject )
                {
                    while ( queue.empty() )
                    {
                        logger.debug ( "Wait new Object" );
                        newObject.wait ();
                        logger.debug ( "Woken up on new Object" );
                    }
                    object = queue.pop ();
                    logger.debug ( "Get new Object = " + object );
                    if ( object == null )   continue;
                }

                // Обработать
                handle ( object );

            //} catch ( InterruptedException ex )    {
            //    logger.debug ( "Interrupted", ex );
            } catch ( Exception exc )              {
                handleError ( exc );
                logger.error ( "Error", exc );
            }
        }
        logger.info ( "Finish: thread '" + this + "' terminated." );
    }

}

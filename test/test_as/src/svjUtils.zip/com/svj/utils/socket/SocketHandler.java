package com.svj.utils.socket;

import org.apache.log4j.Logger;

import java.net.Socket;

/**
 * <BR> Интерфейс обработчика входящих сокетов.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 05.06.2006
 * <BR> Time: 15:45:46
 */
public abstract class  SocketHandler   implements Runnable
{
    private static Logger logger = Logger.getLogger ( SocketHandler.class );

    private boolean busy    = false;
    private boolean started = false;

    private Socket  socket  = null;

    /* Имя процесса. */
    private String  name    = "Process";

    private Object  newSocket   = new Object ();

    private Thread  thread   = null;


//===============================================================================

    public abstract  void  handle ( Socket socket );


    public void publish ( Socket socket )
    {
        synchronized ( newSocket )
        {
           this.socket    = socket;
           logger.debug ( "Waking up sleeping thread" );
           newSocket.notify ();
        }
    }

    public boolean isFree ()
    {
        return (! busy);
    }

    public void start ()
    {
        logger.debug ( "Start" );
        if ( ! started )
        {
            started = true;
            thread  = new Thread ( this, name );
            thread.setDaemon ( true );
            thread.start ();
        }
        logger.debug ( "Finish" );
    }

    public void stop ()
    {
        started = false;
        synchronized ( newSocket )
        {
            // Разбудить процессы, чтобы они завершились.
            newSocket.notify ();
        }
    }

    public void setBusy ()
    {
        busy    = true;
    }

    public void setFree ()
    {
        logger.debug ( "Set FREE Handler" );
        busy    = false;
    }

    public void run ()
    {
        logger.info ( "Start: thread '" + this + "' is running." );
        while ( started )
        {
            try
            {
                synchronized ( newSocket )
                {
                    while ( socket == null )
                    {
                        logger.debug ( "Wait new Socket" );
                        newSocket.wait ();
                        logger.debug ( "Woken up on new Socket" );
                        if ( ! started )
                        {
                            // Server is down. Stoping work.
                            logger.info ( "Server is down. Stoping work." );
                            return;
                        }
                    }
                    logger.debug ( "Get new Socket." );
                }

                // Обработать
                setBusy ();
                handle ( socket );

            } catch ( InterruptedException ex )
            {
                logger.error ( "Error", ex );
            } catch ( Exception ex )
            {
                logger.error ( "Error", ex );
            } finally
            {
                socket = closeSocket ( socket );
                setFree ();
            }
        }
        logger.info ( "Finish: thread '" + this + "' terminated." );
    }

    /**
     * Закрыть сокет. Освободить входной порт.
     * @param socket
     */
    private Socket closeSocket ( Socket socket )
    {
       if ( socket != null )
       {
          try
          {
              socket.close();
          } catch ( Exception e )      {
              logger.error ( "Close socket error.", e );
          }
       }
       return null;
    }

    public void setName ( String name )
    {
        this.name = name;
    }

    public String getName ()
    {
        return name;
    }

    public Thread   getThread()
    {
        return thread;
    }
    
}

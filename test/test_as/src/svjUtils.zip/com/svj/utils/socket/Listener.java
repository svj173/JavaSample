package com.svj.utils.socket;

import org.apache.log4j.Logger;

import java.net.ServerSocket;
import java.net.Socket;
import java.security.AccessControlException;
import java.io.IOException;
import java.util.Hashtable;

import com.svj.utils.ssl.SslManager;
import com.svj.utils.Utils;


/**
 * <BR> Обьект слушает порт, получает сокет, который передает в пул обработчиков,
 * свободному обработчику.
 * <BR> Закончив работу, обработчик сам устанавливает себя в состояние "Свободен".
 * <BR>
 * <BR> User: svj
 * <BR> Date: 05.06.2006
 * <BR> Time: 15:44:30
 */
public class Listener extends Thread    //implements Runnable
{
    private static Logger logger = Logger.getLogger ( Listener.class );

    private boolean tcpNoDelay = true;

    private ServerSocket serverSocket;

    /* Timeout value on the incoming connection. Note : a value of 0 means no timeout.*/
    private int connectionTimeout = 60000;

    /* The port number on which we listen for input requests from Merchant. */
    private int     port;

    private boolean started = false;

    /* Флаг запуска процесса останова Модуля. По нему происходит запрет
    увеличения пула процессов.*/
    //private boolean shutdown = false;

    private SocketHandlersPool pool;

    private SslManager ssm  = null;


    public Listener ( String processName ) throws Exception
    {
        logger.debug ( "Start" );
        setName ( processName );
        started     = true;
        ssm         = null;
        logger.debug ( "Finish" );
    }

    public void init ( SocketHandlersPool pool, int timeout, int port, Hashtable ssl )
            throws Exception
    {
        logger.debug ( "Start ("+getName()+":"+port+")." );
        this.pool           = pool;
        this.port           = port;
        connectionTimeout   = timeout;

        if ( ssl != null )
        {
            // SSL connect
            initSsl(ssl);
        }
        else
        {
            // Simple connect
            logger.info ( "Create PLAIN server socket. ("+getName()+":"+port+")." );
            serverSocket = new ServerSocket ( port );
        }
        logger.debug ( "Finish ("+getName ()+")." );

    }

    private void initSsl ( Hashtable ssl ) throws Exception
    {
        logger.debug ( "Start ("+getName()+":"+port+")." );

        try
        {
            // используется SSL соединение
            logger.info ( "Create SSL server socket ("+getName()+":"+port+")." );
            String ksFile, ksType, ksPassw, trFile, trType, trPassw, type;
            //TreeObject key, trusted;

            // Key
            ksFile  = ( String ) ssl.get ( "ksFile" );
            ksPassw = ( String ) ssl.get ( "ksPassw" );
            ksType  = ( String ) ssl.get ( "ksType" );
            //logger.debug ( "ksFile = " + ksFile + ", ksPassw = " + ksPassw + ", ksType = " + ksType );

            // Trust
            trFile  = ( String ) ssl.get ( "trFile" );
            trPassw = ( String ) ssl.get ( "trPassw" );
            trType  = ( String ) ssl.get ( "trType" );
            //logger.debug ( "trFile = " + trFile + ", trPassw = " + trPassw + ", trType = " + trType );


            type    = ( String ) ssl.get ( "type" ); // SSL, TLS
            ssm     = new SslManager ( ksFile, ksPassw, ksType, trFile, trPassw, trType, type );
            serverSocket = ssm.getServerSocket ( port );
            //( ( javax.net.ssl.SSLServerSocket ) serverSocket ) .setWantClientAuth ( false );
            ( ( javax.net.ssl.SSLServerSocket ) serverSocket ).setNeedClientAuth ( false );

            logger.debug ( "Created server socket ("+getName()+":"+port+")." );

        } catch ( Exception ioe )
        {
            logger.error ( "Listener.initialize ("+getName()+":"+port+"): TCPConnector, io problem: "
                    + ioe.getMessage (), ioe );
            throw new Exception ( "Listener:: ServerSocket.open " + ioe.toString () );
        }

        logger.debug ( "Finish ("+getName()+":"+port+")." );
    }

    public void run ()
    {
        Socket          socket;
        SocketHandler   handler;

        // Loop until we receive a shutdown command
        while ( started )
        {
            logger.debug ( "Start listen incoming port. ("+getName()+":"+port+")." );
            // Accept the next incoming connection from the server socket
            //socket;
            try
            {
                socket = serverSocket.accept ();
                logger.debug ( "Get new socket  ("+getName()+":"+port+")." );
                if ( connectionTimeout > 0 )
                {
                    logger.debug ( "Set socket timeout = " + connectionTimeout + " msec." );
                    socket.setSoTimeout ( connectionTimeout );
                }
                socket.setTcpNoDelay ( tcpNoDelay );
                logger.debug ( "("+getName()+":"+port+"). InetAddress = " + socket.getInetAddress () );
                logger.debug ( "("+getName()+":"+port+"). RemoteSocketAddress = " + socket.getRemoteSocketAddress () );
            } catch ( AccessControlException ace )
            {
                logger.error ( "("+getName()+":"+port+") Socket accept security exception" + ace.getMessage (), ace );
                continue;
            } catch ( IOException e )
            {
                try
                {
                    serverSocket.close ();
                    if ( ssm == null )
                        serverSocket = new ServerSocket ( port );
                    else
                        serverSocket = ssm.getServerSocket ( port );

                } catch ( IOException ioe )
                {
                    logger.error ( "("+getName()+":"+port+") Socket reopen, io problem: " + ioe.getMessage (), ioe );
                    break;
                }
                continue;
            } catch ( Throwable te )
            {
                logger.error ( "("+getName()+":"+port+") Big error !!!", te );
                continue;
            }


            // Get Handler from Pool - опросить все процессоры на предмет занятости.
            try
            {
                logger.debug ( "Get free Processor. ("+getName()+":"+port+ ")" );
                handler = pool.getFreeHandler ();
                if ( handler == null )
                {
                    // Нет свободного процессора - пул переполнен.
                    logger.error ( "Сan't create processor for increase pool. Close socket.("+getName()+":"+port+ ")" );
                    Utils.closeSocket ( socket );
                    continue;
                }
                logger.info ( "Assigning socket to new Processor ("+getName()+":"+port+ ")" );
                // Передать сокет в процессор
                handler.publish ( socket );
            } catch ( Exception e ) {
                logger.error ( "Handle processor error. ("+getName()+":"+port+ ")", e );
                Utils.closeSocket ( socket );
            }

            logger.info ( "Listener is free and waiting new socket. ("+getName()+":"+port+")" );
        }

    }


    public void close ()
    {
        try
        {
            pool.close ();
            logger.info ( "Stop process for listener ("+getName()+":"+port+ ")" );
        } catch ( Exception e ) {
            logger.error ( "Stop process error ("+getName()+":"+port+ ")" );
        }
        try
        {
            serverSocket.close ();
            logger.info ( "Closed server socket for listener. ("+getName()+":"+port+ ")" );
        } catch ( IOException e ) {
            logger.error ( "Close server socket error. ("+getName()+":"+port+ ")" );
        }

        started = false;

        logger.info ( "Finish stoping all processors. ("+getName()+":"+port+ ")" );
    }


}

package com.svj.utils.socket;

import java.util.Hashtable;

/**
 * <BR> Производитель обьектов SocketHandler.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 05.06.2006
 * <BR> Time: 16:19:05
 */
public interface SocketHandlerFactory
{
    public SocketHandler    getSocketHandler ();
}

package com.svj.utils.socket;

import org.apache.log4j.Logger;

import java.util.Vector;

/**
 * <BR>
 * <BR>
 * <BR> User: svj
 * <BR> Date: 27.03.2006
 * <BR> Time: 16:03:18
 */
public class SocketHandlersPool
{
    private static Logger logger = Logger.getLogger ( SocketHandlersPool.class );

    /* Начало Индивидуального имени для нового процесса - для отличия от других пулов */
    private  String   processName       = "Handler";
    /* Максимальная граница данного пула */
    private  int      maxSize  = 0;

    private  Vector   pool  = new Vector ( );

    private SocketHandlerFactory factory;


    public SocketHandlersPool ( String name, SocketHandlerFactory factory, int poolSize ) throws Exception
    {
        this.factory    = factory;
        processName     = name;
        maxSize         = poolSize;
        // Проверка на диапазон
        if ( maxSize < 0 )
        {
            logger.error ( "Bad max_pool_size = " + maxSize );
            maxSize = 20;
        }
    }

    public SocketHandler getFreeHandler () throws Exception
    {
       SocketHandler  result  = null;
       int   i;

       logger.debug ( "Start" );
       for ( i=0; i<pool.size (); i++ )
       {
          result  = (SocketHandler) pool.get (i);
          if (result.isFree())  break; //return  result;
       }
       if ( i == pool.size () )   result   = null; // т.к. конец пула.
       if ( result == null )
       {
          // Нет свободных - увеличить пул
          result   = increasePool ();
       }
       logger.debug ( "Finish. i = " + i + ", pool size = " + pool.size () );
       return  result;
    }

    public SocketHandler increasePool ()  throws Exception
    {
       SocketHandler  handler;
       int   size;

       logger.debug ( "Start" );

       size  = pool.size();
       if ( size >= maxSize )
          throw new Exception ( "Pool has max size, =  " + size + " !!!");

       // Instal new handler class
       try
       {
           handler = factory.getSocketHandler ();
           handler.setName ( processName+"_"+size );
           handler.start();
           pool.addElement ( handler );
       } catch ( Exception e )
       {
          throw new Exception ( "Cannot create Handler !!! Exception = "
               + e.getMessage(), e );
       }
       logger.debug ( "Finish" );
       return handler;
    }

    /**
     * Закрыть содержимое пула и завершить работу.
     * Здесь ждутся завершения всех поднятых процессов-обработчиков.
     */
    public void close ()
    {
       logger.info ( "Close Handler pool" );
       int   psize, i;
       SocketHandler handler;
       psize = pool.size();
       String   str   = "Pool '" + processName + "'. Stoping " + psize + " processors.";
       //System.out.println ( str );
       logger.info ( str );

        // Выдать на все процессу команду об остановке.
       for ( i=0; i < psize; i++ )
       {
          logger.info ( " - stoping process N " + (i+1) );
          handler = (SocketHandler) pool.get(i);
          try
          {
             handler.stop();
          } catch ( Exception e )
          {
             logger.error ( "Cannot stoping Handler [" + i + "]. Error.", e );
          }
       }

        // Ожидать останова процесса
       for ( i=0; i < psize; i++ )
       {
          logger.info ( " - wait join process N " + (i+1) );
          handler = (SocketHandler) pool.get(i);
          try
          {
              handler.getThread().join();
          } catch ( Exception e )
          {
             logger.error ( "Cannot wait join Handler [" + i + "]. Error.", e );
          }
       }
       logger.info ( "Finish stoping all processors." );
    }

}

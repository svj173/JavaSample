package com.svj.utils;

import com.svj.xml.TreeObject;
import com.svj.xml.Parser;
import com.svj.xml.handlers.ObjectHandler;
import com.svj.utils.crypt.Crypt;

import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * <BR> Класс позволяет формировать разные XML структуры.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 17.03.2006
 * <BR> Time: 14:14:11
 */
public class XmlTools
{
    public static final char    START   = '<';
    public static final String  FINISH  = "</";
    public static final char    END     = '>';
    public static final char    KAV     = '"';

    public static StringBuffer startTag ( String name )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        result.append ( START );
        result.append ( name );
        result.append ( END );
        return result;
    }

    public static StringBuffer startTag ( String name, String attr1, String value1 )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        result.append ( START );
        result.append ( name );
        result.append ( ' ' );
        result.append ( attr1 );
        result.append ( "=" );
        result.append ( KAV );
        result.append ( value1 );
        result.append ( KAV );
        result.append ( END );
        return result;
    }

    /**
     * Тэг с атрибутами.
     * @param name
     * @param attr
     * @return законченная строка тэга. без последнего /.
     */
    public static StringBuffer startTag ( String name, Hashtable attr )
    {
        Enumeration en;
        String  key, value;
        StringBuffer    result  = new StringBuffer ( 32 );

        result.append ( START );
        result.append ( name );

        en  = attr.keys ();
        while ( en.hasMoreElements () )
        {
            key = (String) en.nextElement ();
            value   = (String) attr.get ( key );
            result.append ( ' ' );
            result.append ( key );
            result.append ( "=" );
            result.append ( KAV );
            result.append ( value );
            result.append ( KAV );
        }

        result.append ( END );
        return result;
    }

    public static StringBuffer endTag ( String name )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        result.append ( FINISH );
        result.append ( name );
        result.append ( END );
        return result;
    }

    public static StringBuffer createTag ( String name, String value )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        result.append ( startTag(name) );
        result.append ( value );
        result.append ( endTag(name) );
        return result;
    }

    // -------------- Здесь используем внутреннюю табуляцию и перевод строки ------

    public static StringBuffer startTag ( String name, int tab )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        int i;
        for ( i=0; i<tab; i++ )   result.append ( Cons.TAB );
        result.append ( startTag ( name ) );
        result.append ( Cons.END_LINE );
        return result;
    }

    public static StringBuffer startTag ( String name, String attr1, String value1, int tab )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        int i;
        for ( i=0; i<tab; i++ )   result.append ( Cons.TAB );
        result.append ( startTag ( name, attr1, value1 ) );
        result.append ( Cons.END_LINE );
        return result;
    }

    public static StringBuffer startTag ( String name, Hashtable attr, int tab )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        int i;
        for ( i=0; i<tab; i++ )   result.append ( Cons.TAB );
        result.append ( startTag ( name, attr ) );
        result.append ( Cons.END_LINE );
        return result;
    }

    public static StringBuffer endTag ( String name, int tab )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        int i;
        for ( i=0; i<tab; i++ )   result.append ( Cons.TAB );
        result.append ( endTag ( name ) );
        result.append ( Cons.END_LINE );
        return result;
    }

    public static StringBuffer createTag ( String name, String value, int tab )
    {
        StringBuffer    result  = new StringBuffer ( 32 );
        int i;
        for ( i=0; i<tab; i++ )   result.append ( Cons.TAB );
        result.append ( createTag ( name, value ) );
        result.append ( Cons.END_LINE );
        return result;
    }

    /**
     * Взять и распарсить файл  начальных параметров, содержащийся в XML файле.
     *
     * @param fileName Имя Файла конфигурации
     * @param path  Полный путь до директории где лежат XML файлы - на случай докачек данных и т.д.
     */
    public static   TreeObject getXMLParams ( String fileName, String path ) throws Exception
    {
        TreeObject result;
        FileReader fin;
        try
        {
            //logger.debug ( "getXMLParams.");
            fileName = FileTools.createFileName ( fileName, path );
            //logger.debug ( "fileName = " + fileName );

            fin     = new FileReader ( fileName );
            ObjectHandler reporter = new ObjectHandler (path);
            Parser.parse ( reporter, fin );
            fin.close ();
            result  = ( TreeObject ) reporter.getResult ();

        } catch ( Exception e ) {
            // Ошибка чтения либо Нет такого файла конфигурации
            String  str;
            str = "Cannot parse XML config-file '" + fileName + "'. Error = " + e.getMessage ();
            //System.out.println ( str );
            //e.printStackTrace ();
            //logger.error ( str, e );
            throw new Exception ( str, e );
        }
        return result;
    }

    public static   TreeObject getXMLParams ( InputStream io ) throws Exception
    {
        ObjectHandler reporter;
        TreeObject result = null;
        InputStreamReader   isr;

        reporter    = new ObjectHandler ();
        isr         = new InputStreamReader ( io );
        Parser.parse ( reporter, isr );
        result      = ( TreeObject ) reporter.getResult ();

        return result;
    }

    /**
     * <BR> Расшифровать зашифрованные параметры. В тексте тега они начинаются
     *  на key (file:file_name).
     * <BR> Расшифровываются модулем Crypt.
     * <BR> Пример:
     * <BR> < param1>file:conf/a1.pwd</param1>
     * <BR> где file: -    Ключевое слово, с которог оначинается содержимое тега и по
     * <BR>      которому определяется что это - путь до зашифрованного файла.
     * <BR>
     * <BR> @param config
     * <BR> @param path   Абсолютный путь до директории где лежат зашифрованные файлы.
     * <BR> @throws Exception
     */
    public static void decrypt ( TreeObject config, String path ) throws Exception
    {
        Enumeration en;
        Hashtable   hb;
        TreeObject  to;
        String      str, fileName, value, paramName;
        Crypt       decrypt;

        decrypt = new Crypt ();

        // Цикл по всему конфигу
        // - Получить строковые параметры и расшифровать при необходимости
        hb  = config.getStrings ();
        en  = hb.keys ();
        while ( en.hasMoreElements () )
        {
            paramName  = (String) en.nextElement ();
            str         = (String) hb.get ( paramName );
            if ( str.startsWith ( Cons.FILE_KEY ) )
            {
                // Выделить имя файла
                fileName    = str.substring ( Cons.FILE_KEY.length () );
                // Проверить на асболютное имя. Если нет - сделать.
                fileName    = FileTools.createFileName ( fileName, path );
                decrypt.setFile ( fileName );
                // Вычислить значение
                value   = decrypt.load ();
                // Сохранить в конфиг
                config.setString ( paramName, value);
                //logger.debug ( "Param = " + paramName + ", FILE = " + fileName + ", value = " + value );
            }
        }

        // - Получить все древовидные обьекты и по ним пройтись - рекурсивно
        en  = config.getTreeObjectsEnumeration ();
        while ( en.hasMoreElements () )
        {
            to  = (TreeObject) en.nextElement ();
            decrypt ( to, path );
        }
    }


}

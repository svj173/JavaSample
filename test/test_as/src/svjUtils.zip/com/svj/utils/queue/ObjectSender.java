package com.svj.utils.queue;

import org.apache.log4j.Logger;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Vector;

/**
 * <BR> Модуль пытается очистить файловую очередь, путем отправки обьектов.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 12.06.2006
 * <BR> Time: 15:43:26
 */
public class ObjectSender implements ActionListener
{
    private static Logger logger = Logger.getLogger ( ObjectSender.class );

    private Timer   timer;
    private Sender  sender;

    private FileObjectsQueue    queue;


    public ObjectSender ( int   timeout, FileObjectsQueue    queue, Sender sender )
            throws Exception
    {
        logger.debug ( "Start" );
        if ( queue == null  )
            throw new Exception ( "Object FileQueue is NULL." );
        if ( sender == null )
            throw new Exception ( "Object Sender is NULL." );
        this.queue  = queue;
        this.sender = sender;
        timer       = new Timer ( timeout, this );
        logger.debug ( "Finish" );
    }

    public void start ()
    {
        logger.debug ( "Start" );
        if ( ! timer.isRunning () )    timer.start();
        logger.debug ( "Finish" );
    }

    public void actionPerformed ( ActionEvent e )
    {
        Object object;
        boolean bwork;
        Vector  vec;
        String  objName;

        // Пришло время заняться очередью
        logger.debug ( "Start" );

        bwork   = true;
        while ( bwork )
        {
            // - Взять обьект из файловой очереди
            vec  = queue.get ();
            logger.debug ( "Get new object from file queue. Vec = " + vec );
            if ( (vec != null) && (vec.size () ==2) )
            {
                // Есть - обработать
                objName = (String) vec.get(0);
                object  = vec.get(1);
                logger.debug ( "Send Object = " + objName );
                if ( sender.send ( object ) )
                {
                    // Ушло - удалить из очереди и продолжить в цикле.
                    queue.delete ( objName );
                }
                else
                {
                    // Не ушло - закончить цикл.
                    bwork   = false;
                }
                logger.debug ( "Send result = " + bwork );
            }
            else
            {
                // Очередь пуста - закончить оба цикла.
                logger.debug ( "Queue is empty. Finished cicle process." );
                bwork   = false;
                timer.stop();
            }
        }
        logger.debug ( "Finish" );
    }

}

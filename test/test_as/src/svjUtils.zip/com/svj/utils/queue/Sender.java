package com.svj.utils.queue;

/**
 * <BR> Sender. Отправляет обьекты.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 12.06.2006
 * <BR> Time: 16:24:18
 */
public interface Sender
{
    public  boolean     send        ( Object object );
    public  void        close       ();
    public  void        setEngine   ( Object engine );
}

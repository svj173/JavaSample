package com.svj.utils.queue;

import org.apache.log4j.Logger;

import java.io.*;
import java.util.zip.GZIPOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.Vector;

import com.svj.utils.Utils;
import com.svj.utils.FileTools;

/**
 * <BR> Очередь обьектов, котоаря ведется на диске в директории, файлами обьектов.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 12.06.2006
 * <BR> Time: 12:17:28
 */
public class FileObjectsQueue
{
    private static Logger logger = Logger.getLogger ( FileObjectsQueue.class );

    private String  path;

    private boolean process = false;



    public FileObjectsQueue ( String pathDir )
    {
        File    file;
        logger.debug ( "Start. pathDir = " + pathDir );
        path    = pathDir;
        // Если нет такой директории - создать
        file    = new File ( path );
        if ( ! file.exists () )
        {
            // Создать директории
            logger.debug ( "Create new DIR = " + pathDir );
            file.mkdirs ();
        }
        logger.debug ( "Finish" );
    }

    public synchronized void put ( String name, Object object )
    {
        FileOutputStream     fos;
        GZIPOutputStream     gz;
        ObjectOutputStream   oos;
        String               str;

        logger.debug ( "Start. Name = " + name );
        if ( name == null || object == null )
        {
            logger.error ( "Finish with error. Name '" + name + "' or Object '"
                    + object + "' is NULL." );
            return;
        }

        /*
        if ( process )
        {
            try
            {
                wait();
            } catch ( InterruptedException e )
            {
                logger.error ( "Interrupted", e );
            }
        }
        */

            try
            {
                process = false;
                str     = path + "/" + name + ".obj";
                logger.debug ( "Create filePath = " + str );
                fos     = new FileOutputStream ( str );
                gz      = new GZIPOutputStream ( fos );
                oos     = new ObjectOutputStream ( gz );

                oos.writeObject(object);
                oos.flush();
                oos.close();
                fos.close();

                //notify ();

            } catch ( Exception e )
            {
                logger.error ( "", e );
            }

        logger.debug ( "Finish" );
    }

    public void delete ( String fileName )
    {
        File    file;
        logger.debug ( "Start. Delete file = " + fileName );

        process = false;

        try
        {
            fileName    = FileTools.createFileName ( fileName, path );
            logger.debug ( "Delete file 2 = " + fileName );
            file        = new File ( fileName );
            file.delete();
        } catch ( Exception e )
        {
            logger.error ( "Cannot delete file '" + fileName + "'." );
        } finally{
            //notify ();
            logger.debug ( "Finish" );
        }
    }

    public Vector get ()
    {
        Vector              result;
        Object              object;
        FileInputStream     fis;
        GZIPInputStream     gs;
        ObjectInputStream   ois;
        File                file;
        String              files[];
        String              str;

        logger.debug ( "Start" );

        /*
        if ( process )
        {
            try
            {
                wait();
            } catch ( InterruptedException e )
            {
                logger.error ( "Interrupted", e );
            }
        }
        */

        result  = null;
        process = false;
        str     = "unknow";

        try
        {
            // Взять список обьектов
            file    = new File ( path );
            files   = file.list();
            logger.debug ( "List : " + Utils.printStringArray ( files ) );
            if ( (files != null) && (files.length > 0) )
            {
                // Очередь НЕ пуста - т.е. есть хоть одна запись. Берем первую.
                str     = FileTools.createFileName ( files[0], path );
                logger.debug ( "Read file = " + str );
                fis     = new FileInputStream ( str );
                gs      = new GZIPInputStream ( fis );
                ois     = new ObjectInputStream ( gs );
                object  = ois.readObject ();
                result  = new Vector ();
                result.addElement ( str );
                result.addElement ( object );

                ois.close ();
                fis.close ();
            }
        } catch ( Exception e )         {
            // Проблемы с файлом - удалить. 
            result  = null;
            logger.error ( "Get file '" + str + "' from queue error.", e );
            logger.info ( "Delete file '" + str + "' from queue." );
            delete ( str );
        } finally   {
            //notify ();
            logger.debug ( "Finish. Result = " + result );
        }
        return result;
    }

}

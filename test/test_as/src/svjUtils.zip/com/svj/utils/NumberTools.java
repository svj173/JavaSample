package com.svj.utils;


import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

/**
 * Сервисные утилиты по преобразованиям числовых значений.
 * <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 24.08.2005
 * <BR> Time: 14:11:14
 */
public class NumberTools
{

   /**
    * Преобразовать строку в целое.
    * @param intStr        Строковое представление целого числа.
    * @param errorMessage  Сообщение, выводимое при возникновении ошибки преобразования типа.
    * @return
    * @throws Exception
    */
   public static int getInt ( String intStr, String errorMessage )
        throws Exception
   {
      int   result;
      try
      {
         result = Integer.parseInt ( intStr );
      } catch ( Exception e )
      {
         throw new SvjException ( errorMessage + ". Source code = " + intStr );
      }
      return result;
   }

   public static int getInt ( String intStr, int def )
   {
      int   result;
      try
      {
         result = Integer.parseInt ( intStr );
      } catch ( Throwable e )
      {
         result = def;
      }
      return result;
   }

   public static double getDouble ( String doubleStr, double def )
   {
      double   result;
      try
      {
         result = Double.parseDouble ( doubleStr );
      } catch ( Throwable e )
      {
         result = def;
      }
      return result;
   }

    public static double getDouble  ( String doubleStr, String errorMessage )
         throws Exception
    {
       double   result;
       try
       {
          result = Double.parseDouble ( doubleStr );
       } catch ( Exception e )
       {
          throw new SvjException ( errorMessage + ". Source code = " + doubleStr );
       }
       return result;
    }

    public static double getDouble ( Object doubleObj, String errorMessage )
            throws Exception
    {
        double result;
        String doubleStr;
        Double db;

        if ( doubleObj == null )
            throw new SvjException ( errorMessage + ". Source code = " + doubleObj );

        try
        {
            if ( doubleObj instanceof Double )
            {
                db      = (Double) doubleObj;
                result  = db.doubleValue();
            }
            else if ( doubleObj instanceof Long )
            {
                result  = (Long) doubleObj;
            }
            else
            {
                doubleStr   = doubleObj.toString();
                result      = Double.parseDouble(doubleStr);
            }
        } catch ( Exception e ) {
            throw new SvjException ( errorMessage + ". Source code = " + doubleObj );
        }
        return result;
    }

    public static Long getLong ( Object obj, String errorMessage )
            throws Exception
    {
        Long   result;
        String longStr;

        if ( obj == null )
            throw new SvjException ( errorMessage + ". Source code = " + obj );

        try
        {
            longStr = obj.toString();
            result  = Long.parseLong(longStr);
        } catch ( Exception e ) {
            throw new SvjException ( errorMessage + ". Source code = " + obj );
        }
        return result;
    }

    public static Integer getInteger ( Object obj, String errorMessage )
            throws Exception
    {
        Integer result;
        String  intStr;

        if ( obj == null )
            throw new SvjException ( errorMessage + ". Source code = " + obj );

        try
        {
            intStr  = obj.toString();
            result  = Integer.parseInt(intStr);
        } catch ( Exception e ) {
            throw new SvjException ( errorMessage + ". Source code = " + obj );
        }
        return result;
    }


    /**
     * Отформатировать число под сумму. Т.е. округление (само делает) и ограничение до двух знаков
     *  после запятой, с выводом нулей - и после запятой и первым, если число меньше 1.00.
     * @param  amount
     * @return string
     */
    public static String amountFormat ( float amount )
    {
        String                  result, pattern;
        DecimalFormat           formatter;
        DecimalFormatSymbols    symbols;

        // Установить десятичный разделитель - точка (ставит обычно запятую)
        symbols     =   new DecimalFormatSymbols();
        symbols.setDecimalSeparator('.');
        //
        pattern     = "##0.00";
        formatter   = new DecimalFormat ( pattern, symbols );
        result      = formatter.format ( amount );
        return  result;
    }

}

package com.svj.utils.log;


import org.apache.log4j.xml.DOMConfigurator;
import org.apache.log4j.PropertyConfigurator;
import com.svj.utils.SvjException;

/**
 * <BR> Утилиты логирования.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 27.03.2006
 * <BR> Time: 13:15:44
 */
public class LoggerTools
{
    public static void createLogger ( String logConfig ) throws SvjException
    {
        //System.out.println ( "logFile = " + logConfig );
        // читать файл конфигурации логгера
        try
        {
            if ( logConfig.endsWith ( "xml" ) )
            {
               // XML
               //System.out.println ( "Create XML" );
               DOMConfigurator.configure ( logConfig );
            }
            else
            {
               // Property
               //System.out.println ( "Create TXT" );
               PropertyConfigurator.configure ( logConfig );
            }
        } catch ( Throwable er ) {
            throw new SvjException ( "Create logger error.", er );
            //System.err.println ( "Logger Error" );
            //er.printStackTrace ();
        }
    }

}

package com.svj.utils.log;


import org.apache.log4j.spi.LoggerFactory;
import org.apache.log4j.Logger;

/**
 * Logger factory.
 * <BR> User: Zhiganov
 * <BR> Date: 11.10.2004
 * <BR> Time: 12:38:05
 * <BR> Version: $Revision $
 */
public class SvjLoggerFactory   implements LoggerFactory
{

   /**
      The constructor should be public as it will be called by
      configurators in different packages.  */
   public    SvjLoggerFactory () {
   }

   public    Logger makeNewLoggerInstance ( String name ) {
     return new SvjLogger ( name );
   }

}

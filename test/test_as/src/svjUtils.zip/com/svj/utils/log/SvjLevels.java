package com.svj.utils.log;


import org.apache.log4j.Level;

/**
 * New Levels for Logger.
 * <BR> Codes:
 * <LI> DEBUG = 10000 </LI>
 * <LI> INFO  = 20000 </LI>
 * <LI> END   = 20010 </LI>
 * <LI> START  = 20020 </LI>
 * <LI> WARN   = 30000 </LI>
 * <LI> ERROR  = 40000 </LI>
 * <LI> FATAL  = 50000 </LI>
 * <LI> AUDIT  = 50020 </LI>
 *
 * <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 11.10.2004
 * <BR> Time: 12:39:58
 */
public class SvjLevels extends Level
{
   // START
   public   static final    int         START_INT   = Level.INFO_INT + 20;  // INFO_INT
   private  static          String      START_STR   = "START";
   public   static final    SvjLevels   START       = new SvjLevels ( START_INT,
           START_STR, 7 );   // 0, 1, 7 - priority

   // END
   static public final int END_INT   = Level.INFO_INT + 10;  // ERROR_INT
   private static String END_STR    = "END";
   public static final SvjLevels END = new SvjLevels ( END_INT, END_STR, 0 );

   // AUDIT level
   static public final int AUDIT_INT = Level.FATAL_INT + 20;
   private static String AUDIT_STR  = "AUDIT";
   public static final SvjLevels AUDIT = new SvjLevels ( AUDIT_INT, AUDIT_STR, 1 );


   protected SvjLevels ( int level, String strLevel, int syslogEquiv )
   {
      super ( level, strLevel, syslogEquiv );
   }

   /**
    * Convert the string passed as argument to a level. If the conversion fails, then
    * this method returns {@link #DEBUG}.
    */
   public static Level toLevel ( String sArg )
   {
      return toLevel ( sArg, SvjLevels.DEBUG );
   }


   public static Level toLevel ( String sArg, Level defaultValue )
   {

      if ( sArg == null )
      {
         return defaultValue;
      }
      String stringVal = sArg.toUpperCase ();

      if ( stringVal.equals ( START_STR ) )
      {
         return SvjLevels.START;
      }
      else if ( stringVal.equals ( END_STR ) )
      {
         return SvjLevels.END;
      }
      else if ( stringVal.equals ( AUDIT_STR ) )
      {
         return SvjLevels.AUDIT;
      }

      return Level.toLevel ( sArg, defaultValue );
   }


   public static Level toLevel ( int i ) throws IllegalArgumentException
   {
      switch ( i )
      {
         case START_INT:
            return SvjLevels.START;
         case END_INT:
            return SvjLevels.END;
         case AUDIT_INT:
            return SvjLevels.AUDIT;
      }
      return Level.toLevel ( i );
   }

//=============================================================================

}

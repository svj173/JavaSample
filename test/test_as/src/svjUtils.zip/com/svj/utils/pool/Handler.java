package com.svj.utils.pool;


import org.apache.log4j.Logger;

import java.net.Socket;

import com.svj.utils.socket.SocketHandler;

/**
 * <BR> Интерфейс обработчика входящих сокетов.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 05.06.2006
 * <BR> Time: 15:45:46
 */
public abstract class  Handler   implements Runnable
{
    private static Logger logger = Logger.getLogger ( Handler.class );

    private boolean busy        = false;
    private boolean started     = false;

    private Object  object      = null;

    /* Имя процесса. */
    private String  name        = "Process";

    private Object  newObject   = new Object ();

    private Thread  thread      = null;


//===============================================================================

    public abstract  void  handle ( Object  object );

    public abstract  void waitRunning ();
    //public abstract  String getInfo ();


    public void setName ( String name )
    {
        this.name = name;
    }

    public void publish ( Object  object )
    {
        synchronized ( newObject )
        {
           this.object    = object;
           logger.debug ( "Waking up sleeping thread" );
           newObject.notify ();
        }
    }

    public boolean isFree ()
    {
        return (! busy);
    }

    public void start ()
    {
        logger.debug ( "Start. Handler Name = " + name );
        if ( ! started )
        {
            started = true;
            thread = new Thread ( this, name );
            thread.setDaemon ( true );
            thread.start ();
        }
        logger.debug ( "Finish" );
    }

    public void stop ()
    {
        started = false;
    }

    private void setBusy ()
    {
        busy    = true;
    }

    private void setFree ()
    {
        logger.debug ( "Set FREE Handler. Handler Name = " + name );
        busy    = false;
    }

    public void run ()
    {
        logger.debug ( "Start. Handler Name = " + name );
        // Ждать когда поднимется какой-то важный процесс. Например, стартует сервер.
        waitRunning();
        logger.debug ( "Start: thread '" + this + "' is running." );

        while ( started )
        {
            try
            {
                synchronized ( newObject )
                {
                    while ( object == null )
                    {
                        logger.debug ( "Wait new Object" );
                        newObject.wait ();
                        logger.debug ( "Woken up on new Object" );
                    }
                    logger.debug ( "Get new Object." );
                }

                // Обработать
                setBusy ();
                handle ( object );

            } catch ( InterruptedException ex )
            {
                logger.error ( "Error", ex );
            } catch ( Exception ex )
            {
                logger.error ( "Error", ex );
            } finally
            {
                object = null;
                setFree ();
            }
        }
        logger.info ( "Finish: thread '" + this + "' terminated." );
    }



    public String getName ()
    {
        return name;
    }

    public Thread   getThread()
    {
        return thread;
    }

}

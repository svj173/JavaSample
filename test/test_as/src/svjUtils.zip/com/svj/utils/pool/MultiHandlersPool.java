package com.svj.utils.pool;


import org.apache.log4j.Logger;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Properties;
import java.sql.Connection;
import java.sql.SQLException;

import com.svj.utils.db.ConnectionPool;


/**
 * <CODE>MultiHandlersPool</CODE> class for create many HandlersPool for any Handler.
 * <BR> Данный клас создает пул обработчиков чего-либо.
 * <BR> Выдает по запросу Обработчика и после использвоания возврата - поддерживает в
 * рабочем состоянии. Если возникает ошибка - игнорируется - это дело самого Обработчика.
 * <BR> Добавлена возможность пула мультиконнекторов - под разные пулы.
 *
 * @author Sergey Zhiganov (svj173@yahoo.com)
 */
public class MultiHandlersPool
{
    private static Logger logger = Logger.getLogger ( MultiHandlersPool.class );

    /* Для пула пулов коннектов */
    private Hashtable pools;


//-----------------------------------------------------------------------------------

    public MultiHandlersPool ()
    {
        pools = new Hashtable ();
    }

    public void init ()
    {
    }

    public void addPool ( String poolName, HandlersPool pool )
    {
        logger.debug ("Start");
        pools.put ( poolName, pool );
        logger.debug ("Finish");
    }

    public void addHandler ( String poolName, HandlerFactory factory, int maxPoolSize )
    {
        logger.debug ("Start. Pool Name = " + poolName + ", maxPoolSize = " + maxPoolSize );
        if ( pools.contains ( poolName ) )  return;

        HandlersPool    pool;
        pool    = new HandlersPool ( poolName, factory, maxPoolSize );
        pools.put ( poolName, pool );
        logger.debug ("Finish");
    }

    /**
     * Выдает свободного Обработчика по имени пула.
     *
     * @param poolName Имя пула для пула обработчиков
     * @return  Handler
     */
    public Handler getHandler ( String poolName )
    {
        logger.debug ( "Start. poolName = " + poolName );

        Handler         result;
        HandlersPool    pool;

        try
        {
            // Взять пул коннектов по его имени
            pool = ( HandlersPool ) pools.get ( poolName );
            if ( pool == null )
            {
                // Создать и занести в пул
                // - Этого не должно быть, т.к. сначала пул надо проинициализировать, где
                //    эти обьекты и создаются.
                logger.error ( "Cannot find Pool for poolName = " + poolName );
                result = null;
            }
            else
            {
                result  = pool.getHandler ();
            }

        } catch ( Exception e )
        {
            logger.error ( "Get Handler error. pool = " + poolName, e );
            result  = null;
        }

        logger.debug ( "Finish." );

        return result;
    }

//-----------------------------------------------------------------------------------


    /**
     * destroy all connections in all ConnectionPools
     */
    public void destroy ()
    {
        logger.debug ( "Start" );

        String str;
        Enumeration cons = pools.keys ();
        while ( cons.hasMoreElements () )
        {
            str = ( String ) cons.nextElement ();
            logger.debug ( "Close Pool = " + str );
            destroy ( str );
        }
        logger.debug ( "Finish" );
    }

//-----------------------------------------------------------------------------------

    /**
     * destroy all
     */
    public void destroy ( String poolName )
    {
        logger.debug ( "Start" );

        HandlersPool pool = ( HandlersPool ) pools.get ( poolName );
        if ( pool == null )
        {
            logger.error ( "Pool '" + poolName + "' is absent." );
        }
        else
        {
            pool.close ();
        }
        logger.debug ( "Finish" );
    }



    /**
     * Выдать массив имен используемых пулов коннектов.
     */
    public Enumeration getPoolNames ()
    {
        return pools.keys ();
    }

    public Hashtable getInfo()
    {
        Hashtable   result;
        HandlersPool pool;
        Enumeration en;
        String  str;
        Properties vec;

        logger.debug ( "Start" );
        result  = new Hashtable ();
        en      = getPoolNames ();
        while ( en.hasMoreElements () )
        {
            try
            {
                str     = (String) en.nextElement ();
                pool    = (HandlersPool) pools.get(str);
                vec     = pool.getInfo();
                logger.debug ( "Pool name = " + str + ", pool = " + pool + ", poolInfo = " + vec );
                result.put ( str, vec );
            } catch ( Exception e )
            {
                logger.error ( "Create info error.", e );
            }
        }
        logger.debug ( "Finish. Result = " + result );
        return result;
    }

}

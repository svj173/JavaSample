package com.svj.utils.pool;

import org.apache.log4j.Logger;

import java.util.Vector;

/**
 * <BR> Очередь обьектов. Реализует алгоритмы извлечения - FIFO, LIFO.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 29.06.2006
 * <BR> Time: 12:51:05
 */
public class ObjectPool
{
    private static final Logger logger = Logger.getLogger (ObjectPool.class);

    private  Vector   pool;

    /** Алгоритм разгрузки очереди. 0 - LIFO, 1 - FIFO. */
    private  int   poolType;

    /* Алгоритм - последним пришел, первым ушел. Как и в стеке. */
    public static final int LIFO    = 0;
    /* Алгоритм - первым пришел, первым ушел. */
    public static final int FIFO    = 1;


    public ObjectPool ( int poolType )
    {
        pool  = new Vector ( );
        this.poolType = poolType;
    }

    public boolean empty()
    {
        return pool.isEmpty ();
    }

    /**
     * Выдать обьект согласно алгоритму, с удалением его из очереди.
     * @return Обьект
     */
    private Object get ( boolean isDelete )
    {
        Object  result  = null;
        if ( ! pool.isEmpty () )
        {
            int   size, num;
            size  = pool.size ();
            switch ( poolType )
            {
               default:
               case LIFO:
                  num   = size - 1;
                  break;
               case FIFO:
                  num   = 0;
                  break;
            }
            result   = pool.get ( num );
            // Если необходимо - Удалить обьект из пула со смещением обьектов вектора
            //  (иначе позиция останется пустой?)
            if ( isDelete ) pool.removeElementAt ( num );
        }
        //logger.debug ( "Finish. Pool size = " + pool.size () );
        return   result;
    }

    /**
     * Выдать обьект согласно алгоритму, с удалением его из очереди.
     * @return Обьект
     */
    public Object pop ()
    {
        return   get ( true );
    }

    /**
     * Выдать обьект согласно алгоритму, без удаления из очереди.
     * @return Обьект
     */
    public Object peek ()
    {
        return   get ( false );
    }

    /**
     * Положить обьект в очередь.
     * @param object
     */
    public void push ( Object object )
    {
        pool.addElement ( object );
    }

    /**
     * Поиск обьекта.
     * @param object
     * @return  Номер обьекта в очереди, если такой обьект уже есть, либо -1.
     */
    public int  search ( Object object )
    {
        int result;
        result  = pool.indexOf ( object );
        return result;
    }

}

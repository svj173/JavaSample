package com.svj.utils.pool;

/**
 * <BR> Производитель классов.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 26.06.2006
 * <BR> Time: 11:27:27
 */
public interface HandlerFactory
{
    public Handler  createHandler ();
}

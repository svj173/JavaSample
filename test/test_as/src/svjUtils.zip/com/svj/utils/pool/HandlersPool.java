package com.svj.utils.pool;


import org.apache.log4j.Logger;

import java.util.Vector;
import java.util.Properties;


/**
 * <BR>
 * <BR>
 * <BR> User: svj
 * <BR> Date: 27.03.2006
 * <BR> Time: 16:03:18
 */
public class HandlersPool
{
    private static Logger logger = Logger.getLogger ( HandlersPool.class );

    /* Начало Индивидуального имени для нового процесса - для отличия от других пулов.
     Также это имя данного пула. */
    private     String   name       = "Handler";

    /* Максимальная граница данного пула */
    private     int      maxSize  = 0;

    /* Собственно пул. */
    private     Vector   pool  = new Vector ( );

    private     HandlerFactory  factory;



    public HandlersPool ( String name, HandlerFactory  factory, int poolSize )
    {
        logger.debug ("Start. Pool Name = " + name + ", maxPoolSize = " + poolSize );
        this.name       = name;
        this.factory    = factory;
        pool            = new Vector ( );
        maxSize         = poolSize;
        // Проверка на диапазон
        if ( maxSize < 2 )
        {
            logger.error ( "Bad max_pool_size = " + maxSize );
            maxSize = 20;
        }
    }

    public Handler getHandler ()
    {
       Handler  result  = null;
       int   i;

       logger.debug ( "Start. PoolName = " + name + ", size = " + pool.size() );
       for ( i=0; i<pool.size (); i++ )
       {
          result  = (Handler) pool.get (i);
          if (result.isFree())  break; //return  result;
       }
       if ( i == pool.size () )   result   = null; // т.к. конец пула.
       if ( result == null )
       {
          // Нет свободных - увеличить пул
          result   = increasePool ();
       }
       logger.debug ( "Finish. PoolName = " + name + ", i = " + i + ", pool size = " + pool.size() );
       return  result;
    }

    public Handler increasePool ()
    {
        Handler  handler;
        int      size;

        logger.debug ( "Start. PoolName = " + name + ", size = " + pool.size() );

        handler = null;
        size  = pool.size();
        if ( size >= maxSize )
        {
           logger.error ( "Pool has max size =  " + size + " !!!");
        }
        else
        {
           // Instal new handler class
           try
           {
               handler = factory.createHandler ();
               handler.setName (  name + "_" + size );
               handler.start();
               pool.addElement ( handler );
           } catch ( Exception e )
           {
               logger.error ( "Cannot create Handler !!!", e );
               handler = null;
           }
        }
        logger.debug ( "Finish. PoolName = " + name );
        return handler;
    }

    /**
     * Закрыть содержимое пула и завершить работу.
     * Здесь ждутся завершения всех поднятых процессов-обработчиков.
     */
    public void close ()
    {
       logger.info ( "Close Handler pool. PoolName = " + name );
       int   psize, i;
       Handler handler;
       psize = pool.size();
       String   str   = "Pool '" + name + "'. Stoping " + psize + " processors.";
       //System.out.println ( str );
       logger.info ( str );

        // Выдать на все процессу команду об остановке.
       for ( i=0; i < psize; i++ )
       {
          logger.info ( " - stoping process N " + (i+1) );
          handler = (Handler) pool.get(i);
          try
          {
             handler.stop();
          } catch ( Exception e )
          {
             logger.error ( "Cannot stoping Handler [" + i + "]. Error.", e );
          }
       }

        // Ожидать останова процесса
       for ( i=0; i < psize; i++ )
       {
          logger.info ( " - wait join process N " + (i+1) );
          handler = (Handler) pool.get(i);
          try
          {
              handler.getThread().join();
          } catch ( Exception e )
          {
             logger.error ( "Cannot wait join Handler [" + i + "]. Error.", e );
          }
       }
       logger.info ( "Finish stoping all processors." );
    }

    public String getName ()
    {
        return name;
    }

    public int getSize ()
    {
        return pool.size ();
    }

    public Properties getInfo()
    {
        Properties  result;
        Handler handler;

        logger.debug ( "Start" );
        result  = new Properties ( );

        for ( int i=0; i<pool.size (); i++ )
        {
            handler = (Handler) pool.get(i);
            logger.debug ( "Handler = " + handler );
            result.setProperty ( handler.getName(), handler.toString()
                    + ", free:" + handler.isFree () );
        }

        logger.debug ( "Finish. Result = " + result );
        return result;

    }

}

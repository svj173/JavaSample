package com.svj.utils.db;

import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Enumeration;

/**
 * <BR>
 * <BR>
 * <BR> User: svj
 * <BR> Date: 05.06.2006
 * <BR> Time: 12:27:23
 */
public class ConnectionPool
{
    private static Logger logger = Logger.getLogger ( ConnectionPool.class );

    private Hashtable connections;

    private String dbURL;
    private String user;
    private String password;
    private String dbName;
    private int     size;

//-----------------------------------------------------------------------------------

    public ConnectionPool
            ( String dbName, String dbURL, String user, String password,
              String driverClassName, int initialConnections
            )
            throws Exception
    {
        logger.debug ( "Start" );

        // Load the specified driver class
        Class.forName ( driverClassName );

        this.dbName     = dbName;
        this.dbURL      = dbURL;
        this.user       = user;
        this.password   = password;
        this.size       = initialConnections;

        connections = new Hashtable ();

        logger.debug ( "Finish." );
    }



    /**
     * get free Connection. If not free - get new Connection and add it to ConnectionPool
     */
    public Connection getConnection() throws SQLException
    {
        logger.debug ( "Start" );

        Connection con = null;
        Boolean b;

        int	oldsize	= connections.size();

        Enumeration cons = connections.keys();

        synchronized ( connections )
        {
            while ( cons.hasMoreElements() )
            {
                con = (Connection) cons.nextElement();

                b = (Boolean) connections.get(con);
                if ( b == Boolean.FALSE )
                {
                    // So we found an unused connection.
                    // Test its integrity with a quick setAutoCommit(true) call.
                    // For production use, more testing should be performed,
                    // such as executing a simple query.
                    try {
                        con.setAutoCommit ( true );
                    }
                    catch ( SQLException e ) {
                        // Problem with the connection, replace it.
                        con = DriverManager.getConnection ( dbURL, user, password );
                    }
                    // Update the Hashtable to show this one's taken
                    connections.put ( con, Boolean.TRUE );
                    // Return the connection
                    return con;
                }
            }
        }

        // If we get here, there were no free connections.
        con		= DriverManager.getConnection( dbURL, user, password );
        if ( con != null )	connections.put ( con, Boolean.FALSE );

        int	newsize	= connections.size();

        logger.debug ( "Increasing connection pool !!! New Size = " + connections.size () );

        // Recurse to get one of the new connections.
        return getConnection();
    }

//-----------------------------------------------------------------------------------
    /**
     * Return this Connection to Pool (set Passive)
     */
    public void returnConnection ( Connection returned )
    {
        logger.debug ( "Start" );

        Connection	con;
        Enumeration	cons = connections.keys();
        while ( cons.hasMoreElements() )
        {
            con = ( Connection ) cons.nextElement();
            if ( con == returned )
            {
                connections.put ( con, Boolean.FALSE );
                break;
            }
        }
        logger.debug ( "Finish" );
    }

//-----------------------------------------------------------------------------------

    /**
     * get size of this ConnectionPool
     */
    public int getSize ()
    {
        return connections.size ();
    }

//-----------------------------------------------------------------------------------

    /**
     * destroy all connections in this ConnectionPool
     */
    public void close ()
    {
        Connection con = null;
        Enumeration cons = connections.keys ();
        synchronized ( connections )
        {
            while ( cons.hasMoreElements () )
            {
                con = ( Connection ) cons.nextElement ();
                try
                {
                    con.close ();
                }
                catch ( Exception e )
                {
                    logger.error ( "Close connection error.", e );
                }
            }
        }
    }

    public String getName ()
    {
        return dbName;
    }

    public Hashtable getConnections ()
    {
        return connections;
    }

//==================================================================================

}

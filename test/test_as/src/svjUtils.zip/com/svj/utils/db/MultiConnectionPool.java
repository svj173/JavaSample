package com.svj.utils.db;


import org.apache.log4j.Logger;

import java.util.Hashtable;
import java.util.Enumeration;
import java.sql.Connection;
import java.sql.SQLException;


/**
 * <CODE>MultiConnectionPool</CODE> class for create many ConnectionPools for any DataBase.
 * <BR> Данный клас создает пул коннектов к базе данных либо базам данных если их
 * несколько разных.
 * <BR> Выдает по запросу коннект и после использвоания возврата - поддерживает в
 * рабочем состоянии. Если возникает ошибка коннеекта, расцененная как отсутсвие
 * коннекта (несколкьо ключевых слов
 * из сообщения об ошибке SQL соединения), то происходит переконнект всего пула.
 * <BR> Добавлена возможность пула мультиконнекторов - под разные системы.
 * <BR> Методы, используемые по умолчанию - для 'MSRV'.
 *
 * @author Sergey Zhiganov (svj173@yahoo.com)
 */
public class MultiConnectionPool
{
    private static Logger logger = Logger.getLogger ( MultiConnectionPool.class);

    public static MultiConnectionPool instance = new MultiConnectionPool ();

    /* Для пула пулов коннектов */
    private Hashtable pools = new Hashtable ();

    /* Для пула конфигов под пулы коннектов */
    private Hashtable conf = new Hashtable ();

    /* Има пула пулов коннектов по умолчанию. ??? */
    private String defName = "msrv";

//-----------------------------------------------------------------------------------

    private MultiConnectionPool ()
    {
    }

    public static MultiConnectionPool getInstance ()
    {
        return instance;
    }

    public void init ()
    {
        pools = new Hashtable ();
    }

    /**
     * выдает коннект по имени БД из пула
     *
     * @param dbName   Имя базы данных
     * @param poolName Имя пула для пула коннектов
     * @return
     * @throws Exception
     */
    public Connection getConnection ( String dbName, String poolName ) throws Exception
    {
        logger.debug ( "Start. dbName = " + dbName + ", poolName = " + poolName );

        Connection con = null;
        ConnectionPool pool;
        String str;
        Hashtable connections;

        // Взять пул коннектов по его имени
        connections = ( Hashtable ) pools.get ( poolName );
        if ( connections == null )
        {
            // Создать и занести в пул
            // - Этого не должно быть, т.к. сначала пул надо проинициализировать, где
            //    эти обьекты и создаются.
            connections = new Hashtable ();
            pools.put ( poolName, connections );
        }

        if ( connections.containsKey ( dbName ) )
        {
            logger.debug ( "Has pool = " + dbName );
            // ConnectionPool for this class is exist
            try
            {
                pool = ( ConnectionPool ) connections.get ( dbName );
                con = pool.getConnection ();
            }
            catch ( Exception e )
            {
                // if error - return connection = null
                logger.error ( "Get Connection error. dbName = " + dbName, e );
                throw new Exception ( "Get Connection error" );
            }
        }
        else
        {
            // create new ConnectionPool for this DataBase
            str = "HasNOT pool = " + dbName + ". Create new.";
            logger.error ( str );
            throw new Exception ( str );
        }

        if ( con == null )
        {
            logger.error ( "Get Connection error. dbName = " + dbName );
            throw new Exception ( "Get Connection error" );
        }

        logger.debug ( "Finish." );

        return con;
    }

//-----------------------------------------------------------------------------------

    public void returnConnection ( String dbName, Connection con, String poolName )
    {
        logger.debug ( "Start. dbName = " + dbName + ", con = " + con + ", poolName = " + poolName );
        ConnectionPool pool;
        try
        {
            Hashtable connections = ( Hashtable ) pools.get ( poolName );
            if ( connections == null )
            {
                logger.error ( "Pool '" + poolName + "' is absent." );
                try
                {
                    con.close ();
                } catch ( SQLException e )
                {
                }
            }
            else
            {
                if ( connections.containsKey ( dbName ) )
                {
                    // ConnectionPool for this class is exist
                    pool = ( ConnectionPool ) connections.get ( dbName );
                    pool.returnConnection ( con );
                }
                else
                {
                    logger.error ( "Unknow name for ConnectionPool = " + dbName
                            + ". Unknow connection. Close." );
                    try
                    {
                        con.close ();
                    } catch ( SQLException e )
                    {
                        logger.error ( "Close connection error.", e );
                    }
                }
            }
        } catch ( Exception e )
        {
            logger.error ( "Error. pool = " + pools, e );
        }
        logger.debug ( "Finish" );
    }

    /**
     * destroy all connections in all ConnectionPools
     */
    public void destroy ()
    {
        logger.debug ( "Start" );

        String str;
        Enumeration cons = pools.keys ();
        while ( cons.hasMoreElements () )
        {
            str = ( String ) cons.nextElement ();
            logger.debug ( "Close Pool = " + str );
            destroy ( str );
        }
        logger.debug ( "Finish" );
    }

//-----------------------------------------------------------------------------------

    /**
     * destroy all connections in all ConnectionPools
     */
    public void destroy ( String poolName )
    {
        logger.debug ( "Start" );

        ConnectionPool pool;
        Hashtable connections = ( Hashtable ) pools.get ( poolName );
        if ( connections == null )
        {
            logger.debug ( "Pool '" + poolName + "' is absent." );
        }
        else
        {
            Enumeration cons = connections.elements ();
            while ( cons.hasMoreElements () )
            {
                pool = ( ConnectionPool ) cons.nextElement ();
                try
                {
                    logger.debug ( "Close DB = " + pool.getName () + ", Size = " + pool.getSize () );
                    pool.close ();
                } catch ( Exception e )
                {
                    // nothing
                    logger.error ( "Error when destroy ConnectionPool.", e );
                }
            }
        }
        logger.debug ( "Finish" );
    }

    public ConnectionPool getConnectionPool ( String dbName, String poolName )
    {
        Hashtable connections = ( Hashtable ) pools.get ( poolName );
        return ( ConnectionPool ) connections.get ( dbName );
    }

    public ConnectionPool getConnectionPool ( String dbName )
    {
        return getConnectionPool ( dbName, defName );
    }

    /**
     * Выдать массив имен используемых пулов коннектов.
     */
    public Enumeration getPoolNames ()
    {
        return pools.keys ();
    }

}

package com.svj.utils.ssl;


import org.apache.log4j.Logger;

import javax.net.ssl.*;
import javax.net.ServerSocketFactory;
import javax.net.SocketFactory;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;

import com.svj.utils.FileTools;

/**
 * <BR> Создает SSL сокеты на основе харнилища ключей и хранилища доверенных сертификатов.
 * <BR>
 * <BR> User: svj
 * <BR> Date: 21.03.2006
 * <BR> Time: 16:03:03
 */
public class SslManager
{
    private static final Logger logger = Logger.getLogger (SslManager.class);

    /** SSL фабрики, созданные на основе предложенных хранилищ ключей. */
    private  SocketFactory        sslSocketFactory        ;//= null;
    private  ServerSocketFactory  sslServerSocketFactory  ;//= null;

    private     String  type            = SSLCons.TLS;    // SSL, TLS
    private     String  algoritm        = "SunX509";    //
    private     String  keyStoreType    = SSLCons.JKS;    // PKCS12, JKS
    /* Алгоритм генератора случайных чисел. */
    private     String  randomAlgorithm = "SHA1PRNG";    //
    private     String  provider        = "SUN";    //


    public SslManager ( String keyFile, String keyPasswd, String trustFile, String trustPasswd )
    {
        new SslManager ( keyFile, keyPasswd, keyStoreType, trustFile, trustPasswd, keyStoreType, type );
    }

    /**
     * Создать фактории SSL сокетов.
     *
     * @param keyFile       Путь до хранилища приватного и публичного (сертификат) ключей.
     * @param keyPasswd     Пароль на доступ к хранилищу ключей.
     * @param keyStoreType  Тип хранилища приватного и публичного ключей.
     * @param trustFile     Путь до хранилища доверенных сертификатов.
     * @param trustPasswd   Пароль на доступ к хранилищу доверенных сертификатов.
     * @param trustStoreType  Тип хранилища доверенных сертификатов.
     * @param type  Тип соединения: TLS, SSL.
     */
    public SslManager
            ( String keyFile, String keyPasswd, String keyStoreType,
              String trustFile, String trustPasswd, String trustStoreType, String type )
    {
        logger.debug ( "Start. keyFile = " + keyFile
                //+ ", keyPasswd = " + keyPasswd
                + ", keyStoreType = " + keyStoreType + ", trustFile = " + trustFile
                //+ ", trustPasswd = " + trustPasswd
                + ", trustStoreType = " + trustStoreType
                + ", type = " + type );

        if ( type.equals ( SSLCons.TLS ) || type.equals ( SSLCons.SSL ) )
        {
            try
            {
                // set up key manager to do server authentication
                SSLContext          ctx;
                KeyManagerFactory   kmf;
                KeyManager[]        km;
                KeyStore            ks;
                TrustManagerFactory tmf;
                TrustManager[]      tm;
                FileInputStream     fis;
                char[]              passphrase;
                SecureRandom        random;

                logger.debug ( "Get context" );
                ctx         = SSLContext.getInstance ( type );

                // Key
                logger.debug ( "Create key" );
                passphrase  = keyPasswd.toCharArray ();
                kmf         = KeyManagerFactory.getInstance ( algoritm );
                ks          = KeyStore.getInstance ( keyStoreType );
                fis         = new FileInputStream ( keyFile );
                ks.load ( fis, passphrase );
                kmf.init ( ks, passphrase );
                km          = kmf.getKeyManagers ();

                // Trust
                logger.debug ( "Create trust" );
                passphrase  = trustPasswd.toCharArray ();
                tmf         = TrustManagerFactory.getInstance ( algoritm );
                ks          = KeyStore.getInstance ( trustStoreType );
                fis         = new FileInputStream ( trustFile );
                ks.load ( fis, passphrase );
                tmf.init ( ks );
                tm          = tmf.getTrustManagers ();

                // Создать экземпляр защищенного случайного числа при заданном
                //    алгоритме и провайдере
                logger.debug ( "Create random" );
                random      = SecureRandom.getInstance ( randomAlgorithm, provider );

                // Context - Это действие почему-то иногда занимает до 5 минут.
                logger.debug ( "Init context" );
                ctx.init ( km, tm, random );   // km, null, null

                logger.debug ( "Create factory" );
                sslServerSocketFactory  = ctx.getServerSocketFactory ();
                sslSocketFactory        = ctx.getSocketFactory ();

            } catch ( Exception e ) {
                logger.error ( "Create SslManager Error", e );
                //sslServerSocketFactory  = null;
                //sslSocketFactory        = null;
                sslServerSocketFactory  = ServerSocketFactory.getDefault ();
                sslSocketFactory        = SocketFactory.getDefault ();
            }
        }
        else
        {
            logger.debug ( "Create default (plain) factory." );
            sslServerSocketFactory  = ServerSocketFactory.getDefault ();
            sslSocketFactory        = SocketFactory.getDefault ();
        }

        logger.debug ( "sslServerSocketFactory = " + sslServerSocketFactory + ", sslSocketFactory = " + sslSocketFactory );
        logger.debug ( "Finish" );
    }

    public Socket getSocket ( String host, int port ) throws IOException
    {
        logger.debug ( "sslSocketFactory = " + sslSocketFactory + ", host = " + host + ", port = " + port );
        return  sslSocketFactory.createSocket ( host, port );
    }

    public ServerSocket getServerSocket ( int port ) throws IOException
    {
        logger.debug ( "sslServerSocketFactory = " + sslServerSocketFactory + ", port = " + port );
        return  sslServerSocketFactory.createServerSocket ( port );
    }

    public String getType ()
    {
        return type;
    }

    public void setType ( String type )
    {
        this.type = type;
    }

    public String getAlgoritm ()
    {
        return algoritm;
    }

    public void setAlgoritm ( String algoritm )
    {
        this.algoritm = algoritm;
    }

    public String getKeyStoreType ()
    {
        return keyStoreType;
    }

    public void setKeyStoreType ( String keyStoreType )
    {
        this.keyStoreType = keyStoreType;
    }

    public String getRandomAlgorithm ()
    {
        return randomAlgorithm;
    }

    public void setRandomAlgorithm ( String randomAlgorithm )
    {
        this.randomAlgorithm = randomAlgorithm;
    }

    public String getProvider ()
    {
        return provider;
    }

    public void setProvider ( String provider )
    {
        this.provider = provider;
    }

    public String toString ()
    {
        StringBuffer    result  = new StringBuffer ( 128 );

        result.append ( "sslServerSocketFactory = " );
        result.append ( sslServerSocketFactory );
        result.append ( ", sslSocketFactory = " );
        result.append ( sslSocketFactory );
        return result.toString ();
    }

}

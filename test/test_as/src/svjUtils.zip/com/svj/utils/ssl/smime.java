package com.svj.utils.ssl;


import org.apache.log4j.Logger;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.SMIMESigned;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
import org.bouncycastle.mail.smime.SMIMEEnveloped;
import org.bouncycastle.mail.smime.SMIMEUtil;
import org.bouncycastle.cms.*;

import java.security.KeyStore;
import java.security.Security;
import java.security.Key;
import java.security.cert.X509Certificate;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.math.BigInteger;

import com.sun.net.ssl.internal.ssl.Provider;
import com.svj.utils.SvjException;

import javax.mail.*;
import javax.mail.internet.*;
import javax.security.auth.x500.X500Principal;

/**
 * Класс работает с почтовыми сообщениями, подписанными и зашифрованными OpenSSL.
 * <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 18.08.2005
 * <BR> Time: 10:48:23
 */
public class smime
{
   private static final Logger logger = Logger.getLogger(smime.class);

   /* Алиас, под которым хранятся наши сертификат и приватный ключ. */
   private String    ourAlias;
   /* Пароль на доступ к нашему приватному ключу. */
   private String    ourKeyPassword;
   /* Алиас, под которым хранится сторонний сертификат для проверки подписи. */
   private String    unsignCertAlias;

   private  KeyStore keyStore = null;

   // Costants
   private static final int   MULTIPART_SIGNED  = 0;
   private static final int   APP_PKCS7_SIGNED  = 1;
   private static final int   APP_PKCS7_ENV     = 2;
   private static final int   MESSAGE           = 3;
   private static final int   MULTIPART         = 4;
   private static final int   STRINGS           = 5;
   private static final int   TEXT_PLAIN        = 6;
   private static final int   INPUT_STREAMS     = 7;


   public smime ()
   {
      // Add Providers
      // - Add PKCS12 provider
      Security.addProvider ( new BouncyCastleProvider () );
      // - Add SSL provider
      Security.addProvider ( new Provider () );

      keyStore = null;
   }

   /**
    * Инициализировать обьект.
    */
   public void init ( String  fileName, String filePassword, String ksType,
                      String ourAlias, String ourKeyPassword )
        throws Exception
   {
      FileInputStream	fs;
      String			   provider;
      char[] password   = null;

      logger.debug ( "Start" );

      this.ourAlias        = ourAlias;
      this.ourKeyPassword  = processPassword ( ourKeyPassword );
      this.unsignCertAlias = null;

      // Загрузить хранилище ключей
      if ( filePassword != null )
         password = filePassword.toCharArray ();
      if ( ksType == null )   ksType = "PKCS12";
      if ( ksType.equalsIgnoreCase ( "PKCS12" ) ) provider = SSLCons.BC_Provider;
      else  provider  = SSLCons.SUN_Provider;

      logger.debug ( "Start load '" + fileName + "' file. ksType = " + ksType
              + ", Provider = " + provider );
      fs			= new FileInputStream ( fileName );
      keyStore = KeyStore.getInstance ( ksType, provider );
      keyStore.load ( fs, password );

      fs.close ();
      logger.debug ( "Finish" );

   }

   private String processPassword ( String password )
   {
      String   result   = password;
      if ( result != null )
      {
         result = result.trim();
         if ( result.length () == 0 )   result = null;
      }
      return result;
   }

   /**
    * Обработать почтовое сообщение, а также его вложения.
    * @param message
    * @return Part object
    */
   public Part processPart ( Part message ) throws SvjException
   {
      Part  result   = null;

      int            messageType;
      SMIMESigned    signedMessage;
      MimeBodyPart   content;

      logger.debug ( "Start. Process message : " + message );
      try
      {
         messageType = getMessageType ( message );

         switch ( messageType )
         {
            case MULTIPART_SIGNED :
               logger.debug ( "MULTIPART_SIGNED" );
               //SMIMESigned signedMessage = new SMIMESigned
               //       ( ( MimeMultipart ) message.getContent () );
               //MimeBodyPart content = signedMessage.getContent ();
               //verify ( signedMessage );
               //result   = processPart ( content );
               verify ( message );
               signedMessage = new SMIMESigned
                      ( ( MimeMultipart ) message.getContent () );
               content = signedMessage.getContent ();
               result   = processPart ( content );
               break;

            case APP_PKCS7_SIGNED :
               logger.debug ( "APP_PKCS7_SIGNED" );
               verify ( message );
               signedMessage = new SMIMESigned ( message );
               //signedMessage = new SMIMESigned ( (MimeMultipart) message.getContent() );
               content  = signedMessage.getContent ();
               result   = processPart ( content );
               break;

            case APP_PKCS7_ENV :
               logger.debug ( "APP_PKCS7_ENV" );
               message  = decrypt ( message );
               result   = processPart ( message );
               break;

            case MESSAGE :
               logger.debug ( "MESSAGE" );
               result   = processPart ( message );
               break;

            case MULTIPART :
               logger.debug ( "MULTIPART" );
               Multipart mp = ( Multipart ) message.getContent ();
               int bodiesCount = mp.getCount ();
               for ( int i = 0; i < bodiesCount; i++ )
               {
                  // TODO ???? - части ведь надо где-то складывать ?
                  result   = processPart ( mp.getBodyPart ( i ) );
               }
               break;

            case STRINGS :
               logger.debug ( "STRINGS" );
               result   = message;
               break;

            case TEXT_PLAIN :
               logger.debug ( "TEXT_PLAIN" );
               result   = message;
               break;

            case INPUT_STREAMS :
               logger.debug ( "INPUT_STREAMS" );
               result   = getInputStream ( message );
               break;

         }

      } catch ( SvjException se )
      {
         throw se;
      } catch ( Exception e )
      {
         logger.error ( "Error", e );
         throw new SvjException ( "Undefined_Content_Type_Description" );
      } catch ( Throwable tr )
      {
         logger.error ( "Throwable", tr );
         System.gc ();
         throw new SvjException ( "Undefined_Content_Type_Description" );
      }
      logger.debug ( "Finish" );
      return result;
   }

   private Part getInputStream ( Part message ) throws SvjException
   {
      Part  result   = null;
      byte[]   content, input;
      int      ic;

      try
      {
         logger.debug ("This is just an input stream");
         //System.out.println ("This is just an input stream");
         //System.out.println("---------------------------");
         Object obj = message.getContent ();
         InputStream is = (InputStream) obj;
         ic       = message.getSize ();
         content  = new byte[ic];
         ic       = is.read ( content );
         logger.debug ("Read byte : " + ic + ", Buffer size = " + content.length );
         input    = new byte [ic];
         System.arraycopy ( content, 0, input, 0, ic );
         logger.debug ("INPUT byte : " + input.length );

         //content  = Base64.decode ( input );
         //content  = com.sun.mail.util.BASE64DecoderStream.decode( input );
         //logger.debug ("Base64 result = " + new String ( content ) );

         //text     = decrypt ( input, privateKeyAlias, privateKeyPassword );
         //logger.debug ("Decrypt byte result = " + text );
      } catch ( Exception e )
      {
         throw new SvjException ( "Process InputStream object mail error", e );
      }
      return result;
   }

   public int getMessageType ( Part message ) throws SvjException
   {
      try
      {
         logger.debug ( "getContentType = " + message.getContentType () );  // isMimeType
         String messageContentType = ( ( MimePart ) message ).getHeader ( "Content-Type", ";" );
         logger.debug ( "ContentType: " + messageContentType );

         if ( message.isMimeType ( "multipart/signed" ) )
            return MULTIPART_SIGNED;

         if ( message.isMimeType ( "text/plain" ) )
            return TEXT_PLAIN;

         if ( message.isMimeType ( "application/pkcs7-mime" ) ||
              message.isMimeType ( "application/x-pkcs7-mime" ) )
         {
            if ( messageContentType.indexOf ( "smime-type=signed-data" ) > 0 )
               return APP_PKCS7_SIGNED;
            else
               return APP_PKCS7_ENV;
         }

         // Тип неясен - разобрать по типу вложения.

         Object obj = message.getContent ();

         if ( obj instanceof Message )         return MESSAGE;

         if ( obj instanceof Multipart )       return MULTIPART;

         if ( obj instanceof String )          return STRINGS;

         if (obj instanceof InputStream)       return INPUT_STREAMS;

         throw new SvjException ( "Unknow Message Type = " + messageContentType );
      } catch ( Exception e )
      {
         throw new SvjException ( "Get Message Type error", e );
      }

      //return result;
   }

   /**
    * Проверить подпись письма.
    * @param message
    */
   public void verify ( Part message ) throws SvjException
   {
      logger.debug ( "Start" );
      try
      {
         SMIMESigned signedMessage = new SMIMESigned ( message );
         //SMIMEEnveloped signedMessage = new SMIMEEnveloped ( ( MimeMessage ) message );

         //  Test
         //if ( unsignCertAlias.equalsIgnoreCase ( "nodetest") )  unsignCertAlias = "svj2";
         //if ( unsignCertAlias.equalsIgnoreCase ( "infosrv") )   unsignCertAlias = "svj2";

         logger.debug ( "Mail recieve ==> part verifying started. signedMessage: " +
              signedMessage + ", alias: " + unsignCertAlias );
         if ( !keyStore.isKeyEntry ( unsignCertAlias ) &&
              !keyStore.isCertificateEntry ( unsignCertAlias ) )
         {
            throw new SvjException ( "Can't find a certificate for alias: " + unsignCertAlias );
         }
         X509Certificate cert = ( X509Certificate ) keyStore.getCertificate ( unsignCertAlias );
         //logger.debug ( "Mail recieve ==> part verifying cert: " + cert );
         logger.debug ( "Mail recieve ==> checking validity of certificate..." );
         cert.checkValidity ();
         logger.debug ( "Mail recieve ==> checking validity of certificate done!" );

         // extract the information to verify the signatures.
         // SignerInfo blocks which contain the signatures
         SignerInformationStore signers = signedMessage.getSignerInfos ();
         logger.debug ( "Mail recieve ==> signers: " + signers );
         // check signers
         for ( Iterator it = signers.getSigners ().iterator (); it.hasNext (); )
         {
            SignerInformation signer = ( SignerInformation ) it.next ();
            logger.debug ( "Mail recieve ==> Next signer: " + signer );
            // verify that the sig is correct and that it was generated
            // when the certificate was current
            if ( signer.verify ( cert, SSLCons.BC_Provider ) )
            {
               logger.debug ( "Mail recieve ==> Next signer verified" );
               break;
            }
         }

      } catch ( SvjException se )
      {
         throw se;
      } catch ( Exception e )
      {
         logger.error ( "Verify failed: Invalid certificate", e );
         throw new SvjException ( "Verify failed: Invalid certificate.", e );
      }
      logger.debug ( "Finish" );
   }

   /**
    * Зашифровать письмо.
    * @param message
    * @return crypt string
    */
   public String encrypt ( String message, String alias ) throws SvjException
   {
      String result = null;
      X509Certificate cert;

      try
      {
         cert     = ( X509Certificate ) keyStore.getCertificate ( alias );
         if ( cert == null )
         {
            throw new SvjException ( "Can not get sertificat for private key. KeyAlias = "
                 + alias );
         }

        SMIMEEnvelopedGenerator  gen = new SMIMEEnvelopedGenerator();

        //gen.addKeyTransRecipient((X509Certificate)chain[0]);
        gen.addKeyTransRecipient(cert);

        //
        // create a subject key id - this has to be done the same way as
        // it is done in the certificate associated with the private key
        // version 3 only.
        //
        /*
        MessageDigest           dig = MessageDigest.getInstance("SHA1", "BC");

        dig.update(cert.getPublicKey().getEncoded());

        gen.addKeyTransRecipient(cert.getPublicKey(), dig.digest());
        */

        //
        // create the base for our message
        //
        MimeBodyPart    msg = new MimeBodyPart();
        msg.setText ( message );

        // MimeBodyPart    msg  = (MimeBodyPart) message;

        MimeBodyPart mp = gen.generate(msg, SMIMEEnvelopedGenerator.RC2_CBC, SSLCons.BC_Provider );
        //MimeBodyPart mp = gen.generate(msg, SMIMEEnvelopedGenerator.DES_EDE3_CBC, "BC");
        //
        // Get a Session object and create the mail message
        //
        Properties props = System.getProperties();
        Session session = Session.getDefaultInstance(props, null);

        Address fromUser = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
        Address toUser = new InternetAddress("example@bouncycastle.org");

        MimeMessage body = new MimeMessage(session);
        body.setFrom(fromUser);
        body.setRecipient(Message.RecipientType.TO, toUser);
        body.setSubject("example encrypted message");
        body.setContent(mp.getContent(), mp.getContentType());
        body.saveChanges();

        body.writeTo(new FileOutputStream("c:/Serg/FTC_Projects/InfoService/mp_cproc/test/cryptoMail/encrypted.msg"));
      } catch ( Exception e )
      {
         logger.error ( "Encrypt failed.", e );
         throw new SvjException ( "Encrypt failed.", e );
      }

      return result;
   }

   /**
    * Расшифровать сообщение своим приватным ключом.
    * @param message
    * @return decrypt as Part
    */
   public Part decrypt ( Part message )
        throws Exception
   {
      Part  result   = null;
      String   provider;
      X509Certificate cert;
      RecipientId recId;
      SMIMEEnveloped enveloped;
      RecipientInformationStore recipients;
      RecipientInformation recipient;
      Key key;
      byte[] content;
      MimeBodyPart res;

      logger.debug ( "SSL.decrypt: Start. privateKeyAlias = " + ourAlias
           + ", privateKeyPassword = " + ourKeyPassword );
      // find the certificate for the private key and generate a
      // suitable recipient identifier.
      try
      {
         if ( ourAlias == null )
         {
            throw new SvjException ( "Our private key alias is Null" );
         }

         cert     = ( X509Certificate ) keyStore.getCertificate ( ourAlias );
         if ( cert == null )
         {
            throw new SvjException ( "Can not get sertificat for private key. KeyAlias = "
                 + ourAlias );
         }

         recId    = new RecipientId ();
         BigInteger serialNumber = cert.getSerialNumber ();
         recId.setSerialNumber ( serialNumber );

         //recId.setIssuer ( ( ( X509Principal ) cert.getIssuerDN () ).getEncoded () );
         X500Principal x500 = cert.getIssuerX500Principal();
         byte[] encoded = x500.getEncoded();
         recId.setIssuer(encoded);

         enveloped      = new SMIMEEnveloped ( ( MimeMessage ) message );
         recipients  = enveloped.getRecipientInfos ();
         recipient   = recipients.get ( recId );
         if ( recipient == null )
         {
            throw new SvjException ( "RecipientInformation is null" );
         }

         logger.debug ( "Mail recieve ==> Get private key." );
         key      = keyStore.getKey ( ourAlias, ourKeyPassword.toCharArray() );
         if ( key == null )
         {
            throw new SvjException ( "Our private key for alias '" + ourAlias
                 + "' is null" );
         }

         //logger.debug ( "SSL.decrypt: Key = " + key );
         logger.debug ( "SSL.decrypt: Get content" );
         //type  = "SUN";      // DES ?
         provider  = SSLCons.BC_Provider;

         content  = recipient.getContent ( key, provider );

         //logger.debug ( "SSL.decrypt: Get res" );
         res      = SMIMEUtil.toMimeBodyPart ( content );

         //logger.debug ( "SSL.decrypt: Set res" );
         result   = res;
      } catch ( SvjException se )
      {
         throw se;
      } catch ( Exception e )
      {
         logger.error ( "SSL.decrypt: Error.", e );
         throw new SvjException ( "Decrypt error", e );
      }
      logger.debug ( "SSL.decrypt: Finish." );
      return result;
   }


   public String decrypt ( byte[] content )
        throws Exception
   {
      String   result   = null;
      logger.debug ( "SSL.decrypt: Start. privateKeyAlias = " + ourAlias
           + ", privateKeyPassword = " + ourKeyPassword );
      try
      {
         // get priv key
         Key privKey      = keyStore.getKey ( ourAlias, ourKeyPassword.toCharArray() );
         X509Certificate cert     = ( X509Certificate ) keyStore.getCertificate ( ourAlias );

         /*
         // RSA/NONE/OAEPWithSHA1AndMGF1Padding, AES/CTR/NoPadding  RSA
         Cipher   cipher = Cipher.getInstance("RSA/None/NoPadding", "BC");
         //Cipher   cipher = Cipher.getInstance("DES/None/NoPadding", "BC");  // Нет алгоритма
         cipher.init ( Cipher.DECRYPT_MODE, privKey );
         byte[] plainText = cipher.doFinal(content);
         result   = new String(plainText);
         */

         CMSEnvelopedData  enveloped = new CMSEnvelopedData(content);
         // look for our recipient identifier
         RecipientId     recId = new RecipientId();

         recId.setSerialNumber(cert.getSerialNumber());
         recId.setIssuer(cert.getIssuerX500Principal().getEncoded());

         RecipientInformationStore   recipients = enveloped.getRecipientInfos();
         RecipientInformation        recipient = recipients.get(recId);

         if (recipient != null)
         {
             // decrypt the data
             byte[] recData = recipient.getContent(privKey, SSLCons.BC_Provider );
            result   = new String(recData);
         }

      } catch ( Exception e )
      {
         logger.error ( "SSL.decrypt: Error.", e );
         throw new SvjException ( "Can not decrypt byte array.", e );
      }
      logger.debug ( "SSL.decrypt: Finish" );
      return result;
   }

   public void setUnsignAlias ( String  unsignCertAlias )
   {
      this.unsignCertAlias = processPassword ( unsignCertAlias );
   }

//======================================================================

}

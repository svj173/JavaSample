package com.svj.utils.ssl;


import com.svj.utils.SvjException;
import com.svj.utils.HtmlTools;

import javax.net.ssl.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.io.*;
import java.util.Hashtable;
import java.net.URL;
import java.net.Socket;
import java.net.ServerSocket;

import org.apache.log4j.Logger;

/**
 * Построитель SSL стокетов. Использует подставляемые хранилища ключей
 * (а не по умолчанию).
 * Старая версия. Новая - @see SslManager.
 * <BR> <BR> User: Zhiganov <BR> Date: 18.08.2005 <BR> Time: 17:57:52
 */
public class socket
{
   private static final Logger logger = Logger.getLogger(socket.class);

   /** For debug */
   private static final String className = "socket";

   /* Полный урл без параметров.
      Например: URL = https://www.ntcgsm.ru/rp/cgi-bin/cgi.exe */
   //private  URL               url               = null;

   /** SSL фабрика, созданная на основе предложенных хранилищ ключей. */
   private  SSLSocketFactory        sslSocketFactory        = null;
   private  SSLServerSocketFactory  sslServerSocketFactory  = null;

   private final int SERVER   = 0;
   private final int CLIENT   = 1;


   /* Таймаут для созданного SSL сокета. Чтобы не было бесконечного ожидания ответа. */
   //private  int   timeout;


   public socket ( String keyStoreFileName, String keyStorePassword )
        throws Exception
   {
      sslSocketFactory  = createSocketFactory ( keyStoreFileName, keyStorePassword );
   }

   public socket ( String keyStoreFileName, String keyStorePassword, String keyStoreType )
        throws Exception
   {
      sslServerSocketFactory  = createSslServerSocketFactory
           ( keyStoreFileName, keyStorePassword, keyStoreType );
   }


   /**
    *
    * @param keyStoreFileName
    * @param keyStorePassword
    * @param keyStoreType
    * @return
    * @throws Exception
    */
   private SSLServerSocketFactory createSslServerSocketFactory
        ( String keyStoreFileName, String keyStorePassword, String keyStoreType )
        throws Exception
   {
      SSLServerSocketFactory  result   = null;

      try
      {
        logger.debug("Start.");
        javax.net.ssl.SSLContext ctx = javax.net.ssl.SSLContext.getInstance("TLS");
        javax.net.ssl.KeyManagerFactory kmf = javax.net.ssl.KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance(keyStoreType);

        ks.load(
          new FileInputStream(keyStoreFileName), keyStorePassword.toCharArray()
        );
        kmf.init(ks, keyStorePassword.toCharArray());
        javax.net.ssl.TrustManagerFactory tm = javax.net.ssl.TrustManagerFactory.getInstance("SunX509");
        tm.init(ks);
        javax.net.ssl.TrustManager[] tma = tm.getTrustManagers();
        ctx.init(kmf.getKeyManagers(), tma, null);

        result = ctx.getServerSocketFactory();
         logger.debug("Finish.");
      } catch (Exception e) {
         logger.error ( "Create SSL server error.", e );
        throw new SvjException ( "Can't create SSL{Server}SocketFactory!" );
      }
      return   result;
   }

   public socket ()    throws Exception
   {
      sslSocketFactory  = createDefaultSocketFactory ();
   }

   public ServerSocket  createSSLServerSocket ( int port )
        throws Exception
   {
      if ( sslServerSocketFactory == null )
         throw new SvjException ("sslServerSocketFactory is NULL");
      return sslServerSocketFactory.createServerSocket(port);
   }

   /**
    * Создать фабрику SSL сокетов.
    * Используется фабрика по умолчанию, которая прописана в java.security
    */
   public SSLSocketFactory createDefaultSocketFactory () throws Exception
   {
      logger.debug ( "Start" );

      SSLSocketFactory  result      = null;
      result   = (SSLSocketFactory) SSLSocketFactory.getDefault();
      logger.debug ( "Finish. SSLSocketFactory = " + result );
      return result;
   }


   /**
    * Создать фабрику SSL сокетов.
    * Используются все свои настройки и особенности.
    * Хранилище ключей и доверенных сертификатов здесь одно и то же.
    */
   public SSLSocketFactory createSocketFactory
           ( String keyStoreFileName,   String keyStorePassword )
           throws Exception
   {
      logger.debug ( "Start" );

      return   createSocketFactory
              ( keyStoreFileName, keyStorePassword, keyStoreFileName, keyStorePassword );
   }


   /**
    * Создать фабрику SSL сокетов.
    * Используются все свои настройки и особенности.
    */
   public SSLSocketFactory createSocketFactory
           ( String keyStoreFileName,   String keyStorePassword,
             String trustStoreFileName, String trustStorePassword )
           throws Exception
   {
      logger.debug ( "Start" );

      SSLSocketFactory  result         = null;
      KeyStore          keyStore;
      KeyManager[]      keyManagers;
      TrustManager[]    trustedManagers;
      SecureRandom      secureRandom   = null;
      SSLContext        sslContext;

      char[]   charKeyPassword     = keyStorePassword.toCharArray ();
      char[]   charTrustPassword   = trustStorePassword.toCharArray ();

      keyStore  = getKeyStore( keyStoreFileName, charKeyPassword );
      logger.debug ( "-- Create KeyStore" );
      keyManagers = getKeyManagers ( keyStore, charKeyPassword, "SunX509" );
      logger.debug ( "-- Create KeyManager" );
      trustedManagers   = getTrustManagers ( trustStoreFileName, charTrustPassword, "SunX509", "JKS" );
      logger.debug ( "-- Create TrustManager" );
      secureRandom   = getSecureRandom ( "SHA1PRNG", "SUN" );
      sslContext  = getSslContext ( keyManagers, trustedManagers, secureRandom, "TLS" );
      //logger.debug ( "-- Create SSLContext" );
      // Создать Фабрику SSL сокетов
      result  = sslContext.getSocketFactory ();
      //logger.debug ( "-- Create SocketFactory = " + result );
      logger.debug ( "Finish" );
      return   result;
   }

   /**
    * Создать SSLContext
    * <BR> - Получить и инициализировать SSL-контекст базовой реализации при
    *   заданных диспетчерах ключей, доверенных диспетчерах и значении
    *   защищенного случайного числа.
    *
    * @param keyManagers
    * @param trustedManagers
    * @param secureRandom
    * @param type               Тип (строка): TLS, SUN и т.д.
    * @return
    * @throws Exception
    */
   private SSLContext getSslContext (
           KeyManager[] keyManagers, TrustManager[] trustedManagers,
           SecureRandom secureRandom, String type )
           throws Exception
   {
      String   methodName  = className + ".getSslContext:: ";
      SSLContext result   = null;
      String   str;
      try
      {
         //logger.debug ( " Create SSLContext" );
         // Создать SSL-контекст по заданнному провайдеру
         //sslContext = SSLContext.getInstance ( "SUN" );
         result = SSLContext.getInstance ( type );
         // Инициализировать контекст
         //System.out.println ( "-- Start Create sslContext. keyManagers = " + keyManagers
         //   + ", trustedManagers = " + trustedManagers + ", secureRandom = " + secureRandom );
         result.init ( keyManagers, trustedManagers, secureRandom );
         //sslContext.init ( keyManagers, trustedManagers, null );
      } catch ( NoSuchAlgorithmException e )
      {
         str   = "No this algorithm: " + e.toString();
         throw new Exception ( methodName + str );
      } catch ( KeyManagementException e )
      {
         str   = "KeyManagement Error";
         throw new Exception ( methodName + str );
      }
      return result;
   }

   /**
    * Создать Генератор случайных чисел
    * <BR> - Получить защищенное случайное число
    * -- Почему то в яве 1.0.3 не работает. Не находит алгоритм SHA1PRNG
    *
    * @param algorithm        "SHA1PRNG"
    * @param provider         "SUN", "TLS"?
    * @return
    * @throws Exception
    */
   private SecureRandom getSecureRandom ( String algorithm, String provider )
           throws Exception
   {
      String   methodName  = className + ".getSecureRandom:: ";
      SecureRandom result   = null;
      String   str;
      try
      {
         //logger.debug ( " Create SecureRandom" );
         // Создать экземпляр защищенного случайного числа при заданном
         //    алгоритме и провайдере
         result = SecureRandom.getInstance ( algorithm, provider );
      } catch ( NoSuchProviderException e )
      {
         str   = "No this Provider: " + provider;
         throw new Exception ( methodName + str );
      } catch ( NoSuchAlgorithmException e )
      {
         str   = "No this algorithm: " + algorithm;
         throw new Exception ( methodName + str );
      }
      //System.out.println ( "-- Create SecureRandom" );
      return result;
   }

   /**
    *  Создать пул доверенных диспетчеров
    * <BR> - Получить доверенные диспетчеры базовой реализации
    *
    * @param trustStoreFileName
    * @param charTrustPassword
    * @param trustManagerAlgorithm     "SunX509"
    * @param keyStoreType     "JKS"
    * @return
    * @throws Exception
    */
   private TrustManager[] getTrustManagers (
           String trustStoreFileName, char[] charTrustPassword,
           String trustManagerAlgorithm, String keyStoreType )
           throws Exception
   {
      String   methodName  = className + ".getTrustManagers:: ";
      TrustManager[] result   = null;
      String   str;
      try
      {
         //logger.debug ( " Create TrustManagerFactory" );
         // Создать производителя доверенных диспетчеров
         TrustManagerFactory trustManagerFactory;
         trustManagerFactory = TrustManagerFactory.getInstance ( trustManagerAlgorithm );
         // Взять файл доверенных открытых ключей клиентов
	      KeyStore ts = KeyStore.getInstance ( keyStoreType );
	      ts.load ( new FileInputStream(trustStoreFileName), charTrustPassword );
         // Инициализировать производителя доверенных диспетчеров
         trustManagerFactory.init ( ts );     // keyStore
         // Получить доверенные диспетчеры
         result = trustManagerFactory.getTrustManagers ();
      } catch ( NoSuchAlgorithmException e )
      {
         str   = "No algorithm: " + trustManagerAlgorithm;
         throw new Exception ( methodName + str );
      } catch ( KeyStoreException e )
      {
         str   = "Can't trustManagerFactory.init:: KeyStoreException. ";
         throw new Exception ( methodName + str );
      } catch ( Exception ex )
      {
         str   = "Can't trustManagerFactory.init:: Exception. ";
         throw new Exception ( methodName + str );
      }
      return result;
   }

   /**
    *  Создать пул диспетчеров ключей
    * <BR> - Создать диспетчеры ключей базовой реализации для заданного хранилища ключей
    *
    * @param keyStore
    * @param charKeyPassword
    * @param keyManagerAlgorithm
    * @return
    * @throws Exception
    */
   private KeyManager[] getKeyManagers (
           KeyStore keyStore, char[] charKeyPassword, String keyManagerAlgorithm )
           throws Exception
   {
      String   methodName  = className + ".getKeyManagers:: ";
      KeyManager[] result   = null;
      String   str;
      try
      {
         //logger.debug ( " Create KeyManagerFactory" );
         // Создать производителя диспетчеров ключей по заданному алгоритму
         //keyManagerAlgorithm = "SunX509";
         KeyManagerFactory    keyManagerFactory;
         keyManagerFactory = KeyManagerFactory.getInstance ( keyManagerAlgorithm );
         // Инициализировать производителя диспетчеров ключей при заданных
         //       пароле и хранилище ключей
         // - Задать пароль - возможно, тоже в конфиг-файле
         //String keyManagerPassword = "dtuyer45fsr";
         keyManagerFactory.init ( keyStore, charKeyPassword );
         // Получить набор диспетчеров от производителя
         result = keyManagerFactory.getKeyManagers ();
      } catch ( NoSuchAlgorithmException e )
      {
         str   = "No algorithm: " + keyManagerAlgorithm;
         throw new Exception ( methodName + str );
      } catch ( UnrecoverableKeyException e )
      {
         str   = "Can't keyManagerFactory.init. UnrecoverableKeyException.";
         throw new Exception ( methodName + str );
      } catch ( KeyStoreException e )
      {
         str   = "Can't keyManagerFactory.init. KeyStoreException.";
         throw new Exception ( methodName + str );
      }
      return result;
   }

   /**
    *  Получаем указатель на хранящийся набор сертификатов и ключей.
    * <BR> - Получить и загрузить стандартный обьект KeyStore
    *
    * @param keyStoreFileName
    * @param charKeyPassword
    * @return
    * @throws Exception
    */
   private KeyStore getKeyStore ( String keyStoreFileName, char[] charKeyPassword )
           throws Exception
   {
      String   methodName  = className + ".getKeystore:: ";
      KeyStore result   = null;
      String   str;
      try
      {
         //logger.debug ( " Create KeyStore. file = " + keyStoreFileName
         //        + ", pass = " + keyStorePassword );
         // Получить экземпляр хранилища ключей
         String   keyStoreType   = "JKS";
         logger.debug ( "-- Start Create KeyStore. file = " + keyStoreFileName );
         result = KeyStore.getInstance ( keyStoreType );
         // Создать поток файла хранилища ключей
         FileInputStream   fis   = new FileInputStream ( keyStoreFileName );
         // Загрузить из потока файла само хранилище ключей
         result.load ( fis, charKeyPassword );
         //keyStore.load ( fis, jksPassword );
      } catch ( NoSuchAlgorithmException noAlg )   {
         str   = "Key Store load Error: NoSuchAlgorithmException.";
         //noAlg.printStackTrace ();
         throw new Exception ( methodName + str );
      } catch ( FileNotFoundException e )
      {
         str   = "Key Store File '" + keyStoreFileName + "' not found.";
         throw new Exception ( methodName + str );
      } catch ( IOException e )
      {
         str   = "Key Store load Error: IOException.";
         throw new Exception ( methodName + str );
      } catch ( CertificateException e )
      {
         str   = "Key Store load Error: CertificateException.";
         throw new Exception ( methodName + str );
      } catch ( KeyStoreException e )
      {
         str   = "Key Store Error ";
         throw new Exception ( methodName + str );
      }
      return result;
   }


   /**
    * Отправить разовый GET запрос.
    * НЕ сделал.
    * @return
    * @throws SvjException
    */
   public String  sendGetRequest ( Hashtable data )
           throws SvjException
   {
      logger.debug ( "Start.");
      logger.debug ( "dataPair = " + data );

      String   xmlResponse, dataRequest, getRequest;
      xmlResponse = "";
      // Сформировать урл
      //url   = createHttpsUrl (host);
      // Создать данные
      dataRequest = HtmlTools.createDataRequest ( data );
      //getRequest  = createGetRequest ( dataRequest );
      // Создать сокет
      //createSSLSocket ( sslSocketFactory, url.getHost (), url.getPort () );
      // Отправить данные
      //URL   url          = createHttpsUrl (strUrl);
      //xmlResponse = sendRequest ( url, getRequest );
      // Закрыть сокет
      //close();

      logger.debug ( "Finish. xmlResponse = " + xmlResponse );
      return  xmlResponse;
   }

   /**
    * Отправить на сокет строку запроса и получить строку ответа.
    * @param request
    * @return Результирующая строка
    */
   public String sendRequest ( String strUrl, int timeout, String request )
           throws SvjException
   {
      String   methodName  = className + ".sendRequest:: ";
      logger.debug ( "Start" );
      String      str, line, xmlResponse;
      SSLSocket   sslSocket   = null;
      PrintWriter    out   = null;
      BufferedReader in    = null;
      URL   url;

      try
      {
         // Инкапсулировать данные в POST запрос.
         //data  = createPostRequest (request);
         logger.debug ( "request = " + request );

         url   = HtmlTools.createHttpsUrl ( strUrl );

         try
         {
            String   host   = url.getHost ();
            int      port   = url.getPort ();
            if ( port < 0 )   port  = SSLCons.HTTPS_DEFAULT_PORT; // 443
            logger.debug ( "Create socket: host = " + host + ":" + port
                 + ", timeout = " + timeout + " sec."  );
            sslSocket   = (SSLSocket) sslSocketFactory.createSocket ( host, port );
            if ( timeout > 0 )
               sslSocket.setSoTimeout ( timeout * 1000 );
            sslSocket.setKeepAlive ( true );
            logger.debug ( " Socket = " + sslSocket );
            sslSocket.startHandshake();
            logger.debug ( " Get IN and OUT." );
            out = new PrintWriter ( new BufferedWriter (  new OutputStreamWriter (
                      sslSocket.getOutputStream())));
            in  = new BufferedReader ( new InputStreamReader
                    ( sslSocket.getInputStream (), "windows-1251" ) );
            // Отправить Уведомление
            logger.debug ( " Send request." );
            out.println ( request );
            out.flush ();
         } catch ( Exception e )
         {
            // Отметить ошибку передачи данных
            str   = methodName + "ERROR: Send request. ";
            logger.error ( str + e.toString() );
            throw new SvjException ( str, e );
            //e.printStackTrace ();
         }

         // Проверить - не было ли ошибки при передаче
         if ( out.checkError() )
         {
            // The client  closed the connection
            str   = methodName + "ERROR: Get error message after send request.";
            logger.error ( str );
            throw new SvjException ( str );
         }


         logger.debug ( "Get response" );
         xmlResponse = "";

         try
         {
            // -------------- Получить Ответ в XML форме ----------------------
            while ((line = in.readLine()) != null)
            {
               //logger.debug ( " line = " + line );
               xmlResponse += line + "\r\n";
            }
         } catch ( Exception e )
         {
            str   = methodName + "ERROR: Get Response. ";
            logger.error ( str + e.toString () );
            throw new SvjException ( str, e );
            //e.printStackTrace ();
         }
         logger.debug ( " xmlResponse = " + xmlResponse );

      } finally
      {
         // Закрыть сокет
         try
         {
            if ( in  != null )   in.close();
            if ( out != null )   out.close();
            if ( sslSocket != null )   sslSocket.close();
         } catch ( IOException e )           {
            logger.debug ( " Client socket closed error. Error = "
                    + e.toString () );
         }
         logger.debug ( "Finish." );
      }

      return xmlResponse;
   }

   public SSLSocket createSslSocket ( String hostUrl, int timeout, boolean keepAlive )
        throws SvjException
   {
      SSLSocket   socket   = null;
      String   str;
      URL   url;
      try
      {
         url   = HtmlTools.createHttpsUrl ( hostUrl );
         String   host   = url.getHost ();
         int      port   = url.getPort ();
         if ( port < 0 )   port  = SSLCons.HTTPS_DEFAULT_PORT; // 443
         logger.debug ( "Create socket: host = " + host + ":" + port
              + ", timeout = " + timeout + " sec, keepAlive = " + keepAlive  );
         socket   = (SSLSocket) sslSocketFactory.createSocket ( host, port );
         if ( timeout > 0 )
            socket.setSoTimeout ( timeout * 1000 );
         if ( keepAlive )
            socket.setKeepAlive ( true );
         logger.debug ( "Socket = " + socket );
         //socket.startHandshake();
      } catch ( Exception e )
      {
         // Отметить ошибку передачи данных
         str   = "Create SSl Socket ERROR.";
         logger.error ( str + e.toString() );
         throw new SvjException ( str, e );
      }
      return   socket;
   }

   public void send ( Socket socket, String data ) throws SvjException
   {
      OutputStream    out   = null;
      String   str;
      try
      {
         out   = socket.getOutputStream ();
         out.write ( data.getBytes() );
         out.flush ();

      } catch ( Exception e )
      {
         // Отметить ошибку передачи данных
         str   = "Send to SSl Socket ERROR.";
         logger.error ( str + e.toString() );
         throw new SvjException ( str, e );
      }

   }

   public String readResponse ( Socket socket ) throws SvjException
   {
      logger.debug ( "Get response" );
      String response, str;
      int b;
      InputStream in = null;
      ByteArrayOutputStream baos;
      response = "";

      try
      {
         in = socket.getInputStream ();

         // -------------- Получить Ответ ----------------------
         baos = new ByteArrayOutputStream ();

         while ( ( b = in.read () ) != -1 )
         {
            baos.write ( b );
         }

         // Перекодирование байтов в строку
         // с использованием кодировки по умолчанию
         response = baos.toString ();

         // Если нужна конкретная кодировка
         // response = baos.toString("Cp1251");

      } catch ( Exception e )
      {
         str = "ERROR: Get Response. ";
         logger.error ( str + e.toString () );
         throw new SvjException ( str, e );
      }
      logger.debug ( "Response = " + response );
      return response;
   }

   /**
    * Закрыть сокет. Освободить входной порт.
    * @param socket
    */
   public Socket closeSocket ( Socket socket )
   {
      if ( socket != null )
      {
         try
         {
            socket.shutdownInput();
         } catch ( Exception e )      {  }
         try
         {
            socket.shutdownOutput ();
         } catch ( Exception e )      {  }
         try
         {
            socket.close();
         } catch ( Exception e )      {  }
      }
      return null;
   }

   public Socket createSocket ( String infosrvHost, int timeout, boolean keepAlive )
        throws SvjException
   {
      Socket   result;
      URL      url;
      int      port;
      String   host, str;
      result   = null;
      try
      {
         url      = new URL ( infosrvHost );
         host     = url.getHost ();
         port     = url.getPort ();
         result   = new Socket ( host, port );
         if ( timeout > 0 )   result.setSoTimeout ( timeout * 1000 );
         if ( keepAlive )   result.setKeepAlive ( true );
      } catch ( Exception e )
      {
         str   = "Create simple socket error. ";
         logger.error ( str, e );
         throw new SvjException ( str + e.getMessage (), e );
      }
      return result;
   }


//=============================================================================

}

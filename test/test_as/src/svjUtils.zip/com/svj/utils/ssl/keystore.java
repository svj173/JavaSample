package com.svj.utils.ssl;


import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.io.*;
import java.util.Enumeration;
import java.util.Properties;
import java.security.*;

import com.sun.net.ssl.internal.ssl.Provider;
import com.svj.utils.FileTools;
import com.svj.utils.string.Conversion;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.apache.log4j.Logger;

/**
 * Класс работает с хранилищами ключей.
 * <BR> <BR> User: Zhiganov <BR> Date: 18.08.2005 <BR> Time: 18:00:57
 */
public class keystore
{
   private static final Logger logger = Logger.getLogger(keystore.class);

   private  KeyStore keyStore = null;

   private  String   fileName = "";

   static final int FILE_HEADER        = 0x7e01;  // File header.
   static final int DATA_BLOCK         = 1; // Data block
   static final int FINAL_DATA_BLOCK   = 2; // Final data block.
   static final int SIG_BLOCK          = 3; // Signature block
   static final int CERT_BLOCK         = 4; // Certificate block.

   static final int KEY_BLOCK          = 16; // Key block
   static final int IV_BLOCK           = 17; // IV block
   static final int LOCK_BLOCK         = 18; // Locking block


   public keystore ()
   {
      // Add Providers
      // - Add PKCS12 provider
      Security.addProvider ( new BouncyCastleProvider () );
      // - Add SSL provider
      Security.addProvider ( new Provider () );

      keyStore = null;
   }

   /**
    * Загрузить файл-хранилище.
    */
   public void loadStore ( String  fileName, String filePassword, String ksType )
        throws Exception
   {
      FileInputStream	fs;
      String			   type;
      char[] password   = null;

      if ( filePassword != null )
         password = filePassword.toCharArray ();
      if ( ksType == null )   ksType = "PKCS12";
      if ( ksType.equalsIgnoreCase ( "PKCS12" ) ) type = "BC";   // BouncyCastle
      else  type  = "SUN";

      logger.debug ( "load '" + fileName + "' file. ksType = " + ksType
              + ", type = " + type );
      fs			= new FileInputStream ( fileName );
      keyStore = KeyStore.getInstance ( ksType, type );
      keyStore.load ( fs, password );

      fs.close ();
      this.fileName  = fileName;

   }

   public Enumeration   aliases () throws KeyStoreException
   {
      return   keyStore.aliases ();
   }

   public String  getFileName ()
   {
      return fileName;
   }

   /**
    * Выдать тип ключа - Ключ или Сертификат.
    *
    * @param alias
    * @return
    * @throws KeyStoreException
    */
   public String getType ( String alias ) throws KeyStoreException
   {
      String   result   = "";
      if ( keyStore.isKeyEntry ( alias ) )   result   += "Key";
      if ( keyStore.isCertificateEntry ( alias ) )  result   += "Cert";
      return result;
   }

   /**
    * Выдать сертификатную информацию для ключа по его алиасу.
    * @param alias
    * @return
    * @throws KeyStoreException
    */
   public String getCertInfo ( String alias ) throws KeyStoreException
   {
      String   result   = "";
      Certificate cert = keyStore.getCertificate ( alias );
      if ( cert != null )       result   = cert.toString ();
      return result;
   }


   /**
    * Шифровать текст.
    *
    * @param sslKeyStore   Путь до хранилища ключей
    * @param sslKeyAlias   Алиас в хранилище
    * @param ksType        Тип хранилища ключей - SUN, PKCS12, ...
    * @param keyStorePassword        Пароль на доступ к файлу хранилища ключей (если есть).
    * @param text          Текстовое сообщение для шифрации.
    * @param compression   Режим компрессии.
    * @param codeType      Тип кодировки русских букв.
    * @return string
    */
   public String encrypt ( String sslKeyStore, String sslKeyAlias, String ksType,
                           String keyStorePassword, String text,
                           int compression, String codeType )
        throws Exception
   {
      String   result   = "";
      // Загрузить хранилище
      loadStore ( sslKeyStore, keyStorePassword, ksType );

      return result;
   }

   /**
    * Подписать и зашифровать текст. НЕ реализовано.
    *
    * @param sslKeyStore
    * @param sslKeyAlias
    * @param signKey
    * @param signPassphrase
    * @param text
    * @param compression
    * @param codeType
    * @param signFormat
    * @return string
    */
   public String encryptAndSign ( String sslKeyStore, String sslKeyAlias, String signKey,
                                  String signPassphrase, String text, int compression,
                                  String codeType, String signFormat )
   {
      String   result   = "";
      return result;
   }

   /**
    * Подписать текст. Формирует только подпись для данного текста.
    *
    * @param algoritm
    * @param privateKey
    * @param text
    * @return
    * @throws Exception
    */
   public String  sign ( String algoritm, PrivateKey privateKey, String text )
        throws Exception
   {
      String   result;
      Signature sig;
      // Set up signature object.
      sig  = Signature.getInstance ( algoritm, "BC" );
      //sig = Signature.getInstance ( "MD5withRSA", "BC" );
      sig.initSign ( privateKey );
      //sig.initSign ( my_private, sec_rand ); // Initialize with my private signing key.
      sig.update ( text.getBytes() );
      // Получить подписанную строку
      byte[] b = sig.sign();
      // Преобразовать байты в символьный текст - Это только подпись.
      result   = Conversion.byteArrayToBase64String(b);
      logger.debug ( "sig = " + sig );

      return result;
   }

   public   void signToFile ( PrivateKey privateKey, String text, String outFileName, String alias )
        throws Exception
   {
      // Сформирвоать сигнатуру, с помощью которой потом подпишем текст
      Signature sig = createSignature ( privateKey );

      // Сохранить в файле. Пишет какой-то байтовый бинарный формат. Неизвестно как его читать.
      saveSignToFile ( outFileName, sig, alias, text );

   }

   private void saveSignToFile ( Signature sig, String text )
        throws Exception
   {
      byte[] message = text.getBytes ();
      System.out.println ("Read " + message.length + " bytes of message data.");

      // Compute the signature, print base-64 encoded.
      sig.update (message);
      byte[] signature = sig.sign ();
      System.out.println (
          "Signature: " + new String (
              org.bouncycastle.util.encoders.Base64.encode (signature)));

   }

   private void saveSignToFile ( String outFileName, Signature sig, String alias, String text )
        throws Exception
   {
      byte[] tmp;
      X509Certificate   my_cert = (X509Certificate) keyStore.getCertificate(alias);
      // Создать поток
      File file_out  = new File ( outFileName );
      FileOutputStream file_str = new FileOutputStream ( file_out ); // Final output stream.
      SignatureOutputStream sig_str = new SignatureOutputStream ( file_str, sig ); // As it says.
      DataOutputStream data_str = new DataOutputStream ( sig_str ); // See java doc.

      data_str.writeShort ( FILE_HEADER ); // Write a file header.

      data_str.writeShort ( DATA_BLOCK ); // Write data block header.
      data_str.writeInt ( text.length() ); // Write length.
      data_str.write ( text.getBytes () ); // Write encrypted data.

      data_str.writeShort ( CERT_BLOCK ); // Cert block header.
      tmp = my_cert.getEncoded (); // Get encoded in a byte array.
      data_str.writeInt ( tmp.length ); // Write length.
      data_str.write ( tmp ); // Write data.

      //
      // The last block we write out is our
      // certificate block.
      //

      System.out.println ( file_out.getName () + " >> Write out Signature code block." );
      data_str.writeShort ( SIG_BLOCK ); // Write Header.
      data_str.flush (); // Flush it..

      tmp = sig.sign (); // Get signature code.
      data_str.writeInt ( tmp.length ); // Write length.
      data_str.write ( tmp ); // Write data.

      data_str.flush ();
      data_str.close ();
   }

   private Signature createSignature ( PrivateKey privateKey )
        throws Exception
   {
      Signature result;
      // Генератор случайных чисел
      byte[] lock = new byte[24];
      SecureRandom   sec_rand = SecureRandom.getInstance ( "SHA1PRNG", "SUN" );

      sec_rand.nextBytes ( lock );

      result = Signature.getInstance ( "MD5withRSA", "BC" );
      result.initSign ( privateKey );
      result.update ( lock ); // put plain text of lock data into signature.

      // либо
      //SecureRandom   sec_rand = new SecureRandom ();
      //result.initSign ( privateKey, sec_rand );

      return result;
   }

   public PrivateKey getPrivateKey ( String alias, String ksPassword )
        throws Exception
   {
      logger.debug ( "get Key. alias = " + alias + ", passw =  " + ksPassword );
      PrivateKey  prKey = null;
      char[]   passwd   = ksPassword.toCharArray ();
      if ( keyStore.isKeyEntry ( alias) )
         logger.debug ( "KeyStore has alias = " + alias );
      //Object   obj   = keyStore.getKey(alias, passwd); // Get private key.
      //logger.debug ( "Key " + obj.getClass ().getName() );
      //Key key  = keyStore.getKey(alias, passwd); // Get private key.
      prKey = (PrivateKey)keyStore.getKey(alias, passwd); // Get private key.
      //my_cert = (X509Certificate) keyStore.getCertificate(l); // Get Signing Certificate
      return   prKey;
   }

   /**
    * Загружает приватный ключ, записанный в файле в бинарном виде.
    * @param fileName
    * @return
    * @throws Exception
    */
   public PrivateKey loadPrivateKey ( String fileName ) throws Exception
   {
      logger.debug ( "fileName = " + fileName );
      PrivateKey  pk = null;
      FileInputStream   fin   = new FileInputStream ( fileName );
      ObjectInputStream keyFile  = new ObjectInputStream ( fin );
      pk = (PrivateKey) keyFile.readObject ();
      keyFile.close();
      return   pk;
   }
//================================================================================
   /**
    * For TEST.
    * @param args
    */
   public static void main ( String[] args )
   {
      String   str, messText, keyFileName, filePass, ksType, signText, algoritm,
           alias, prvKeyFileName, keyPass, signFileName, inputFileName;
      Properties        prop;
      keystore   ssl;
      PrivateKey  key;
      //
      if ( args.length < 1 )
      {
         System.out.println ( "Use: class config_file" );
         System.exit ( 10 );
      }

      signText = "no";

      try
      {
         // Загрузить свойства
         prop        = FileTools.loadProperties ( args[0] );
         // Прописать логгер
         str         = prop.getProperty ( "logFile" );
         System.out.println ( "logger = " + str );
         // Создать обьект
         ssl   = new keystore ();
         // Взять исходные данные
         prvKeyFileName = prop.getProperty ( "prvKeyFileName" );
         keyFileName    = prop.getProperty ( "keyFileName" );
         filePass       = prop.getProperty ( "filePass" );
         ksType         = prop.getProperty ( "ksType" );
         alias          = prop.getProperty ( "alias" );
         keyPass        = prop.getProperty ( "keyPass" );
         // Взять тип алгоритма
         algoritm       = prop.getProperty ( "algoritm" );
         signFileName   = prop.getProperty ( "signFileName" );
         inputFileName  = prop.getProperty ( "inputFileName" );

         // Загрузить хранилище - P12
         ssl.loadStore ( keyFileName, filePass, ksType );
         // Взять приватный ключ из хранилища
         key            = ssl.getPrivateKey ( alias, keyPass );
         //key            = ssl.loadPrivateKey ( prvKeyFileName );

         /*
         // Сохранить ключ в файле как поток байт.
         String fileKey = "c:/Serg/FTC_Projects/MGate_Local/mserver/test/ssl/sign/privkey.der";
         byte[] bkey = key.getEncoded ();
         FileOutputStream fos = new  FileOutputStream ( fileKey );
         fos.write (bkey);
         fos.close ();
         */

         // Загрузить из файла приватный ключ
         //key   = ssl.loadPrivateKey ( prvKeyFileName );

         // Example
         //my_private = (PrivateKey)key_store.getKey(alias, ks_pass); // Get private key.
         //X509Certificate my_cert = (X509Certificate)key_store.getCertificate(alias); // Get Signing Certificate

         // Сформирвоать исходный текст
         //messText    = "Проверка SSL подписи";
         messText    = FileTools.loadFile ( inputFileName );

         // Подписать и получить результат в виде текста.
         signText    = ssl.sign ( algoritm, key, messText );
         // Сохранить в файле
         //Utils.writeToFile ( signFileName, signText.getBytes() );
         //KeyPair kp  = new KeyPair ( );
         //System.out.println ( "signText = " + signText );

         // Подписать и сохранить в файле
         //ssl.signToFile ( key, messText, "test.msg", alias );
      } catch ( Exception e )
      {
         System.out.println ( "Error" );
         e.printStackTrace ();
      } finally   {
         System.out.println ( "main. Finish. signText = " + signText );
         System.exit ( 0 );
      }
   }

//================================================================================

}

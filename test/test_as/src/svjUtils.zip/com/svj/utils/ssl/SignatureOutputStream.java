package com.svj.utils.ssl;

import java.io.*;
import java.security.Signature;
import java.security.SignatureException;

/**
 * Signature output stream is a stream wrapper that passes data though a Signature
 * object before passing it on.
 * <BR> <BR> User: Zhiganov <BR> Date: 22.08.2005 <BR> Time: 15:33:55
 */
public class SignatureOutputStream    extends FilterOutputStream
{
   private Signature sig = null;

   public SignatureOutputStream ( OutputStream out,
                                  Signature sig )
   {
      super ( out );
      this.sig = sig;
   }

   public void write ( int b )
        throws IOException
   {
      try
      {
         sig.update ( ( byte ) b );
      } catch ( SignatureException s_ex )
      {
         throw new IOException ( s_ex.getMessage () );
      }
      out.write ( b );
   }

   public void write ( byte[] b )
        throws IOException
   {
      try
      {
         sig.update ( b );
      } catch ( SignatureException s_ex )
      {
         throw new IOException ( s_ex.getMessage () );
      }

      out.write ( b );
   }

   public void write ( byte[] b, int o, int l )
        throws IOException
   {
      try
      {
         sig.update ( b, o, l );
      } catch ( SignatureException s_ex )
      {
         throw( new IOException ( s_ex.getMessage () ) );
      }

      out.write ( b, o, l );
   }
   
}

package com.svj.utils.ssl;

/**
 * <BR> <BR> User: Zhiganov <BR> Date: 18.08.2005 <BR> Time: 11:44:39
 */
public class SSLCons
{
   public static final String   BC_Provider     = "BC";
   public static final String   SUN_Provider    = "SUN";
   public static final String   SSL    = "SSL";
   public static final String   TLS    = "TLS";
   public static final String   JKS    = "JKS";
   public static final String   PKCS12    = "PKCS12";


   // HTTP header field names.
   public static final String HEADER_POST					   = "POST";
   public static final String HEADER_HOST					   = "Host";
   public static final String HEADER_CONTENT_TYPE			= "Content-Type";
   public static final String HEADER_CONTENT_TYPE_JMS		= "ContentType";
   public static final String HEADER_CONTENT_LENGTH		= "Content-Length";
   public static final String HEADER_CONTENT_LOCATION		= "Content-Location";
   public static final String HEADER_CONTENT_ID			   = "Content-ID";
   public static final String HEADER_SOAP_ACTION			= "SOAPAction";
   public static final String HEADER_AUTHORIZATION			= "Authorization";
   public static final String HEADER_PROXY_AUTHORIZATION	= "Proxy-Authorization";
   // HTTP header field values.
   public static final String HEADERVAL_DEFAULT_CHARSET		= "iso-8859-1";
   public static final String HEADERVAL_CHARSET_UTF8			= "utf-8";
   public static final String HEADERVAL_CONTENT_TYPE			= "text/xml";
   public static final String HEADERVAL_CONTENT_TYPE_DEFAULT
           = "application/x-www-form-urlencoded";
   public  static final String HTTP_VERSION				      = "1.0";
   public  static final int    HTTP_DEFAULT_PORT			   = 80;
   public  static final int    HTTPS_DEFAULT_PORT			   = 443;
   public  static final int    DEFAULT_OUTPUT_BUFFER_SIZE	= 512;
   public  static final int    DEFAULT_TIMEOUT_MSEC	      = 30000;

   // Имена свойств Продавца в БД  ??? - for SimMP only
   public static final String MP_HOST			         = "HOST";
   public static final String MP_TIMEOUT_SEC 	      = "TIMEOUT_SEC";
   public static final String MP_REQUEST			      = "REQUEST";
   public static final String MP_REQUEST_TYPE	      = "REQUEST_TYPE";
   public static final String MP_RESPONSE_TYPE	      = "RESPONSE_TYPE";
   public static final String MP_RESPONSE_CODE	      = "RESPONSE_CODE";
   public static final String MP_RESPONSE_MESSAGE	   = "RESPONSE_MESSAGE";
   public static final String MP_RESPONSE_CODE_TYPE	= "RESPONSE_CODE_TYPE";
   public static final String MP_USER	               = "USER";
   public static final String MP_PASSWORD             = "PASSWORD";
   public static final String MP_AUTHORITHATION       = "AUTHORITHATION";
   public static final String MP_C002_TYPE            = "C002_TYPE";

   public static final String END_LINE 			= "\r\n";
   public static final char START_MACROS 			= '{';
   public static final char START_FORMAT 			= '|';
   public static final char END_MACROS 			= '}';

}

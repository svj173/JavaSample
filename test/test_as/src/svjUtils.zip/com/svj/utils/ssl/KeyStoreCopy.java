package com.svj.utils.ssl;


import java.security.Security;
import java.security.KeyStore;
import java.io.*;
import java.util.Enumeration;

/**
 * Копирование пар ключей из хранилища PKCS12 в хранилище JKS.
 * Причем если JKS не существует, то создается новое хранилище, иначе копируется
 * вся старая информация (ключи - т.е. к старым ключам добавляются новые ключи из РKCS12).
 * Функция обратного копирования - на будущее.
 * <BR>
 * <BR> User: Zhiganov
 * <BR> Date: 18.08.2005
 * <BR> Time: 9:39:46
 */
public class KeyStoreCopy
{
   public static void main ( String args[] ) throws Throwable
   {
      Security.addProvider ( new com.sun.net.ssl.internal.ssl.Provider () );

      if ( args.length < 6 )
      {
         System.out.println ( "\nKeystoreMove Usage: \njava KeystoreMove <source> " +
              "<destination> where\n" +
              " <source> and <destination> are " +
              "<storetype> <keystore> <password>\n" );
         System.out.println ( " - Requires jsse for PKCS12 keystore support \n" +
              " - source storetype can be JKS or PKCS12\n" +
              " - destination storetype must be JKS type (PKCS12 write not supported)" +
              " and create new.\n" +
              "Example: PKCS12 mailstore_kshin.p12 123456 JKS mailstore.jks 123456");
         System.exit ( 0 );
      }

      // PKCS12 mailstore_kshin.12 123456 JKS mailstore.jks 123456
      FileInputStream in;

      // --------  Load source keystore to memory ---------
      in = new FileInputStream ( args[1] );
      KeyStore ksin = KeyStore.getInstance ( args[0] );
      char[] pwin = args[2].toCharArray ();
      if ( pwin.length == 0 )
      {
         pwin = null;
      }
      ksin.load ( in, pwin );
      in.close ();

      // --------  Load destination keystore initial contents to memory ---------
      KeyStore ksout = KeyStore.getInstance ( args[3] );
      ksout.load ( null, null );
      char[]   pwout = args[5].toCharArray ();
      if ( pwout.length == 0 )    pwout = null;
      String   keyStoreOutFile   = args[4];
      File  file  = new File ( keyStoreOutFile );
      if ( file.exists () )
      {
         // Есть такой файл - закачать
         System.out.println ( "Has key store. Type = " + args[3] );
         in = new FileInputStream ( keyStoreOutFile );
         ksout.load ( in, pwout );
         in.close ();
      }
      else
      {
         // Нет такого хранилища - создать новое
         System.out.println ( "Create new out key store. Type = " + args[3] );
      }

      //---------  Main Loop to get keys/certs from source keystore ------------
      BufferedReader stdin = new BufferedReader ( new InputStreamReader ( System.in ) );

      Enumeration en = ksin.aliases ();
      while ( en.hasMoreElements () )
      {
         String alias = ( String ) en.nextElement ();
         if ( ksout.containsAlias ( alias ) )
         {
            System.out.println ( keyStoreOutFile + " already contains " + alias
                 + "  Key will not be copied." );
            continue;
         }


         // -------  Ask user if alias of source key/cert should be renamed -----------
         System.out.println ( "Source alias: " + alias
              + "  Rename alias to: [<return> to keep original alias] .. " );
         String newuseralias = stdin.readLine ().trim ();
         if ( newuseralias.equals ( "" ) )
         {
            newuseralias = alias;
            System.out.println ( "Original alias used" );
         }
         else
         {
            System.out.println ( "New alias: " + newuseralias );
         }

         if ( ksin.isCertificateEntry ( alias ) )
         {
            System.out.println ( "importing certificate " + alias );
            ksout.setCertificateEntry ( newuseralias, ksin.getCertificate ( alias ) );
         }

         if ( ksin.isKeyEntry ( alias ) )
         {
            System.out.println ( "importing key " + alias );
            ksout.setKeyEntry ( newuseralias, ksin.getKey ( alias, pwin ), pwout, ksin.getCertificateChain ( alias ) );
         }

      }
      //---------  End main loop ----------------------

      //---------  Overwrite the destination keystore with new keys/certs --------------
      FileOutputStream out = new FileOutputStream ( keyStoreOutFile );
      ksout.store ( out, pwout );
      out.close ();
      System.out.println ( "keystore copy successful\n" );
      System.exit ( 0 );
   }
}

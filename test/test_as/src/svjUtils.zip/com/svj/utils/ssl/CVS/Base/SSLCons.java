package com.cft.simmp.utils.ssl;

/**
 * <BR> <BR> User: Zhiganov <BR> Date: 18.08.2005 <BR> Time: 11:44:39
 */
public class SSLCons
{
   public static final String   BC_Provider     = "BC";
   public static final String   SUN_Provider    = "SUN";

}

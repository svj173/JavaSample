/**
 * Created by IntelliJ IDEA.
 * User: svj
 * Date: 16.02.2007
 * Time: 18:14:38
 * To change this template use File | Settings | File Templates.
 */
package test.as.client;

public class NumberManager
{
    private static NumberManager ourInstance = new NumberManager();

    public static int num   = 0;

    public static NumberManager getInstance() {
        return ourInstance;
    }

    private NumberManager() {
    }

    public synchronized  int getNumber()
    {
        // ������������ ���������� ��
        num++;
        return num;
    }


}
